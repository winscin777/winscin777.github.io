<?php
$emailku = 'aram.margaryan.707@gmail.com'; // GANTI EMAIL KAMU DISINI
?>